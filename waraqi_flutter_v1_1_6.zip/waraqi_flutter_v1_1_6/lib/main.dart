import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:tesseract_ocr/tesseract_ocr.dart';
import 'package:tesseract_ocr/ocr_engine_config.dart';
import 'models/paper_document.dart';
import 'services/paper_storage.dart';
import 'services/print_service.dart';
import 'screens/crop_capture_screen.dart';
import 'widgets/paper_pages.dart';
import 'theme.dart';

void main() { WidgetsFlutterBinding.ensureInitialized(); runApp(const WaraqiApp()); }

class WaraqiApp extends StatelessWidget {
  const WaraqiApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner:false,
    title:'ورقتي | منشئ الأوراق الامتحانية',
    theme:appTheme(),
    locale:const Locale('ar','IQ'),
    supportedLocales:const [Locale('ar','IQ'),Locale('en','US')],
    localizationsDelegates:const [
      GlobalMaterialLocalizations.delegate,
      GlobalCupertinoLocalizations.delegate,
      GlobalWidgetsLocalizations.delegate,
    ],
    builder:(context,child)=>Directionality(textDirection:TextDirection.rtl,child:child!),
    home:const StudioScreen(),
  );
}

const _subjects = ['الرياضيات','اللغة العربية','اللغة الإنجليزية','العلوم','الفيزياء','الكيمياء','الأحياء','التربية الإسلامية','الاجتماعيات','اللغة الكردية','مادة عامة'];
const _fieldLabels = <String,String>{
  'country':'الدولة','ministry':'الوزارة','directorate':'المديرية',
  'school':'المدرسة','title':'عنوان الورقة','academicYear':'العام الدراسي',
  'subject':'المادة','grade':'الصف','total':'الدرجة الكلية',
  'duration':'الوقت','date':'التاريخ',
};
const _elements = <String,String>{
  'math':'معادلة رياضية','chem':'معادلة كيميائية','table':'جدول','drawing':'رسم توضيحي',
  'poetry':'شعر','text':'نص منسق','tf':'صح أو خطأ','options':'اختيارات',
  'verse':'آية أو حديث','space':'مساحة إجابة','columns':'فقرات بأعمدة',
  'matching':'مطابقة','gallery':'شبكة صور','photo':'استخراج نص من صورة','image':'صورة توضيحية',
};
const _elementIcons = <String,IconData>{
  'math':Icons.functions,'chem':Icons.science_outlined,'table':Icons.table_chart_outlined,
  'drawing':Icons.draw_outlined,'poetry':Icons.format_quote,'text':Icons.text_fields,
  'tf':Icons.fact_check_outlined,'options':Icons.list_alt,'verse':Icons.menu_book_outlined,
  'space':Icons.edit_note,'columns':Icons.view_column_outlined,'matching':Icons.compare_arrows,
  'gallery':Icons.grid_view_outlined,'photo':Icons.document_scanner_outlined,'image':Icons.image_outlined,
};

class StudioScreen extends StatefulWidget {
  const StudioScreen({super.key});
  @override State<StudioScreen> createState()=>_StudioScreenState();
}

class _StudioScreenState extends State<StudioScreen> with WidgetsBindingObserver {
  final _storage=PaperStorage();
  PaperDocument _document=PaperDocument();
  int _tab=0;
  bool _loading=true;
  bool _answers=false;
  bool _busy=false;
  final _recognizing=<String>{};
  final _questionTextControllers=<String,TextEditingController>{};
  final _collapsed=<String>{};
  final _answersOpen=<String>{};
  List<GlobalKey> _previewKeys=[];
  final _scroll=ScrollController();

  @override void initState(){super.initState();WidgetsBinding.instance.addObserver(this);_load();}
  @override void didChangeAppLifecycleState(AppLifecycleState state){
    if(!_loading && state!=AppLifecycleState.resumed){
      _storage.saveNow(_document);
    }
  }
  Future<void> _load() async {
    final doc=await _storage.load();
    if(mounted)setState((){_document=doc;_loading=false;});
  }
  @override void dispose(){
    for(final controller in _questionTextControllers.values){controller.dispose();}
    WidgetsBinding.instance.removeObserver(this);
    _storage.dispose();_scroll.dispose();super.dispose();
  }
  TextEditingController _textController(PaperQuestion question)=>
      _questionTextControllers.putIfAbsent(question.id,()=>TextEditingController(text:question.text));
  void _edit(VoidCallback fn){setState(fn);_storage.queueSave(_document);}
  void _to(int page){setState(()=>_tab=page);if(_scroll.hasClients)_scroll.jumpTo(0);}
  void _notice(String message){if(!mounted)return;ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(message),behavior:SnackBarBehavior.floating));}

  Future<void> _newDocument() async {
    var subject=_document.subject;
    var type='exam';
    final created=await showModalBottomSheet<bool>(context:context,isScrollControlled:true,backgroundColor:Colors.transparent,builder:(context)=>StatefulBuilder(builder:(context,change)=>SafeArea(child:Container(
      padding:EdgeInsets.fromLTRB(20,24,20,24+MediaQuery.of(context).viewInsets.bottom),
      decoration:const BoxDecoration(color:Colors.white,borderRadius:BorderRadius.vertical(top:Radius.circular(30))),
      child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('إنشاء مستند جديد',style:TextStyle(fontSize:23,fontWeight:FontWeight.w900)),
        const SizedBox(height:7),const Text('اختر المادة ونوع الورقة ثم ابدأ التحرير.',style:TextStyle(color:Palette.muted)),
        const SizedBox(height:22),const Text('نوع المستند',style:TextStyle(fontWeight:FontWeight.w800)),
        const SizedBox(height:9),Row(children:[Expanded(child:_choice('ورقة أسئلة',type=='exam',()=>change(()=>type='exam'))),const SizedBox(width:10),Expanded(child:_choice('ملزمة',type=='booklet',()=>change(()=>type='booklet')))]),
        const SizedBox(height:23),const Text('المادة الدراسية',style:TextStyle(fontWeight:FontWeight.w800)),const SizedBox(height:10),
        Wrap(spacing:8,runSpacing:8,children:_subjects.map((s)=>_choice(s,subject==s,()=>change(()=>subject=s))).toList()),
        const SizedBox(height:25),_mainButton('إنشاء المستند',Icons.add_circle_outline,()=>Navigator.pop(context,true)),
        const SizedBox(height:7),Center(child:TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('إلغاء'))),
      ])),
    ))));
    if(created==true){
      _edit((){_document=PaperDocument()..subject=subject..title='ورقة $subject'..documentType=type..questions=[];_tab=1;_collapsed.clear();});
      _notice('تم إنشاء ورقة جديدة، ويمكنك تعديل بياناتها.');
    }
  }

  /// OCR is the intended outcome of photographing a question: its pixels are
  /// never inserted into the printed exam. The user approves editable text.
  Future<void> _captureQuestion(PaperQuestion question,bool fromCamera) async {
    if(_recognizing.contains(question.id))return;
    try {
      final cropped=await Navigator.push<List<int>>(context,MaterialPageRoute(
        builder:(_)=>CropCaptureScreen(fromCamera:fromCamera)));
      if(!mounted || cropped==null || cropped.isEmpty)return;
      setState(()=>_recognizing.add(question.id));
      File? temporary;
      try {
        final directory=await getTemporaryDirectory();
        temporary=File('${directory.path}/waraqi_ocr_${newId()}.jpg');
        await temporary.writeAsBytes(cropped,flush:true);
        final recognized=await TesseractOcr.extractText(
          temporary.path,
          config:OCRConfig(language:'ara+eng',engine:OCREngine.tesseract,
            options:{'preserve_interword_spaces':'1','tessedit_pageseg_mode':'6'}),
        );
        if(!mounted)return;
        await _reviewExtractedText(question,recognized);
      } finally {
        if(temporary!=null && await temporary.exists())await temporary.delete();
      }
    } catch(e) {
      _notice('تعذّر استخراج النص من الصورة. جرّب صورة أوضح: $e');
    } finally {
      if(mounted)setState(()=>_recognizing.remove(question.id));
    }
  }

  Future<void> _reviewExtractedText(PaperQuestion question,String extracted) async {
    final normalized=extracted.replaceAll('\r\n','\n').trim();
    if(normalized.isEmpty){
      _notice('لم يُكتشف نص واضح في المنطقة المحددة. جرّب توسيع إطار القص وتحسين الإضاءة.');
      return;
    }
    final controller=TextEditingController(text:normalized);
    // The dialog is a deliberate correction step: Arabic OCR can misread
    // diacritics, decimal marks and formulas, so we never auto-commit it.
    try {
      final choice=await showDialog<String>(context:context,builder:(dialog)=>AlertDialog(
        title:const Text('مراجعة النص المستخرج',style:TextStyle(fontWeight:FontWeight.w900)),
        content:SizedBox(width:500,child:SingleChildScrollView(child:Column(
          mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.stretch,
          children:[
            const Text('راجع الأرقام والمعادلات قبل الإضافة. يمكنك تعديل جميع الكلمات مباشرة.',
              style:TextStyle(color:Palette.muted,fontSize:12)),
            const SizedBox(height:13),
            TextField(controller:controller,textDirection:TextDirection.rtl,
              textAlign:TextAlign.right,minLines:5,maxLines:12,
              decoration:const InputDecoration(labelText:'النص المكتشف',hintText:'صحّح نص السؤال هنا')),
          ],
        ))),
        actions:[
          TextButton(onPressed:()=>Navigator.pop(dialog),child:const Text('إلغاء')),
          OutlinedButton(onPressed:()=>Navigator.pop(dialog,'append'),child:const Text('إضافة للنص')),
          FilledButton(onPressed:()=>Navigator.pop(dialog,'replace'),child:const Text('استبدال النص')),
        ],
      ));
      if(choice==null || !mounted)return;
      final text=controller.text.trim();
      if(text.isEmpty){_notice('النص فارغ ولم يُضف إلى السؤال');return;}
      _edit((){
        question.insertExtractedText(text, append:choice=='append');
        _textController(question).value=TextEditingValue(
          text:question.text,
          selection:TextSelection.collapsed(offset:question.text.length),
        );
      });
      _notice('أُدرج النص في السؤال ويمكنك تحريره في أي وقت.');
    } finally {controller.dispose();}
  }

  /// Illustrative image elements stay separate from OCR and are explicitly
  /// opt-in (charts and pictures only, not question text capture).
  Future<void> _addIllustration(PaperQuestion question,bool fromCamera,{String kind='image'}) async {
    try {
      final image=await Navigator.push<List<int>>(context,MaterialPageRoute(
        builder:(_)=>CropCaptureScreen(fromCamera:fromCamera)));
      if(image==null || image.isEmpty || !mounted)return;
      final path=await _storage.saveImage(image);
      _edit(()=>question.elements.add(PaperElement(id:newId(),kind:kind,imagePath:path)));
      _notice('تمت إضافة الصورة التوضيحية إلى السؤال.');
    }catch(e){_notice('تعذّر إضافة الرسم: $e');}
  }

  Future<void> _pickLogo() async {
    try {
      final selected=await ImagePicker().pickImage(source:ImageSource.gallery,imageQuality:80,maxWidth:800);
      if(selected==null)return;
      final path=await _storage.saveImage(await selected.readAsBytes());
      _edit(()=>_document.logoPath=path);
    } catch(e){_notice('تعذّر اختيار الشعار: $e');}
  }

  void _addQuestion(){_edit(()=>_document.questions.add(PaperQuestion(id:newId(),points:5)));}
  void _removeQuestion(PaperQuestion question){_edit(()=>_document.questions.remove(question));}
  void _moveQuestion(int oldIndex,int diff){final next=oldIndex+diff;if(next<0||next>=_document.questions.length)return;_edit((){final q=_document.questions.removeAt(oldIndex);_document.questions.insert(next,q);});}
  void _cloneQuestion(PaperQuestion q){_edit((){_document.questions.insert(_document.questions.indexOf(q)+1,PaperQuestion(id:newId(),text:q.text,points:q.points,answer:q.answer,type:q.type,branches:List.of(q.branches),elements:q.elements.map((e)=>PaperElement(id:newId(),kind:e.kind,text:e.text,imagePath:e.imagePath)).toList()));});}

  void _showElements(PaperQuestion q){
    showModalBottomSheet<void>(context:context,backgroundColor:Colors.transparent,isScrollControlled:true,builder:(context)=>SafeArea(child:Container(
      padding:const EdgeInsets.fromLTRB(17,17,17,27),
      decoration:const BoxDecoration(color:Colors.white,borderRadius:BorderRadius.vertical(top:Radius.circular(29))),
      child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
        Center(child:Container(width:40,height:4,decoration:BoxDecoration(color:Palette.line,borderRadius:BorderRadius.circular(2)))),
        const SizedBox(height:20),const Text('مكتبة العناصر',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),
        const Text('اختر العنصر المناسب، وستظهر البطاقات بألوان مريحة لتسهيل التمييز بين الأنواع.',style:TextStyle(color:Palette.muted)),const SizedBox(height:17),
        ConstrainedBox(constraints:BoxConstraints(maxHeight:MediaQuery.of(context).size.height*.60),child:SingleChildScrollView(child:LayoutBuilder(builder:(context,box){
          final items=_elements.entries.toList();
          final cell=(box.maxWidth-20)/3;
          const palettes=<({Color bg,Color fg})>[
            (bg:Color(0xFFE9F7F2),fg:Color(0xFF0F8A6A)),
            (bg:Color(0xFFEAF3FF),fg:Color(0xFF2B6CB0)),
            (bg:Color(0xFFFFF1E5),fg:Color(0xFFB8661F)),
            (bg:Color(0xFFF2ECFF),fg:Color(0xFF7754C3)),
            (bg:Color(0xFFFFEDF2),fg:Color(0xFFB83260)),
            (bg:Color(0xFFEAF7E7),fg:Color(0xFF4A8F29)),
          ];
          return Wrap(spacing:10,runSpacing:10,children:items.asMap().entries.map((entry){
            final index=entry.key;
            final e=entry.value;
            final palette=palettes[index%palettes.length];
            return InkWell(
              onTap:(){Navigator.pop(context);if(e.key=='photo'){_photoChoice(q);} else if(['image','gallery','drawing'].contains(e.key)){
                _addIllustration(q,false,kind:e.key);
              } else {_textElement(q,e.key);}},
              borderRadius:BorderRadius.circular(19),
              child:Container(
                width:cell,height:107,padding:const EdgeInsets.all(10),
                decoration:BoxDecoration(color:palette.bg,borderRadius:BorderRadius.circular(19),border:Border.all(color:palette.fg.withValues(alpha:.12))),
                child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
                  Container(width:42,height:42,decoration:BoxDecoration(color:Colors.white.withValues(alpha:.85),borderRadius:BorderRadius.circular(14)),child:Icon(_elementIcons[e.key],size:25,color:palette.fg)),
                  const SizedBox(height:9),
                  Text(e.value,textAlign:TextAlign.center,style:TextStyle(fontWeight:FontWeight.w800,fontSize:11.5,color:palette.fg,height:1.3)),
                ]),
              ),
            );
          }).toList());
        }))),
      ]),
    )));
  }

  void _photoChoice(PaperQuestion q){
    showModalBottomSheet<void>(context:context,showDragHandle:true,builder:(context)=>SafeArea(child:Padding(padding:const EdgeInsets.all(18),child:Column(mainAxisSize:MainAxisSize.min,children:[
      const Text('تحويل صورة السؤال إلى نص',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),
      const SizedBox(height:9),const Text('حدد منطقة السؤال أولًا، ثم حوّلها إلى نص قابل للتعديل. لن تُطبع الصورة.',style:TextStyle(color:Palette.muted)),
      const SizedBox(height:17),ListTile(leading:const Icon(Icons.camera_alt_rounded,color:Palette.teal),title:const Text('مسح السؤال بالكاميرا'),subtitle:const Text('غيّر حجم إطار القص قبل الالتقاط ثم راجع النص'),onTap:(){Navigator.pop(context);_captureQuestion(q,true);}),
      ListTile(leading:const Icon(Icons.photo_library_outlined,color:Palette.teal),title:const Text('التعرّف من صورة محفوظة'),subtitle:const Text('حدد مساحة السؤال ثم استخرج النص'),onTap:(){Navigator.pop(context);_captureQuestion(q,false);}),
    ]))));
  }

  Future<void> _textElement(PaperQuestion q,String kind,{PaperElement? existing}) async {
    if(kind=='math'){
      await _mathElementDialog(q,existing:existing);
      return;
    }
    final description=kind=='space'?'عدد أسطر الإجابة (مثال: 4)':kind=='table'?'افصل الأعمدة بعلامة | وكل صف بسطر':kind=='options'?'اكتب كل اختيار في سطر مستقل':'أدخل محتوى ${_elements[kind]}';
    final controller=TextEditingController(text:existing?.text??(kind=='space'?'3':''));
    final value=await showDialog<String>(context:context,builder:(context)=>AlertDialog(
      title:Text(existing==null?'إضافة ${_elements[kind]}':'تعديل ${_elements[kind]}'),
      content:Column(mainAxisSize:MainAxisSize.min,children:[Text(description,style:const TextStyle(color:Palette.muted,fontSize:12)),const SizedBox(height:12),TextField(controller:controller,maxLines:kind=='space'?1:5,decoration:const InputDecoration(hintText:'اكتب هنا...'))]),
      actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(context,controller.text),child:const Text('حفظ'))],
    ));
    controller.dispose();
    if(value!=null){_edit((){if(existing!=null){existing.text=value;} else {q.elements.add(PaperElement(id:newId(),kind:kind,text:value));}});}
  }

  Future<void> _mathElementDialog(PaperQuestion q,{PaperElement? existing}) async {
    final controller=TextEditingController(text:existing?.text??'');
    const categories=<String,List<String>>{
      'أساسي':['xₙ','x^n','ⁿ√','√','a/b','( )','|x|','±'],
      'العمليات':['+','−','×','÷','=','≠','≈','≤','≥','∑','∏'],
      'المجموعات':['∈','∉','⊂','⊆','∪','∩','∅','ℕ','ℤ','ℚ','ℝ'],
      'الهندسة والمثلثات':['∠','△','°','π','⊥','∥','sin','cos','tan'],
      'التفاضل والتكامل':['lim','d/dx','∫','∬','∂','∇','f(x)','dx'],
      'المتجهات والوحدات':['v⃗','x̄','m/s','m/s²','N','μ','Ω','kg'],
    };
    var selected=categories.keys.first;
    void insertToken(String token){
      final value=controller.value;
      final selection=value.selection;
      final text=value.text;
      final start=selection.isValid?selection.start:text.length;
      final end=selection.isValid?selection.end:text.length;
      final newText=text.replaceRange(start,end,token);
      controller.value=TextEditingValue(text:newText,selection:TextSelection.collapsed(offset:start+token.length));
    }
    final result=await showDialog<String>(context:context,builder:(context)=>StatefulBuilder(builder:(context,setLocal)=>AlertDialog(
      title:Text(existing==null?'إضافة معادلة رياضية':'تعديل معادلة رياضية'),
      content:SizedBox(width:560,child:SingleChildScrollView(child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,mainAxisSize:MainAxisSize.min,children:[
        const Text('اختر القسم المناسب، ثم اضغط على الرموز لإدراجها داخل المعادلة. يمكنك كتابة LaTeX أو نص رياضي مباشرة أيضًا.',style:TextStyle(color:Palette.muted,fontSize:12,height:1.5)),
        const SizedBox(height:12),
        Wrap(spacing:8,runSpacing:8,children:categories.keys.map((name)=>_choice(name,selected==name,()=>setLocal(()=>selected=name))).toList()),
        const SizedBox(height:12),
        Wrap(spacing:8,runSpacing:8,children:categories[selected]!.map((token)=>ActionChip(label:Text(token,style:const TextStyle(fontWeight:FontWeight.w800)),onPressed:()=>setLocal(()=>insertToken(token)),backgroundColor:Colors.white)).toList()),
        const SizedBox(height:14),
        Container(padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:const Color(0xFFFFF7DA),borderRadius:BorderRadius.circular(16)),child:const Row(children:[Icon(Icons.info_outline,color:Color(0xFF8C6A1B)),SizedBox(width:8),Expanded(child:Text('إذا تُركت المعادلة فارغة تبقى المسودة محفوظة كما كتبتها لاحقًا.',style:TextStyle(fontSize:11.5,color:Color(0xFF6E5317))))])),
        const SizedBox(height:12),
        TextField(controller:controller,minLines:5,maxLines:8,textDirection:TextDirection.ltr,decoration:const InputDecoration(labelText:'المعادلة',hintText:'مثال: x^2-5x+6=0 أو LaTeX')),
      ]))),
      actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(context,controller.text),child:const Text('حفظ'))],
    )));
    controller.dispose();
    if(result!=null){_edit((){if(existing!=null){existing.text=result;} else {q.elements.add(PaperElement(id:newId(),kind:'math',text:result));}});}
  }

  Future<void> _chooseExportFormat() async {
    if(_busy)return;
    showModalBottomSheet<void>(context:context,showDragHandle:true,builder:(context)=>SafeArea(child:Padding(
      padding:const EdgeInsets.fromLTRB(18,10,18,18),
      child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        const Text('اختر الصيغة النهائية',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),
        const SizedBox(height:8),
        const Text('يمكنك الآن إخراج الورقة النهائية بصيغة PDF أو Word حسب حاجتك.',style:TextStyle(color:Palette.muted)),
        const SizedBox(height:16),
        _secondaryButton('حفظ أو مشاركة PDF',Icons.picture_as_pdf_outlined,(){Navigator.pop(context);_exportPdf();}),
        const SizedBox(height:10),
        _secondaryButton('حفظ أو مشاركة Word',Icons.description_outlined,(){Navigator.pop(context);_exportWord();}),
      ]),
    )));
  }

  Future<void> _exportPdf() async {
    await _export(true);
  }

  Future<void> _exportWord() async {
    if(_busy)return;
    setState(()=>_busy=true);
    try{
      await PrintService.shareWord(_document,answers:_answers);
    }catch(e){_notice('تعذّر تجهيز ملف Word: $e');}
    if(mounted)setState(()=>_busy=false);
  }

  @override Widget build(BuildContext context){
    if(_loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    final pages=['الرئيسية','بيانات الورقة','محرر الأسئلة','التنسيق','معاينة الورقة'];
    return Scaffold(
      appBar:AppBar(title:Row(children:[Container(width:39,height:39,decoration:BoxDecoration(color:Palette.teal,borderRadius:BorderRadius.circular(13)),child:const Icon(Icons.description_rounded,color:Colors.white,size:22)),const SizedBox(width:10),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('ورقتي',style:TextStyle(fontWeight:FontWeight.w900,fontSize:21)),Text(pages[_tab],style:const TextStyle(fontSize:11,color:Palette.muted,fontWeight:FontWeight.w400))]))]),actions:[IconButton(tooltip:'حفظ',onPressed:() async {await _storage.saveNow(_document);_notice('تم حفظ الورقة على الجهاز');},icon:const Icon(Icons.save_outlined)),IconButton(tooltip:'مستند جديد',onPressed:_newDocument,icon:const Icon(Icons.add_box_outlined)),const SizedBox(width:5)]),
      body:SingleChildScrollView(controller:_scroll,padding:const EdgeInsets.fromLTRB(14,6,14,110),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:1050),child:Center(child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        if(_tab==0)_home(),if(_tab==1)_data(),if(_tab==2)_questions(),if(_tab==3)_format(),if(_tab==4)_preview(),
      ])))),
      bottomNavigationBar:SafeArea(top:false,child:Container(margin:const EdgeInsets.fromLTRB(12,0,12,9),padding:const EdgeInsets.symmetric(vertical:7,horizontal:4),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(25),boxShadow:[BoxShadow(color:Palette.ink.withValues(alpha:.10),blurRadius:22,offset:const Offset(0,5))]),child:Row(children:[
        _nav(0,Icons.grid_view_rounded,'الرئيسية'),_nav(1,Icons.ballot_outlined,'البيانات'),_nav(2,Icons.list_alt_rounded,'الأسئلة'),_nav(3,Icons.tune_rounded,'التنسيق'),_nav(4,Icons.preview_outlined,'المعاينة'),
      ]))),
    );
  }

  Widget _nav(int index,IconData icon,String label){final active=_tab==index;return Expanded(child:InkWell(onTap:()=>_to(index),borderRadius:BorderRadius.circular(17),child:AnimatedContainer(duration:const Duration(milliseconds:180),padding:const EdgeInsets.symmetric(vertical:8),decoration:BoxDecoration(color:active?Palette.mint:Colors.transparent,borderRadius:BorderRadius.circular(17)),child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(icon,size:22,color:active?Palette.teal:Palette.muted),const SizedBox(height:3),Text(label,style:TextStyle(fontSize:10.5,fontWeight:active?FontWeight.w900:FontWeight.w600,color:active?Palette.teal:Palette.muted))]))));}
  Widget _hero(String number,String heading,String subtitle,IconData icon,Color surface,Color accent){return Container(margin:const EdgeInsets.only(bottom:14),padding:const EdgeInsets.all(20),decoration:BoxDecoration(color:surface,borderRadius:BorderRadius.circular(27)),child:Row(children:[Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(number,style:TextStyle(color:accent,fontWeight:FontWeight.w900,fontSize:11)),const SizedBox(height:8),Text(heading,style:const TextStyle(color:Palette.ink,fontSize:22,fontWeight:FontWeight.w900)),const SizedBox(height:6),Text(subtitle,style:const TextStyle(color:Palette.muted,fontSize:12.5,height:1.55))])),const SizedBox(width:8),Container(height:65,width:65,decoration:BoxDecoration(color:Colors.white.withValues(alpha:.8),borderRadius:BorderRadius.circular(21)),child:Icon(icon,color:accent,size:30))]));}
  Widget _panel(String title,IconData icon,Widget body,{String? subtitle,Color? iconColor}) => Container(margin:const EdgeInsets.only(bottom:13),padding:const EdgeInsets.all(17),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(25),border:Border.all(color:Palette.line)),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    Row(children:[Container(width:39,height:39,decoration:BoxDecoration(color:(iconColor??Palette.teal).withValues(alpha:.10),borderRadius:BorderRadius.circular(13)),child:Icon(icon,color:iconColor??Palette.teal,size:21)),const SizedBox(width:11),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:16,fontWeight:FontWeight.w900)),if(subtitle!=null)Text(subtitle,style:const TextStyle(color:Palette.muted,fontSize:11.5))]))]),const SizedBox(height:16),body,
  ]));
  Widget _choice(String title,bool selected,VoidCallback tap,{IconData? icon})=>InkWell(onTap:tap,borderRadius:BorderRadius.circular(13),child:Container(padding:const EdgeInsets.symmetric(horizontal:13,vertical:11),decoration:BoxDecoration(color:selected?Palette.mint:Palette.background,borderRadius:BorderRadius.circular(13),border:Border.all(color:selected?Palette.teal.withValues(alpha:.2):Palette.line)),child:Row(mainAxisSize:MainAxisSize.min,children:[if(icon!=null)...[Icon(icon,size:17,color:selected?Palette.teal:Palette.muted),const SizedBox(width:7)],Text(title,style:TextStyle(fontSize:12.5,fontWeight:selected?FontWeight.w800:FontWeight.w500,color:Palette.ink)),if(selected)...[const SizedBox(width:6),const Icon(Icons.check_circle_rounded,size:16,color:Palette.teal)]])));
  Widget _mainButton(String label,IconData icon,VoidCallback tap,{bool dark=false})=>SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:tap,icon:Icon(icon,size:19),label:Padding(padding:const EdgeInsets.symmetric(vertical:12),child:Text(label,style:const TextStyle(fontSize:14,fontWeight:FontWeight.w900))),style:FilledButton.styleFrom(backgroundColor:dark?Palette.ink:Palette.teal,foregroundColor:Colors.white,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(17)))));
  Widget _secondaryButton(String title,IconData icon,VoidCallback? action)=>OutlinedButton.icon(onPressed:action,icon:Icon(icon,size:17),label:Text(title,style:const TextStyle(fontWeight:FontWeight.w800)),style:OutlinedButton.styleFrom(foregroundColor:Palette.ink,side:const BorderSide(color:Palette.line),padding:const EdgeInsets.symmetric(vertical:11,horizontal:12),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(15))));
  Widget _editField(String label,String value,ValueChanged<String> update,{int lines=1,String? hint,TextInputType? keyboard})=>Padding(padding:const EdgeInsets.only(bottom:13),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Padding(padding:const EdgeInsets.only(bottom:7),child:Text(label,style:const TextStyle(fontSize:12,fontWeight:FontWeight.w800))),TextFormField(key:ValueKey('$label-${_document.hashCode}'),initialValue:value,onChanged:(v){update(v);_storage.queueSave(_document);},keyboardType:keyboard,minLines:lines,maxLines:lines,decoration:InputDecoration(hintText:hint??label))]));
  Widget _stats(String label,String number,IconData icon,Color background,Color foreground){return Expanded(child:Container(padding:const EdgeInsets.all(13),decoration:BoxDecoration(color:background,borderRadius:BorderRadius.circular(19)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,color:foreground,size:20),const SizedBox(height:12),Text(number,style:TextStyle(color:Palette.ink,fontWeight:FontWeight.w900,fontSize:19)),Text(label,style:const TextStyle(fontSize:11,color:Palette.muted))])));}

  Widget _home(){final d=_document;return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    Container(height:245,clipBehavior:Clip.antiAlias,decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xFF193A47),Color(0xFF147B7B)],begin:Alignment.topRight,end:Alignment.bottomLeft),borderRadius:BorderRadius.circular(29)),child:Stack(children:[
      Positioned(left:-80,top:40,child:Container(width:235,height:235,decoration:BoxDecoration(shape:BoxShape.circle,border:Border.all(color:Colors.white24,width:37)))),
      Positioned(left:24,top:30,child:Transform.rotate(angle:-.15,child:Container(width:115,height:155,decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(14),boxShadow:const [BoxShadow(color:Colors.black26,blurRadius:17)]),child:const Padding(padding:EdgeInsets.all(15),child:Column(children:[Icon(Icons.school_outlined,color:Palette.teal),Divider(),SizedBox(height:19),Divider(),Divider(),Divider(),Divider()]))))),
      Positioned.fill(child:Padding(padding:const EdgeInsets.all(23),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Container(padding:const EdgeInsets.symmetric(horizontal:12,vertical:6),decoration:BoxDecoration(color:Colors.white24,borderRadius:BorderRadius.circular(30)),child:const Text('استوديو إنشاء الامتحانات',style:TextStyle(color:Colors.white,fontSize:11,fontWeight:FontWeight.w700))),const SizedBox(height:17),const Text('ورقة احترافية،\nبلمساتك الخاصة',style:TextStyle(fontSize:25,fontWeight:FontWeight.w900,color:Colors.white,height:1.4)),const Spacer(),SizedBox(width:180,child:FilledButton.icon(onPressed:()=>_to(2),icon:const Icon(Icons.edit_note_rounded),label:const Text('تابع التحرير'),style:FilledButton.styleFrom(backgroundColor:const Color(0xFFCCF6DC),foregroundColor:Palette.ink)))]))),
    ])),const SizedBox(height:13),Row(children:[_stats('الأسئلة','${d.digits(d.questions.length)}',Icons.quiz_outlined,Palette.mint,Palette.teal),const SizedBox(width:9),_stats('الدرجات',d.digits(d.usedPoints.toStringAsFixed(0)),Icons.analytics_outlined,Palette.blue,const Color(0xFF448FAE)),const SizedBox(width:9),_stats('المستند','A4',Icons.description_outlined,Palette.lilac,const Color(0xFF7B65B1))]),
    const SizedBox(height:20),const Text('مساحة العمل',style:TextStyle(fontSize:21,fontWeight:FontWeight.w900)),const SizedBox(height:5),const Text('كل أدواتك منظمة في أقسام واضحة',style:TextStyle(fontSize:12,color:Palette.muted)),const SizedBox(height:12),
    GridView.count(crossAxisCount:2,childAspectRatio:1.34,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),mainAxisSpacing:11,crossAxisSpacing:11,children:[
      _homeCard('بيانات الورقة','الترويسة، المدرسة، المادة',Icons.ballot_outlined,Palette.mint,Palette.teal,1),
      _homeCard('الأسئلة','كتابة، تصوير، درجات',Icons.library_books_outlined,Palette.blue,const Color(0xFF3C87A9),2),
      _homeCard('التنسيق','الخطوط، الأرقام، الهوامش',Icons.tune_outlined,Palette.lilac,const Color(0xFF7B65B1),3),
      _homeCard('المعاينة','نسخة الطالب والإجابات',Icons.print_outlined,Palette.sand,const Color(0xFFA77A3E),4),
    ]),const SizedBox(height:14),_panel('الورقة الحالية',Icons.description_outlined,Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(d.title,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:17)),const SizedBox(height:5),Text('${d.subject} • ${d.grade} • ${d.digits(d.academicYear)}',style:const TextStyle(color:Palette.muted,fontSize:12)),const SizedBox(height:14),Row(children:[Expanded(child:_secondaryButton('مستند جديد',Icons.add,_newDocument)),const SizedBox(width:9),Expanded(child:_secondaryButton('عرض الورقة',Icons.visibility_outlined,()=>_to(4)))] )])),
  ]);}

  Widget _homeCard(String title,String subtitle,IconData icon,Color bg,Color fg,int page)=>InkWell(onTap:()=>_to(page),borderRadius:BorderRadius.circular(23),child:Container(padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:bg,borderRadius:BorderRadius.circular(23)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Container(height:37,width:37,decoration:BoxDecoration(color:Colors.white70,borderRadius:BorderRadius.circular(13)),child:Icon(icon,color:fg,size:21)),const Spacer(),Text(title,style:const TextStyle(fontSize:15,fontWeight:FontWeight.w900)),const SizedBox(height:3),Text(subtitle,maxLines:2,style:const TextStyle(fontSize:10.5,color:Palette.muted))])));

  Widget _data(){final d=_document;return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    _hero('01 / بيانات المستند','هوية ورقتك','أدخل المعلومات مرة واحدة وحدّد العناصر التي تريد إظهارها في رأس الورقة وأسفلها.',Icons.assignment_outlined,Palette.mint,Palette.teal),
    _panel('معلومات المدرسة',Icons.school_outlined,Column(children:[
      _editField('الدولة',d.country,(v)=>d.country=v),_editField('الوزارة',d.ministry,(v)=>d.ministry=v),_editField('المديرية',d.directorate,(v)=>d.directorate=v),_editField('اسم المدرسة',d.school,(v)=>d.school=v),
    ]),subtitle:'بيانات الترويسة الرسمية'),
    _panel('بيانات الاختبار',Icons.fact_check_outlined,Column(children:[
      _editField('عنوان الورقة',d.title,(v)=>d.title=v),_editField('المادة',d.subject,(v)=>d.subject=v),
      _editField('الصف',d.grade,(v)=>d.grade=v),_editField('العام الدراسي',d.academicYear,(v)=>d.academicYear=v),
      _editField('نوع الاختبار',d.examLabel,(v)=>d.examLabel=v),_editField('التاريخ',d.date,(v)=>d.date=v),
      _editField('مدة الامتحان',d.duration,(v)=>d.duration=v),
      _editField('الدرجة الكلية',d.total.toStringAsFixed(0),(v){d.total=(parseLocalizedNumber(v)??0).clamp(0,1000000).toDouble();},keyboard:TextInputType.number),
    ]),iconColor:const Color(0xFF448FAE)),
    _panel('الجزء العلوي للورقة',Icons.vertical_align_top,Column(children:[
      _editField('البسملة',d.bismillah,(v)=>d.bismillah=v),_editField('ملاحظة أعلى الورقة',d.topNote,(v)=>d.topNote=v,lines:2),
      Align(alignment:Alignment.centerRight,child:Text('الحقول الظاهرة في الترويسة',style:Theme.of(context).textTheme.titleSmall)),const SizedBox(height:10),
      Wrap(spacing:8,runSpacing:8,children:_fieldLabels.entries.map((e)=>_choice(e.value,d.headerFields.contains(e.key),()=>_edit((){if(!d.headerFields.add(e.key))d.headerFields.remove(e.key);}))).toList()),
    ]),subtitle:'عرض أو إخفاء كل حقل دون حذف معلوماته',iconColor:const Color(0xFF7B65B1)),
    _panel('الجزء السفلي والبيانات الاختيارية',Icons.vertical_align_bottom,Column(children:[
      _editField('معلم المادة',d.teacherName,(v)=>d.teacherName=v),
      _editField('ملاحظة أسفل الورقة',d.footerText,(v)=>d.footerText=v,lines:2),
      const SizedBox(height:6),
      _switch('إظهار حقل اسم الطالب',d.showStudentNameField,(v)=>_edit(()=>d.showStudentNameField=v)),
      _switch('إظهار حقل الصف/الشعبة',d.showSectionField,(v)=>_edit(()=>d.showSectionField=v)),
    ]),subtitle:'يمكن جعل اسم الطالب والشعبة اختياريين، كما يظهر معلم المادة في أسفل الورقة',iconColor:const Color(0xFFB8661F)),
    _panel('شعار المدرسة',Icons.image_outlined,Row(children:[Container(width:72,height:72,decoration:BoxDecoration(color:Palette.background,borderRadius:BorderRadius.circular(16)),child:d.logoPath!=null&&File(d.logoPath!).existsSync()?ClipRRect(borderRadius:BorderRadius.circular(16),child:Image.file(File(d.logoPath!),fit:BoxFit.cover)):const Icon(Icons.add_photo_alternate_outlined,color:Palette.muted,size:28)),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('ضع شعار المدرسة أعلى الورقة',style:TextStyle(fontSize:12,fontWeight:FontWeight.w700)),const SizedBox(height:7),_secondaryButton('اختيار شعار',Icons.photo_library_outlined,_pickLogo)]))])),
    _mainButton('متابعة إلى الأسئلة',Icons.arrow_back_rounded,()=>_to(2)),
  ]);}

  Widget _questions(){
    final d=_document;
    final used=d.usedPoints;
    final difference=(used-d.total).abs();
    return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      _hero('02 / محرر الأسئلة','صمّم أسئلتك بحرية','كتابة، استخراج النص من صورة بعد قصها، فروع، عناصر ونماذج إجابة.',Icons.edit_document,Palette.blue,const Color(0xFF3685A8)),
      Container(margin:const EdgeInsets.only(bottom:14),padding:const EdgeInsets.all(17),decoration:BoxDecoration(color:Palette.dark,borderRadius:BorderRadius.circular(25)),child:Column(children:[
        Row(children:[const Icon(Icons.analytics_outlined,color:Color(0xFFB9EBD2),size:26),const SizedBox(width:9),Expanded(child:const Text('ملخص درجات الورقة',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w900))),Text('${d.digits(d.questions.length)} سؤال',style:const TextStyle(color:Colors.white70))]),
        const SizedBox(height:15),Row(children:[Expanded(child:_darkMetric('درجات الأسئلة',d.digits(used.toStringAsFixed(used==used.roundToDouble()?0:1)))),const SizedBox(width:9),Expanded(child:_darkMetric('الدرجة الكلية',d.digits(d.total.toStringAsFixed(d.total==d.total.roundToDouble()?0:1))))]),
        if(difference>.001)Padding(padding:const EdgeInsets.only(top:13),child:Row(children:[const Icon(Icons.info_outline,color:Color(0xFFFFD390),size:18),const SizedBox(width:7),Expanded(child:Text('هناك فرق مقداره ${d.digits(difference.toStringAsFixed(difference==difference.roundToDouble()?0:1))} درجة. يمكنك تعديله في بيانات الورقة.',style:const TextStyle(color:Color(0xFFFFE3B6),fontSize:11)))])),
      ])),
      _panel('الأرقام في جميع الأسئلة',Icons.pin_outlined,Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Wrap(spacing:9,runSpacing:9,children:[_choice('عربية ١٢٣',d.digitStyle==DigitStyle.arabic,()=>_edit(()=>d.digitStyle=DigitStyle.arabic)),_choice('إنجليزية 123',d.digitStyle==DigitStyle.english,()=>_edit(()=>d.digitStyle=DigitStyle.english))]),
        const SizedBox(height:8),const Text('ينطبق الاختيار على أرقام نصوص الأسئلة وفروعها وأرقام السؤال والصفحة في المعاينة والطباعة.',style:TextStyle(fontSize:11,color:Palette.muted,height:1.5)),
      ]),iconColor:const Color(0xFF9A7CBE)),
      if(d.questions.isEmpty) Container(margin:const EdgeInsets.only(bottom:16),padding:const EdgeInsets.symmetric(vertical:43,horizontal:22),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(25),border:Border.all(color:Palette.line)),child:Column(children:[Container(width:87,height:87,decoration:BoxDecoration(color:Palette.mint,borderRadius:BorderRadius.circular(27)),child:const Icon(Icons.library_add_check_outlined,color:Palette.teal,size:43)),const SizedBox(height:16),const Text('ابدأ بالسؤال الأول',style:TextStyle(fontSize:21,fontWeight:FontWeight.w900)),const SizedBox(height:5),const Text('اكتب سؤالك أو استخرج نصه من صورة بعد تحديد إطار الالتقاط.',style:TextStyle(color:Palette.muted,fontSize:12),textAlign:TextAlign.center)])),
      for(var i=0;i<d.questions.length;i++) _questionCard(d.questions[i],i),
      const SizedBox(height:6),_mainButton('إضافة سؤال جديد',Icons.add_circle_outline,_addQuestion),
      const SizedBox(height:10),_mainButton('الانتقال إلى المعاينة',Icons.visibility_outlined,()=>_to(4),dark:true),
    ]);
  }

  Widget _darkMetric(String label,String value)=>Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:Colors.white.withValues(alpha:.10),borderRadius:BorderRadius.circular(15)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(label,style:const TextStyle(color:Colors.white70,fontSize:11)),Text(value,style:const TextStyle(color:Colors.white,fontSize:24,fontWeight:FontWeight.w900))]));

  Widget _questionCard(PaperQuestion q,int index){
    final d=_document;
    final collapsed=_collapsed.contains(q.id);
    final answerOpen=_answersOpen.contains(q.id);
    return Container(margin:const EdgeInsets.only(bottom:14),padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(24),border:Border.all(color:Palette.line),boxShadow:[BoxShadow(color:Palette.ink.withValues(alpha:.025),blurRadius:12,offset:const Offset(0,4))]),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      Row(children:[Container(padding:const EdgeInsets.symmetric(horizontal:14,vertical:9),decoration:BoxDecoration(color:Palette.dark,borderRadius:BorderRadius.circular(12)),child:Text('السؤال ${d.digits(index+1)}',style:const TextStyle(fontWeight:FontWeight.w900,color:Colors.white,fontSize:13))),const Spacer(),IconButton(tooltip:'نقل لأعلى',onPressed:index==0?null:()=>_moveQuestion(index,-1),icon:const Icon(Icons.keyboard_arrow_up)),IconButton(tooltip:'نقل لأسفل',onPressed:index==d.questions.length-1?null:()=>_moveQuestion(index,1),icon:const Icon(Icons.keyboard_arrow_down)),PopupMenuButton<String>(tooltip:'خيارات السؤال',onSelected:(action){if(action=='copy')_cloneQuestion(q);if(action=='remove')_removeQuestion(q);if(action=='visible')_edit(()=>q.visible=!q.visible);},itemBuilder:(_)=>[const PopupMenuItem(value:'copy',child:Text('نسخ السؤال')),PopupMenuItem(value:'visible',child:Text(q.visible?'إخفاء من الطباعة':'إظهار في الطباعة')),const PopupMenuItem(value:'remove',child:Text('حذف السؤال',style:TextStyle(color:Colors.red)))])]),
      const SizedBox(height:11),Row(children:[const Text('درجة السؤال',style:TextStyle(fontSize:12,fontWeight:FontWeight.w700)),const SizedBox(width:9),SizedBox(width:81,child:TextFormField(key:ValueKey('points-${q.id}'),initialValue:q.points.toStringAsFixed(0),keyboardType:const TextInputType.numberWithOptions(decimal:true),textAlign:TextAlign.center,onChanged:(v){setState(()=>q.points=(parseLocalizedNumber(v)??0).clamp(0,1000000).toDouble());_storage.queueSave(d);},decoration:const InputDecoration(isDense:true,contentPadding:EdgeInsets.all(10)))),const Spacer(),_choice(q.visible?'ظاهر':'مخفي',q.visible,()=>_edit(()=>q.visible=!q.visible),icon:Icons.visibility_outlined),IconButton(onPressed:()=>setState((){if(!_collapsed.add(q.id))_collapsed.remove(q.id);}),icon:Icon(collapsed?Icons.expand_more:Icons.expand_less))]),
      if(!collapsed)...[
        const SizedBox(height:12),TextFormField(key:ValueKey('question-text-${q.id}'),controller:_textController(q),maxLines:3,minLines:2,textInputAction:TextInputAction.newline,onChanged:(v){q.text=v;_storage.queueSave(d);},decoration:const InputDecoration(hintText:'اكتب نص السؤال أو استخرجه من صورة...')),
        const SizedBox(height:11),Row(children:[Expanded(child:_secondaryButton(_recognizing.contains(q.id)?'جارٍ استخراج النص...':'نص من صورة',Icons.document_scanner_outlined,_recognizing.contains(q.id)?null:()=>_photoChoice(q))),const SizedBox(width:7),Expanded(child:_secondaryButton('إضافة عنصر',Icons.add_box_outlined,()=>_showElements(q)))]),
        if(q.branches.isNotEmpty)...[const SizedBox(height:14),const Text('فروع السؤال',style:TextStyle(fontWeight:FontWeight.w800,fontSize:12)),const SizedBox(height:7)],
        for(var j=0;j<q.branches.length;j++) Padding(padding:const EdgeInsets.only(bottom:8),child:Row(children:[Container(width:34,height:36,alignment:Alignment.center,decoration:BoxDecoration(color:Palette.mint,borderRadius:BorderRadius.circular(11)),child:Text(d.digits(j+1),style:const TextStyle(color:Palette.teal,fontWeight:FontWeight.w900))),const SizedBox(width:7),Expanded(child:TextFormField(key:ValueKey('branch-${q.id}-$j-${q.branches[j]}'),initialValue:q.branches[j],minLines:1,maxLines:2,onChanged:(v){q.branches[j]=v;_storage.queueSave(d);},decoration:const InputDecoration(isDense:true,hintText:'نص الفرع'))),IconButton(tooltip:'حذف الفرع',onPressed:()=>_edit(()=>q.branches.removeAt(j)),icon:const Icon(Icons.close,size:18,color:Palette.muted))])),
        if(q.elements.isNotEmpty)...[const SizedBox(height:8),const Text('العناصر المضافة',style:TextStyle(fontWeight:FontWeight.w800,fontSize:12)),const SizedBox(height:8)],
        for(final element in q.elements) _elementChip(q,element),
        const SizedBox(height:11),Row(children:[Expanded(child:_secondaryButton('إضافة فرع',Icons.add,()=>_edit(()=>q.branches.add('')))),const SizedBox(width:7),Expanded(child:_secondaryButton('استخراج من المعرض',Icons.photo_library_outlined,_recognizing.contains(q.id)?null:()=>_captureQuestion(q,false)))]),
        const SizedBox(height:11),InkWell(onTap:()=>setState((){if(!_answersOpen.add(q.id))_answersOpen.remove(q.id);}),borderRadius:BorderRadius.circular(15),child:Container(padding:const EdgeInsets.all(13),decoration:BoxDecoration(color:Palette.background,borderRadius:BorderRadius.circular(15)),child:Row(children:[const Icon(Icons.key_outlined,color:Palette.teal,size:19),const SizedBox(width:9),const Expanded(child:Text('نموذج الإجابة',style:TextStyle(fontWeight:FontWeight.w800))),Icon(answerOpen?Icons.keyboard_arrow_up:Icons.keyboard_arrow_down)]))),
        if(answerOpen)Padding(padding:const EdgeInsets.only(top:9),child:TextFormField(key:ValueKey('answer-${q.id}'),initialValue:q.answer,maxLines:3,onChanged:(v){q.answer=v;_storage.queueSave(d);},decoration:const InputDecoration(hintText:'الإجابة النموذجية (لا تظهر في نسخة الطالب)'))),
      ],
    ]));
  }

  Widget _elementChip(PaperQuestion q,PaperElement element)=>Container(margin:const EdgeInsets.only(bottom:7),decoration:BoxDecoration(color:Palette.background,borderRadius:BorderRadius.circular(15),border:Border.all(color:Palette.line)),child:ListTile(dense:true,leading:Icon(_elementIcons[element.kind]??Icons.article_outlined,color:Palette.teal),title:Text(_elements[element.kind]??element.kind,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:12)),subtitle:element.imagePath!=null?Padding(padding:const EdgeInsets.only(top:5),child:File(element.imagePath!).existsSync()?Image.file(File(element.imagePath!),height:90,alignment:Alignment.centerRight):const Text('الصورة غير موجودة')):Text(element.text,maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:11)),trailing:Row(mainAxisSize:MainAxisSize.min,children:[if(element.imagePath==null)IconButton(onPressed:()=>_textElement(q,element.kind,existing:element),icon:const Icon(Icons.edit_outlined,size:19)),IconButton(onPressed:()=>_edit(()=>q.elements.remove(element)),icon:const Icon(Icons.delete_outline,size:19,color:Colors.redAccent))])));

  Widget _format(){final d=_document;return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    _hero('03 / التنسيق والطباعة','محرر المظهر','تحكم دقيق في بداية ونهاية الكتابة والمسافات وشكل الأرقام.',Icons.tune_rounded,Palette.lilac,const Color(0xFF7860AF)),
    _panel('شكل الأرقام في الورقة',Icons.onetwothree,Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Wrap(spacing:10,runSpacing:9,children:[_choice('١٢٣ عربية',d.digitStyle==DigitStyle.arabic,()=>_edit(()=>d.digitStyle=DigitStyle.arabic)),_choice('123 إنجليزية',d.digitStyle==DigitStyle.english,()=>_edit(()=>d.digitStyle=DigitStyle.english))]),const SizedBox(height:12),Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:Palette.background,borderRadius:BorderRadius.circular(14)),child:Text(d.digits('س 1: احسب 45.67 × 100 =      (1) 250'),style:const TextStyle(fontWeight:FontWeight.w800,fontSize:14)))]),subtitle:'إعداد موحد لترقيم الأسئلة والفروع ونصوصها والمعاينة'),
    _panel('موضع الكتابة في صفحة A4',Icons.vertical_align_center,Column(children:[
      _range('الهامش العلوي — قلّله لرفع بداية الكتابة',d.topMarginMm,0,45,'مم',(v)=>_edit(()=>d.topMarginMm=v)),
      const Divider(color:Palette.line,height:22),
      _range('الهامش السفلي — قلّله لإنزال نهاية الكتابة',d.bottomMarginMm,0,45,'مم',(v)=>_edit(()=>d.bottomMarginMm=v)),
      const Divider(color:Palette.line,height:22),
      _range('الهوامش الجانبية',d.sideMarginMm,5,30,'مم',(v)=>_edit(()=>d.sideMarginMm=v)),
      const Divider(color:Palette.line,height:22),
      _range('الفاصل بعد الترويسة',d.headerGapMm,0,28,'مم',(v)=>_edit(()=>d.headerGapMm=v)),
      const SizedBox(height:7),Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:Palette.mint,borderRadius:BorderRadius.circular(15)),child:Row(children:[const Icon(Icons.lightbulb_outline,color:Palette.teal),const SizedBox(width:9),Expanded(child:Text('يمكنك رفع الكتابة حتى أعلى الصفحة، لكن بعض الطابعات تحتاج هامش أمان ٥–١٠ مم.',style:TextStyle(color:Palette.ink,fontSize:11,height:1.5)))])),
    ]),subtitle:'تحريك مساحة الكتابة عموديًا بدقة الملّيمتر'),
    _panel('الخط والمسافات',Icons.format_size,Column(children:[
      _range('حجم الخط',d.fontSize,11,23,'نقطة',(v)=>_edit(()=>d.fontSize=v)),
      const Divider(color:Palette.line,height:22),
      _range('تباعد الأسطر',d.lineSpacing,1,2.2,'×',(v)=>_edit(()=>d.lineSpacing=v)),
      const Divider(color:Palette.line,height:22),
      _range('المسافة بين الأسئلة',d.questionGap,4,35,'نقطة',(v)=>_edit(()=>d.questionGap=v)),
    ])),
    _panel('إعدادات الورقة',Icons.pages_outlined,Column(children:[
      Row(children:[Expanded(child:_choice('A4 عمودي',!d.landscape,()=>_edit(()=>d.landscape=false),icon:Icons.stay_current_portrait)),const SizedBox(width:8),Expanded(child:_choice('A4 أفقي',d.landscape,()=>_edit(()=>d.landscape=true),icon:Icons.stay_current_landscape))]),
      const SizedBox(height:14),_switch('خط فاصل أسفل الترويسة',d.showHeaderLine,(v)=>_edit(()=>d.showHeaderLine=v)),
      _switch('إظهار درجات الأسئلة',d.showGrades,(v)=>_edit(()=>d.showGrades=v)),
      _switch('سطور للإجابة',d.showRules,(v)=>_edit(()=>d.showRules=v)),
      _switch('عبارة نهاية الورقة',d.showFooter,(v)=>_edit(()=>d.showFooter=v)),
      _switch('ترقيم الصفحات',d.showPageNumbers,(v)=>_edit(()=>d.showPageNumbers=v)),
      _switch('شعار المدرسة',d.showLogo,(v)=>_edit(()=>d.showLogo=v)),
    ])),
    _mainButton('شاهد نتيجة التنسيق',Icons.preview_outlined,()=>_to(4)),
  ]);}

  Widget _range(String title,double value,double min,double max,String unit,ValueChanged<double> changed){
    final displayed=value==value.roundToDouble()?value.toInt().toString():value.toStringAsFixed(1);
    return Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Expanded(child:Text(title,style:const TextStyle(fontSize:12,fontWeight:FontWeight.w800))),Container(padding:const EdgeInsets.symmetric(horizontal:10,vertical:5),decoration:BoxDecoration(color:Palette.mint,borderRadius:BorderRadius.circular(9)),child:Text('${_document.digits(displayed)} $unit',style:const TextStyle(color:Palette.teal,fontWeight:FontWeight.w900,fontSize:12)))]),Slider(min:min,max:max,value:value.clamp(min,max).toDouble(),onChanged:changed)]);
  }
  Widget _switch(String label,bool value,ValueChanged<bool> changed)=>SwitchListTile.adaptive(contentPadding:EdgeInsets.zero,dense:true,title:Text(label,style:const TextStyle(fontSize:12,fontWeight:FontWeight.w700)),value:value,activeTrackColor:Palette.teal,onChanged:changed);

  Widget _preview(){final d=_document;final groups=PaperPages.paginate(d,answers:_answers);_previewKeys=List.generate(groups.length,(_)=>GlobalKey());
    final oversized=PaperPages.oversizedQuestions(d,answers:_answers);
    var count=1;
    final pages=<Widget>[];
    for(var i=0;i<groups.length;i++){
      final start=count;
      count+=groups[i].length;
      final width=d.landscape?PaperPages.a4Height:PaperPages.a4Width;
      final height=d.landscape?PaperPages.a4Width:PaperPages.a4Height;
      pages.add(LayoutBuilder(builder:(context,box){final available=math.min(box.maxWidth,700.0);return Container(margin:const EdgeInsets.only(bottom:15),decoration:BoxDecoration(border:Border.all(color:Palette.line),boxShadow:[BoxShadow(color:Palette.ink.withValues(alpha:.10),blurRadius:20,offset:const Offset(0,5))]),child:SizedBox(width:available,height:available*height/width,child:FittedBox(fit:BoxFit.contain,child:RepaintBoundary(key:_previewKeys[i],child:ExamPage(document:d,questions:groups[i],pageIndex:i,pageCount:groups.length,startingNumber:start,answers:_answers)))));}));
    }
    return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      _hero('04 / معاينة الطباعة','النتيجة النهائية','نفس شكل الصفحات يُستخدم للطباعة وتصدير PDF، بما فيه الأرقام والصور والهوامش.',Icons.print_outlined,Palette.sand,const Color(0xFFAE803D)),
      _panel('نسخة المعاينة',Icons.visibility_outlined,Column(children:[Row(children:[Expanded(child:_choice('نسخة الطالب',!_answers,()=>setState(()=>_answers=false),icon:Icons.school_outlined)),const SizedBox(width:8),Expanded(child:_choice('مع الإجابات',_answers,()=>setState(()=>_answers=true),icon:Icons.check_circle_outline))]),const SizedBox(height:12),Row(children:[Icon(Icons.description_outlined,color:Palette.teal,size:18),const SizedBox(width:7),Text('عدد الصفحات التقديري: ${d.digits(groups.length)}',style:const TextStyle(fontWeight:FontWeight.w700,fontSize:12)),const Spacer(),Text(d.landscape?'A4 أفقي':'A4 عمودي',style:const TextStyle(color:Palette.muted,fontSize:12))])])),
      if(oversized.isNotEmpty)Container(
        margin:const EdgeInsets.only(bottom:12),padding:const EdgeInsets.all(14),
        decoration:BoxDecoration(color:const Color(0xFFFFF0D7),borderRadius:BorderRadius.circular(16)),
        child:Text('تنبيه: السؤال/الأسئلة ${oversized.map(d.digits).join('، ')} أطول من المساحة المتاحة في صفحة A4. قسّم السؤال أو قلّل حجم الخط قبل الطباعة حتى لا يصبح صغيرًا جدًا.',
          style:const TextStyle(color:Color(0xFF754C12),fontWeight:FontWeight.w700,fontSize:12)),
      ),
      Container(padding:const EdgeInsets.all(10),margin:const EdgeInsets.only(bottom:13),decoration:BoxDecoration(color:const Color(0xFFDFE6E8),borderRadius:BorderRadius.circular(21)),child:Column(children:pages)),
      _mainButton(_busy?'جارٍ تجهيز الملف...':'طباعة الورقة',Icons.print_rounded,_busy?(){}:()=>_export(false)),
      const SizedBox(height:10),_mainButton('تصدير الورقة: Word أو PDF',Icons.file_download_outlined,_busy?(){}:_chooseExportFormat,dark:true),
      const SizedBox(height:10),const Text('تقسيم صفحات A4 تقديري. عند وجود سؤال طويل جدًا ستظهر رسالة تطلب تقسيمه قبل الطباعة. راجع المعاينة قبل الحفظ.',textAlign:TextAlign.center,style:TextStyle(color:Palette.muted,fontSize:11,height:1.5)),
    ]);
  }

  Future<void> _export(bool share) async {
    if(_busy)return;
    final oversized=PaperPages.oversizedQuestions(_document,answers:_answers);
    if(oversized.isNotEmpty){
      _notice('يتجاوز السؤال ${_document.digits(oversized.first)} مساحة A4. قسّم السؤال قبل الطباعة.');
      return;
    }
    setState(()=>_busy=true);
    try{
      await WidgetsBinding.instance.endOfFrame;
      if(share){await PrintService.sharePdf(_document,_previewKeys);}else{await PrintService.printPages(_document,_previewKeys);}
    }catch(e){_notice('تعذّر تجهيز الطباعة: $e');}
    if(mounted)setState(()=>_busy=false);
  }
}
