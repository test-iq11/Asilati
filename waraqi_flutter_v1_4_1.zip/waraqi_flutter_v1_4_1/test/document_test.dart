import 'dart:io';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:waraqi_studio/services/paper_archive.dart';
import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;
import 'package:waraqi_studio/services/ocr_crop_service.dart';
import 'package:waraqi_studio/screens/crop_capture_screen.dart';
import 'dart:typed_data';
import 'package:waraqi_studio/services/ocr_text_tools.dart';
import 'package:waraqi_studio/services/print_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:waraqi_studio/models/paper_document.dart';
import 'package:waraqi_studio/widgets/paper_pages.dart';

void main() {
  test('PaperDocument unnamed constructor is available across app entrypoints', () {
    final document = PaperDocument();
    expect(document.title, isNotEmpty);
    expect(document.questions, isNotEmpty);
    final fromEmptyJson = PaperDocument.fromJson(<String, dynamic>{});
    expect(fromEmptyJson.title, document.title);
    expect(fromEmptyJson.questions.length, document.questions.length);
    expect(PaperDocument.decode(document.encode()).title, document.title);
  });

  test('Arabic and English digits normalize across all source scripts', () {
    expect(formatDigits('س 1: 45.67 و ۱۲٣', DigitStyle.arabic), 'س ١: ٤٥.٦٧ و ١٢٣');
    expect(formatDigits('س ١: ٤٥.٦٧ و ۱۲٣', DigitStyle.english), 'س 1: 45.67 و 123');
    expect(formatDigits('رقم ١٢٣ 123 ۱۲۳', DigitStyle.english), 'رقم 123 123 123');
  });

  test('Arabic and English keyboard grades parse as finite numbers', () {
    expect(parseLocalizedNumber('١٢٫٥'), 12.5);
    expect(parseLocalizedNumber('12.5'), 12.5);
    expect(parseLocalizedNumber('۱۲٫۵'), 12.5);
    expect(parseLocalizedNumber('NaN'), isNull);
    expect(parseLocalizedNumber('Infinity'), isNull);
  });

  test('separate top and bottom A4 margins persist without clamping', () {
    final d = PaperDocument();
    d.topMarginMm = 0;
    d.bottomMarginMm = 27;
    d.digitStyle = DigitStyle.english;
    final copy = PaperDocument.decode(d.encode());
    expect(copy.topMarginMm, 0);
    expect(copy.bottomMarginMm, 27);
    expect(copy.digits('السؤال ٥: ٣+٢'), 'السؤال 5: 3+2');
    expect(PaperPages.mm(10), closeTo(28.346, .002));
  });

  test('full photo cropping happens after capture in photo coordinates', () {
    final full = img.Image(width: 1000, height: 800);
    final centered = OcrCropService.crop(full,
      centerX: .5, centerY: .5, widthFraction: .5, heightFraction: .25);
    expect(centered.width, 500);
    expect(centered.height, 200);
    final entire = OcrCropService.crop(full,
      centerX: .5, centerY: .5, widthFraction: 1, heightFraction: 1);
    expect(entire.width, full.width);
    expect(entire.height, full.height);
    final nearEdge = OcrCropService.crop(full,
      centerX: .95, centerY: .98, widthFraction: .6, heightFraction: .6);
    expect(nearEdge.width, 600);
    expect(nearEdge.height, 480);
  });

  test('optional student fields and footer teacher survive save/load', () {
    final d = PaperDocument()
      ..showStudentNameField = false
      ..showSectionField = false
      ..teacherName = 'سارة أحمد';
    final restored = PaperDocument.decode(d.encode());
    expect(restored.showStudentNameField, isFalse);
    expect(restored.showSectionField, isFalse);
    expect(restored.teacherName, 'سارة أحمد');
    // Old saved documents get the documented defaults for new fields.
    final oldData = d.toJson()
      ..remove('teacherName')
      ..remove('showStudentNameField')
      ..remove('showSectionField');
    final legacy = PaperDocument.fromJson(oldData);
    expect(legacy.showStudentNameField, isTrue);
    expect(legacy.showSectionField, isTrue);
    expect(legacy.teacherName, '');
  });

  testWidgets('optional student fields disappear and teacher appears in page footer', (tester) async {
    final d = PaperDocument()
      ..showStudentNameField = false
      ..showSectionField = false
      ..teacherName = 'سارة أحمد'
      ..questions = [PaperQuestion(id: 'q', text: 'سؤال تجريبي')];
    tester.view.physicalSize = const Size(1200, 1700);
    tester.view.devicePixelRatio = 1;
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: Center(
      child: ExamPage(document: d, questions: d.questions, pageIndex: 0,
        pageCount: 1, startingNumber: 1, answers: false),
    ))));
    expect(tester.takeException(), isNull);
    expect(find.text('اسم الطالب:'), findsNothing);
    expect(find.text('الصف/الشعبة:'), findsNothing);
    expect(find.text('معلم المادة: سارة أحمد'), findsOneWidget);
  });

  test('OCR inserts editable question text without embedding source photo', () {
    final d = PaperDocument();
    final q = d.questions.first;
    expect(q.insertExtractedText('أوجد ٣ × 4', append: false), isTrue);
    expect(q.insertExtractedText('ثم أجب عن ٥', append: true), isTrue);
    expect(q.insertExtractedText('   ', append: false), isFalse);
    expect(q.elements, isEmpty);
    final copy = PaperDocument.decode(d.encode());
    expect(copy.questions.first.text, 'أوجد ٣ × 4\nثم أجب عن ٥');
    expect(copy.questions.first.elements, isEmpty);
    expect(copy.digits(copy.questions.first.text), 'أوجد ٣ × ٤\nثم أجب عن ٥');
  });

  test('separately inserted illustrative images survive persistence', () {
    final d = PaperDocument();
    d.questions.first.elements.add(
      PaperElement(id: 'figure', kind: 'image', imagePath: '/test/figure.jpg'),
    );
    final copy = PaperDocument.decode(d.encode());
    expect(copy.questions.first.elements.first.imagePath, '/test/figure.jpg');
    expect(copy.questions.first.branches.length, 2);
  });

  test('pagination always includes a page, even with no questions', () {
    final d = PaperDocument()..questions = [];
    expect(PaperPages.paginate(d, answers: false).length, 1);
  });

  test('question headings and branches share one number style', () {
    final d = PaperDocument();
    for (final style in DigitStyle.values) {
      d.digitStyle = style;
      final heading = questionPrintLabel(d, 12, 'أوجد ٥ + 2');
      final branch = branchPrintLabel(d, 3, '٣ + 4');
      if (style == DigitStyle.english) {
        expect(heading, 'س 12: أوجد 5 + 2');
        expect(branch, '(3) 3 + 4');
      } else {
        expect(heading, 'س ١٢: أوجد ٥ + ٢');
        expect(branch, '(٣) ٣ + ٤');
      }
    }
  });

  test('digits stay consistent after saving and reloading', () {
    final d = PaperDocument()
      ..digitStyle = DigitStyle.english
      ..questions = [PaperQuestion(id: 'q01', text: 'أوجد ٥ + ٢',
        branches: ['٣ + 4', '۶ × 7'])];
    final restored = PaperDocument.decode(d.encode());
    final q = restored.questions.single;
    expect(questionPrintLabel(restored, 1, q.text), 'س 1: أوجد 5 + 2');
    expect(branchPrintLabel(restored, 1, q.branches.first), '(1) 3 + 4');
    expect(branchPrintLabel(restored, 2, q.branches.last), '(2) 6 × 7');
  });

  test('pagination keeps all visible questions and excludes hidden', () {
    final d = PaperDocument()
      ..questions = List.generate(16, (i) => PaperQuestion(
        id: 'q$i', text: 'سؤال رقم $i اختبار تنسيق الصفحات', points: 5));
    d.questions[8].visible = false;
    final pages = PaperPages.paginate(d, answers: false);
    expect(pages, isNotEmpty);
    final ids = pages.expand((page) => page).map((q) => q.id).toList();
    expect(ids.length, 15);
    expect(ids, d.questions.where((q) => q.visible).map((q) => q.id).toList());
  });

  test('oversized questions are detected before printing', () {
    final d = PaperDocument()
      ..questions = [PaperQuestion(id: 'too-long',
        text: List.filled(500, 'هذا النص طويل جداً').join(' '))];
    expect(PaperPages.oversizedQuestions(d, answers: false), [1]);
    d.questions.single.text = 'سؤال قصير';
    expect(PaperPages.oversizedQuestions(d, answers: false), isEmpty);
  });

  testWidgets('question numbering and body render with the same digit setting', (tester) async {
    final d = PaperDocument()
      ..digitStyle = DigitStyle.english
      ..showRules = false
      ..questions = [PaperQuestion(id: 'q1', text: 'أوجد ٥ + 2', branches: ['٣ + 4'])];
    tester.view.physicalSize = const Size(1200, 1700);
    tester.view.devicePixelRatio = 1;
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    Widget page() => MaterialApp(home: Scaffold(body: Center(
      child: ExamPage(document: d, questions: d.questions, pageIndex: 0,
        pageCount: 1, startingNumber: 1, answers: false),
    )));
    String printedText(String key) => tester.widget<Text>(
      find.byKey(ValueKey<String>(key)),
    ).data!;
    await tester.pumpWidget(page());
    expect(tester.takeException(), isNull,
      reason: 'A4 header and identity fields must not overflow horizontally');
    // Inspect the actual Text widgets that are printed, not an unrelated label.
    expect(printedText('exam-question-1'), 'س 1: أوجد 5 + 2');
    expect(printedText('exam-branch-1-1'), '(1) 3 + 4');
    d.digitStyle = DigitStyle.arabic;
    await tester.pumpWidget(page());
    expect(tester.takeException(), isNull);
    expect(printedText('exam-question-1'), 'س ١: أوجد ٥ + ٢');
    expect(printedText('exam-branch-1-1'), '(١) ٣ + ٤');
  });
  testWidgets('student identity lines fit A4 in both orientations and supported margins', (tester) async {
    final d = PaperDocument()
      ..showRules = false
      ..questions = [PaperQuestion(id: 'test', text: 'أوجد ٥ + ٢')];
    tester.view.physicalSize = const Size(1300, 1800);
    tester.view.devicePixelRatio = 1;
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    Widget page() => MaterialApp(home: Scaffold(body: Center(
      child: ExamPage(document: d, questions: d.questions, pageIndex: 0,
        pageCount: 1, startingNumber: 1, answers: false),
    )));
    for (final landscape in [false, true]) {
      for (final sideMargin in [5.0, 14.0, 30.0]) {
        for (final font in [11.0, 15.0, 23.0]) {
          d.landscape = landscape;
          d.sideMarginMm = sideMargin;
          d.fontSize = font;
          await tester.pumpWidget(page());
          expect(tester.takeException(), isNull,
            reason: 'Render overflow on A4: landscape=$landscape '
              'sideMargin=$sideMargin fontSize=$font');
          expect(find.byType(ExamPage), findsOneWidget);
        }
      }
    }
  });

  testWidgets('A4 header and footer cannot overrun the page at extreme settings', (tester) async {
    final d = PaperDocument()
      ..landscape = true
      ..sideMarginMm = 30
      ..fontSize = 23
      ..headerGapMm = 28
      ..teacherName = 'معلم مادة الرياضيات للصف الخامس الابتدائي'
      ..topNote = 'اقرأ السؤال بعناية ثم أجب عن جميع الأسئلة مع مراعاة الخطوات'
      ..school = 'مدرسة الاختبار الابتدائية الطويلة الاسم جداً'
      ..questions = [PaperQuestion(id: 'fit-test', text: 'أوجد ٥ + ٢')];
    tester.view.physicalSize = const Size(1300, 1800);
    tester.view.devicePixelRatio = 1;
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    Widget page() => MaterialApp(home: Scaffold(body: Center(
      child: ExamPage(document: d, questions: d.questions, pageIndex: 0,
        pageCount: 1, startingNumber: 1, answers: false),
    )));
    for (final margins in [(top: 8.0, bottom: 8.0), (top: 45.0, bottom: 45.0)]) {
      d.topMarginMm = margins.top;
      d.bottomMarginMm = margins.bottom;
      await tester.pumpWidget(page());
      expect(tester.takeException(), isNull,
        reason: 'A4 bounds exceeded with large header/footer '
          'top=${margins.top} bottom=${margins.bottom}');
      expect(find.text('معلم المادة: ${d.teacherName}'), findsOneWidget);
      expect(find.byType(ExamPage), findsOneWidget);
    }
  });

  test('Arabic OCR cleanup drops suspect English words without losing any digits', () {
    const source = 'مساحة القارة ١٢٣٤ و 5678 و ۱۲۳ ET ey x\n'
        'قدر ناتج ٤٥ + ٣٢ = ٧٧';
    final cleaned = OcrTextTools.clean(source, arabicOnly: true);
    expect(cleaned, 'مساحة القارة ١٢٣٤ و 5678 و ۱۲۳ x\nقدر ناتج ٤٥ + ٣٢ = ٧٧');
    expect(cleaned, contains('١٢٣٤'));
    expect(cleaned, contains('5678'));
    expect(cleaned, contains('۱۲۳'));
    expect(OcrTextTools.hasLatinWords(source), isTrue);
    expect(OcrTextTools.hasDigits(source), isTrue);
    final bilingual = OcrTextTools.clean(source, arabicOnly: false);
    expect(bilingual, contains('ET ey'));
  });

  test('OCR image preparation preserves crop proportions and can be decoded', () {
    final sample = img.Image(width: 300, height: 120);
    final prepared = OcrTextTools.prepareForOcr(img.encodePng(sample));
    final decoded = img.decodeImage(prepared);
    expect(decoded, isNotNull);
    expect(decoded!.width, 750);
    expect(decoded.height, 300);
  });

  test('section titles and exam templates survive serialization and cloning data', () {
    final d = PaperDocument()
      ..paperLayout = 'arabicLines'
      ..questions = [PaperQuestion(id: 'rules', text: 'استخرج المبتدأ والخبر',
        sectionTitle: 'القواعد', points: 10)];
    final saved = PaperDocument.decode(d.encode());
    expect(saved.paperLayout, 'arabicLines');
    expect(saved.questions.single.sectionTitle, 'القواعد');
    final oldDocument = d.toJson()..remove('paperLayout');
    expect(PaperDocument.fromJson(oldDocument).paperLayout, 'mathFrame');
  });

  test('editable Word format includes section headings and separated questions', () async {
    final d = PaperDocument()
      ..paperLayout = 'arabicLines'
      ..teacherName = 'علي'
      ..questions = [PaperQuestion(id: 'one', text: 'أعرب الآتي',
        sectionTitle: 'القواعد')];
    final html = await PrintService.generateWordHtml(d, answers: false);
    expect(html, contains('القواعد'));
    expect(html, contains('arabic-lines'));
    expect(html, contains('border-bottom:1px solid #444'));
    expect(html, contains('معلم المادة: علي'));
    expect(html, contains('أعرب الآتي'));
  });


  test('four independent crop corners cannot cross or leave photo', () {
    final first = CropQuad.inset(.1);
    expect(first.isValid, isTrue);
    final moved = first.moveCorner(0, const Offset(.04, .06));
    expect(moved.points[0], const Offset(.04, .06));
    for (var index = 1; index < 4; index++) {
      expect(moved.points[index], first.points[index],
          reason: 'Moving one corner must not drag the other three');
    }
    final rejected = moved.moveCorner(1, const Offset(.02, .96));
    expect(rejected.points, moved.points,
        reason: 'Crossed or concave quadrilaterals must be rejected');
    final clamped = moved.moveCorner(0, const Offset(-20, -20));
    expect(clamped.points[0], const Offset(0, 0));
    expect(clamped.isValid, isTrue);
  });

  test('independent edge, center move and clamp preserve a valid crop', () {
    final initial = CropQuad.inset(.1);
    final top = initial.moveEdge(0, const Offset(0, -.04));
    expect(top.points[0].dy, closeTo(.06, 0.00001));
    expect(top.points[1].dy, closeTo(.06, 0.00001));
    expect(top.points[2], initial.points[2]);
    expect(top.points[3], initial.points[3]);
    final translated = top.translate(const Offset(0.8, 0.8));
    expect(translated.isValid, isTrue);
    expect(translated.points.every((p) => p.dx <= 1 && p.dy <= 1), isTrue);
    expect(initial.moveEdge(0, const Offset(0, .95)).points, initial.points,
        reason: 'Sides cannot cross their opposite edges');
  });

  test('free four-corner crop rectifies source pixels and bounds output size', () {
    final photo = img.Image(width: 300, height: 200);
    final rectangle = CropQuad.fromPoints(const [
      Offset(.1, .1), Offset(.9, .1), Offset(.9, .9), Offset(.1, .9),
    ]);
    final exact = OcrCropService.cropQuadrilateral(photo, rectangle);
    expect(exact.width, 240);
    expect(exact.height, 160);
    final skewed = CropQuad.fromPoints(const [
      Offset(.10, .05), Offset(.86, .14), Offset(.95, .88), Offset(.17, .94),
    ]);
    final corrected = OcrCropService.cropQuadrilateral(photo, skewed);
    expect(corrected.width, greaterThan(100));
    expect(corrected.height, greaterThan(100));
    expect(corrected.width, lessThanOrEqualTo(300));
    expect(corrected.height, lessThanOrEqualTo(200));
  });

  test('crop after photo decoding preserves original dimensions', () {
    final photo = img.Image(width: 400, height: 220);
    final bytes = Uint8List.fromList(img.encodeJpg(photo));
    final preview = OcrCropService.previewEncoded(bytes);
    expect(preview['width'], 400);
    expect(preview['height'], 220);
    expect(img.decodeImage(preview['jpeg']! as Uint8List), isNotNull);
    final cropped = OcrCropService.cropEncoded(<String, Object>{
      'bytes': bytes,
      'points': <double>[.1, .1, .9, .1, .9, .9, .1, .9],
    });
    final decoded = img.decodeImage(cropped);
    expect(decoded, isNotNull);
    expect(decoded!.width, 320);
    expect(decoded.height, 176);
  });

  testWidgets('crop editor exposes independent handles without screen overflow', (tester) async {
    final image = Uint8List.fromList(img.encodeJpg(img.Image(width: 240, height: 420)));
    tester.view.physicalSize = const Size(410, 900);
    tester.view.devicePixelRatio = 1;
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    await tester.pumpWidget(MaterialApp(home: CropCaptureScreen(
      fromCamera: false, testPhotoBytes: image,
    )));
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
    for (var i = 0; i < 4; i++) {
      expect(find.byKey(ValueKey('crop-corner-$i')), findsOneWidget);
      expect(find.byKey(ValueKey('crop-edge-$i')), findsOneWidget);
    }
    expect(find.byKey(const ValueKey('crop-center-handle')), findsOneWidget);
    expect(find.text('قص واستخراج النص'), findsOneWidget);
    tester.view.physicalSize = const Size(320, 740);
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull,
        reason: 'Crop editor controls must fit narrow Android displays');
  });

  test('multiple papers have durable independent IDs and page breaks', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    final archive = PaperArchive();
    final first = PaperDocument()..title = 'اختبار أول'..questions = [
      PaperQuestion(id: 'a', text: 'السؤال الأول'),
      PaperQuestion(id: 'b', text: 'السؤال الثاني', pageBreakBefore: true),
    ];
    final second = PaperDocument()..title = 'اختبار ثان';
    await archive.saveDocument(first);
    await archive.saveDocument(second);
    final found = await archive.documents();
    expect(found.length, 2);
    expect(found.first.title, 'اختبار ثان');
    expect(found.last.documentId, first.documentId);
    expect(found.last.questions.last.pageBreakBefore, isTrue);
    final pages = PaperPages.paginate(first, answers: false);
    expect(pages.length, 2);
    expect(pages.first.single.text, 'السؤال الأول');
    expect(pages.last.single.text, 'السؤال الثاني');
    archive.dispose();
  });

  test('bank copies questions without linking editing state', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    final archive = PaperArchive();
    final original = PaperQuestion(id: 'q', text: 'احسب ١ + ٢', branches: ['أ', 'ب']);
    await archive.addToBank(original, subject: 'الرياضيات', grade: 'الخامس');
    original.text = 'تغيير خارج البنك';
    original.branches[0] = 'تعديل';
    final saved = await archive.bank();
    expect(saved.length, 1);
    expect(saved.first.question.text, 'احسب ١ + ٢');
    expect(saved.first.question.branches.first, 'أ');
    await archive.removeFromBank(saved.first.id);
    expect(await archive.bank(), isEmpty);
    archive.dispose();
  });

  test('backup round trip merges saved documents and question bank', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    final archive = PaperArchive();
    final source = PaperDocument()..title = 'نموذج رياضيات'
        ..questions = [PaperQuestion(id: 'q1', text: 'جد الناتج')];
    await archive.saveDocument(source);
    await archive.addToBank(source.questions.first, subject: 'رياضيات', grade: 'الخامس');
    final bytes = await archive.exportBackup();
    final imported = await archive.importBackup(bytes);
    expect(imported, 1);
    final docs = await archive.documents();
    expect(docs.length, 2);
    expect(docs[0].documentId, isNot(docs[1].documentId));
    expect((await archive.bank()).length, 2);
    archive.dispose();
  });

  test('backup restores real image attachments into app documents directory', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    final folder = await Directory.systemTemp.createTemp('waraqi_backup_test_');
    addTearDown(() async {
      if (await folder.exists()) await folder.delete(recursive: true);
    });
    final originalImage = File('${folder.path}/sample.png');
    final imageBytes = Uint8List.fromList(img.encodePng(
        img.Image(width: 24, height: 12)));
    await originalImage.writeAsBytes(imageBytes);
    final archive = PaperArchive(documentsDirectory: () async => folder);
    final original = PaperDocument()
      ..title = 'مستند بصور'
      ..logoPath = originalImage.path;
    await archive.saveDocument(original);
    final backup = await archive.exportBackup();
    final count = await archive.importBackup(backup);
    expect(count, 1);
    final docs = await archive.documents();
    expect(docs.length, 2);
    final restoredPath = docs.first.logoPath;
    expect(restoredPath, isNotNull);
    expect(restoredPath, isNot(originalImage.path));
    expect(restoredPath!.endsWith('.png'), isTrue);
    expect(await File(restoredPath).readAsBytes(), orderedEquals(imageBytes));
    expect(docs.last.logoPath, originalImage.path);
    archive.dispose();
  });

  test('backup rejects arbitrary or malformed files without deleting papers', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    final archive = PaperArchive();
    await archive.saveDocument(PaperDocument());
    await expectLater(
      archive.importBackup(Uint8List.fromList([123, 125])),
      throwsFormatException,
    );
    expect((await archive.documents()).length, 1);
    archive.dispose();
  });

  test('new IDs remain unique during rapid backup imports', () {
    final ids = List.generate(2000, (_) => newId());
    expect(ids.toSet().length, ids.length);
  });

  test('Word numbering excludes hidden questions and avoids first-page breaks', () async {
    final doc = PaperDocument()..questions = [
      PaperQuestion(id: 'hidden', text: 'نص مخفي', visible: false),
      PaperQuestion(id: 'first', text: 'سؤال مرئي', pageBreakBefore: true),
    ];
    final html = await PrintService.generateWordHtml(doc, answers: false);
    expect(html.contains('نص مخفي'), isFalse);
    expect(html.contains('س ١: سؤال مرئي'), isTrue);
    expect(html.contains('style="page-break-before:always"'), isFalse);
  });

}
