# إصلاح فشل GitHub Actions — ورقتي 1.4.1

## سجل الفشل الذي أرسله المستخدم

- `flutter analyze`: **No issues found!**
- `flutter test`: فشل اختباران وفق سجل المستخدم: (`crop editor exposes independent handles without screen overflow`) و(`backup round trip merges saved documents and question bank`).
- الاختبار الأول: `A RenderFlex overflowed by 22 pixels on the right` عند نقل عرض النافذة إلى 320 نقطة.
- الاختبار الثاني: `MissingPluginException getApplicationDocumentsDirectory` عند استيراد نسخة لا تحتوي على صور.

## التعديلات

1. أدوات التحريك الدقيق تعرض في صفين دون تغيير وظائف الأزرار في الهواتف الضيقة، وصف واحد على الهواتف الأوسع.
2. `PaperArchive.importBackup` يطلب مجلد المستندات فقط إذا كانت هناك صور لاستعادتها.
3. خيار حقن مسار المستندات في `PaperArchive` للاختبارات فقط مع بقاء التطبيق الفعلي على `path_provider`.
4. اختبار جديد لاستعادة صور PNG والتحقق من المسار والبيانات الأصلية وبقاء المستند السابق.
5. رفع الإصدار إلى `1.4.1+15` وتحديث ملف GitHub Actions وأسماء الملفات الناتجة.

## فحوص التنفيذ

- فحص أولي: `python3 tool/source_preflight.py`.
- التحقق من ZIP: `unzip -tq waraqi_flutter_v1_4_1.zip`.
- على GitHub: `flutter analyze` ثم `flutter test --reporter expanded` ثم `flutter build apk --release --no-pub`.

**هذه نسخة معالجة بالمصدر. لا يُعد نجاح الاختبار على الهاتف أو إصدار APK مؤكدًا قبل اجتياز GitHub Actions.**
