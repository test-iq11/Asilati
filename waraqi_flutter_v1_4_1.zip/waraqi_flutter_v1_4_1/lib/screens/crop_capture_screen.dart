import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../services/ocr_crop_service.dart';
import '../theme.dart';

/// Capture the full frame first, then independently adjust all four corners,
/// edges, and the position of the selection. Pinching/panning only changes the
/// VIEW; normalized coordinates are mapped back to the full original photo.
class CropCaptureScreen extends StatefulWidget {
  const CropCaptureScreen({super.key, required this.fromCamera,
    this.testPhotoBytes});

  final bool fromCamera;
  @visibleForTesting
  final Uint8List? testPhotoBytes;

  @override
  State<CropCaptureScreen> createState() => _CropCaptureScreenState();
}

class _CropCaptureScreenState extends State<CropCaptureScreen> {
  CameraController? _camera;
  Uint8List? _fullPhotoBytes;
  Uint8List? _displayJpeg;
  Size? _photoDimensions;
  String? _error;
  bool _loading = true;
  bool _processing = false;

  final _photoKey = GlobalKey();
  final _transformation = TransformationController();
  CropQuad _quad = CropQuad.inset();
  CropQuad? _dragOrigin;
  Offset? _dragSceneOrigin;
  Size _sceneSize = Size.zero;
  Size _viewportSize = Size.zero;
  int _activeCorner = 0;
  bool get _cropping =>
      _fullPhotoBytes != null && _displayJpeg != null && _photoDimensions != null;

  @override
  void initState() {
    super.initState();
    _transformation.addListener(_onZoomChanged);
    _initialize();
  }

  void _onZoomChanged() {
    if (mounted && _cropping) setState(() {});
  }

  Future<void> _initialize() async {
    try {
      if (widget.testPhotoBytes != null) {
        await _loadPhotoBytes(widget.testPhotoBytes!);
      } else if (widget.fromCamera) {
        final cameras = await availableCameras();
        if (cameras.isEmpty) throw StateError('لا توجد كاميرا متاحة');
        final back = cameras.where((c) => c.lensDirection == CameraLensDirection.back);
        final device = back.isEmpty ? cameras.first : back.first;
        final controller = CameraController(
          device,
          ResolutionPreset.high,
          enableAudio: false,
          imageFormatGroup: ImageFormatGroup.jpeg,
        );
        await controller.initialize();
        if (!mounted) {
          await controller.dispose();
          return;
        }
        _camera = controller;
      } else {
        final photo = await ImagePicker().pickImage(
            source: ImageSource.gallery, imageQuality: 100);
        if (photo == null) {
          if (mounted) Navigator.of(context).pop();
          return;
        }
        await _loadPhoto(File(photo.path));
      }
    } catch (error) {
      _error = 'تعذّر فتح ${widget.fromCamera ? 'الكاميرا' : 'الصورة'}: $error';
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _loadPhoto(File file) async {
    await _loadPhotoBytes(await file.readAsBytes());
  }

  Future<void> _loadPhotoBytes(Uint8List bytes) async {
    // The injectable widget-test image stays synchronous so tests do not
    // depend on the scheduler of another isolate. Production uses compute.
    final preview = widget.testPhotoBytes != null
        ? OcrCropService.previewEncoded(bytes)
        : await compute<Uint8List, Map<String, Object>>(
            OcrCropService.previewEncoded, bytes);
    if (!mounted) return;
    setState(() {
      _fullPhotoBytes = bytes;
      _displayJpeg = preview['jpeg']! as Uint8List;
      _photoDimensions = Size(
        (preview['width']! as int).toDouble(),
        (preview['height']! as int).toDouble(),
      );
      _quad = CropQuad.inset();
      _activeCorner = 0;
      _error = null;
    });
    _transformation.value = Matrix4.identity();
  }

  Future<void> _takeFullPhoto() async {
    final camera = _camera;
    if (_processing || camera == null || !camera.value.isInitialized) return;
    setState(() => _processing = true);
    try {
      final photo = await camera.takePicture();
      final temporary = File(photo.path);
      try {
        await _loadPhoto(temporary);
      } finally {
        if (await temporary.exists()) await temporary.delete();
      }
    } catch (error) {
      _reportError('تعذّر تصوير الورقة: $error');
    } finally {
      if (mounted) setState(() => _processing = false);
    }
  }

  void _retake() {
    if (_processing) return;
    setState(() {
      _fullPhotoBytes = null;
      _displayJpeg = null;
      _photoDimensions = null;
      _quad = CropQuad.inset();
    });
    _transformation.value = Matrix4.identity();
  }

  Future<void> _rotatePhoto() async {
    final bytes = _fullPhotoBytes;
    if (_processing || bytes == null) return;
    setState(() => _processing = true);
    try {
      final rotated = await compute<Uint8List, Uint8List>(
          OcrCropService.rotateEncoded, bytes);
      await _loadPhotoBytes(rotated);
    } catch (error) {
      _reportError('تعذّر تدوير الصورة: $error');
    } finally {
      if (mounted) setState(() => _processing = false);
    }
  }

  Future<void> _confirmCrop() async {
    final bytes = _fullPhotoBytes;
    if (_processing || bytes == null) return;
    if (!_quad.isValid) {
      _reportError('حدود القص غير صحيحة، عدّل الزوايا قبل المتابعة');
      return;
    }
    setState(() => _processing = true);
    try {
      final points = <double>[
        for (final point in _quad.points) ...[point.dx, point.dy],
      ];
      // Pixel operations happen off the UI isolate. Zoom does not affect OCR.
      final cropped = await compute<Map<String, Object>, Uint8List>(
          OcrCropService.cropEncoded, <String, Object>{
        'bytes': bytes,
        'points': points,
      });
      if (mounted) Navigator.of(context).pop(cropped);
    } catch (error) {
      _reportError('تعذّر قص الصورة: $error');
    } finally {
      if (mounted) setState(() => _processing = false);
    }
  }

  void _reportError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
    );
  }

  void _resetCrop() {
    setState(() => _quad = CropQuad.inset());
  }

  void _fullCrop() {
    // Exact full-photo selection; the partially visible handles still respond.
    setState(() => _quad = CropQuad.inset(0));
  }

  void _straightenCrop() {
    final p = _quad.points;
    final left = p.map((v) => v.dx).reduce(math.min);
    final right = p.map((v) => v.dx).reduce(math.max);
    final top = p.map((v) => v.dy).reduce(math.min);
    final bottom = p.map((v) => v.dy).reduce(math.max);
    final straight = CropQuad.fromPoints(<Offset>[
      Offset(left, top), Offset(right, top),
      Offset(right, bottom), Offset(left, bottom),
    ]);
    setState(() => _quad = straight);
  }

  Offset? _scenePoint(Offset global) {
    final box = _photoKey.currentContext?.findRenderObject();
    if (box is! RenderBox || !box.hasSize) return null;
    return box.globalToLocal(global);
  }

  void _beginMove(DragStartDetails details, {int? corner, int? edge}) {
    final point = _scenePoint(details.globalPosition);
    if (point == null) return;
    _dragSceneOrigin = point;
    _dragOrigin = _quad;
    if (corner != null) setState(() => _activeCorner = corner);
  }

  void _updateMove(DragUpdateDetails details, {int? corner, int? edge}) {
    final start = _dragSceneOrigin;
    final original = _dragOrigin;
    final position = _scenePoint(details.globalPosition);
    if (start == null || original == null || position == null ||
        _sceneSize.width <= 0 || _sceneSize.height <= 0) return;
    final motion = Offset((position.dx - start.dx) / _sceneSize.width,
        (position.dy - start.dy) / _sceneSize.height);
    CropQuad next;
    if (corner != null) {
      next = original.moveCorner(corner, original.points[corner] + motion);
    } else if (edge != null) {
      next = original.moveEdge(edge, motion);
    } else {
      next = original.translate(motion);
    }
    if (next != _quad && mounted) setState(() => _quad = next);
  }

  void _finishMove(DragEndDetails details) {
    _dragOrigin = null;
    _dragSceneOrigin = null;
  }

  void _nudge(int x, int y) {
    if (_processing) return;
    final zoom = _transformation.value.getMaxScaleOnAxis();
    // A nudge of around one screen pixel is small even at high zoom.
    final delta = Offset(x * 1.5 / math.max(1, _sceneSize.width * zoom),
        y * 1.5 / math.max(1, _sceneSize.height * zoom));
    setState(() => _quad = _quad.moveCorner(
        _activeCorner, _quad.points[_activeCorner] + delta));
  }

  void _changeZoom(bool zoomIn) {
    final scale = _transformation.value.getMaxScaleOnAxis();
    final updated = (scale * (zoomIn ? 1.6 : .625)).clamp(1.0, 7.0).toDouble();
    final center = Offset(_viewportSize.width / 2, _viewportSize.height / 2);
    final anchor = _transformation.toScene(center);
    final transform = Matrix4.diagonal3Values(updated, updated, 1);
    transform.setEntry(0, 3, center.dx - anchor.dx * updated);
    transform.setEntry(1, 3, center.dy - anchor.dy * updated);
    _transformation.value = transform;
  }

  @override
  void dispose() {
    _camera?.dispose();
    _transformation.removeListener(_onZoomChanged);
    _transformation.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF111B23),
      appBar: AppBar(
        backgroundColor: const Color(0xFF111B23),
        foregroundColor: Colors.white,
        title: Text(_cropping ? 'قصّ الصورة بدقة' : 'تصوير الورقة كاملة'),
        actions: [
          if (_cropping)
            IconButton(tooltip: 'إعادة ضبط التكبير',
              onPressed: () => _transformation.value = Matrix4.identity(),
              icon: const Icon(Icons.center_focus_strong_rounded)),
          IconButton(tooltip: 'إغلاق',
              onPressed: () => Navigator.of(context).pop(),
              icon: const Icon(Icons.close_rounded)),
        ],
      ),
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
            child: Text(
              _cropping
                  ? 'اسحب الدوائر الأربع للزوايا والمقابض على الجوانب. حرّك الدائرة الوسطى لنقل الإطار، وكبّر بإصبعين لضبط الحروف بدقة.'
                  : 'صوّر الورقة كاملة. بعد التصوير ستتمكن من ضبط الزوايا الأربع والقص بحرية.',
              style: const TextStyle(color: Colors.white70, fontSize: 12.5, height: 1.45),
              textAlign: TextAlign.center,
            ),
          ),
          Expanded(child: LayoutBuilder(builder: (context, box) {
            if (_loading) {
              return const Center(child: CircularProgressIndicator());
            }
            if (_error != null) {
              return Center(child: Padding(padding: const EdgeInsets.all(20),
                child: Text(_error!, style: const TextStyle(color: Colors.white),
                    textAlign: TextAlign.center)));
            }
            if (_cropping) return _cropEditor(Size(box.maxWidth, box.maxHeight));
            if (_camera == null || !_camera!.value.isInitialized) {
              return const Center(child: CircularProgressIndicator());
            }
            return _cameraPreview();
          })),
          _bottomPanel(),
        ]),
      ),
    );
  }

  Widget _cameraPreview() {
    final controller = _camera!;
    return ClipRect(child: LayoutBuilder(builder: (context, box) {
      final size = controller.value.previewSize!;
      final portrait = Size(size.height, size.width);
      return Center(child: FittedBox(fit: BoxFit.contain,
          child: SizedBox(width: portrait.width, height: portrait.height,
              child: CameraPreview(controller))));
    }));
  }

  Widget _cropEditor(Size viewport) {
    _viewportSize = viewport;
    final photo = _photoDimensions!;
    if (viewport.width <= 0 || viewport.height <= 0) {
      return const SizedBox.shrink();
    }
    final scale = math.min((viewport.width - 12) / photo.width,
        (viewport.height - 12) / photo.height);
    final width = photo.width * scale;
    final height = photo.height * scale;
    _sceneSize = Size(width, height);
    final zoom = _transformation.value.getMaxScaleOnAxis();
    final handleSize = 48.0 / zoom;
    final edgeSize = 40.0 / zoom;
    final p = _quad.points;
    final actual = p.map((point) => Offset(point.dx * width, point.dy * height)).toList();
    final middle = Offset(_quad.center.dx * width, _quad.center.dy * height);

    return ClipRect(child: InteractiveViewer(
      transformationController: _transformation,
      alignment: Alignment.center,
      constrained: false,
      minScale: 1,
      maxScale: 7,
      boundaryMargin: const EdgeInsets.all(150),
      child: SizedBox(
        key: _photoKey,
        width: width,
        height: height,
        child: Stack(clipBehavior: Clip.none, children: [
          Positioned.fill(child: Image.memory(_displayJpeg!,
              fit: BoxFit.fill, gaplessPlayback: true)),
          Positioned.fill(child: IgnorePointer(child: CustomPaint(
              painter: _QuadOverlay(p: actual)))),
          for (var i = 0; i < 4; i++)
            _dragHandle(
              key: ValueKey('crop-corner-$i'),
              position: actual[i],
              size: handleSize,
              accent: _activeCorner == i,
              label: '',
              corner: i,
            ),
          for (var i = 0; i < 4; i++)
            _dragHandle(
              key: ValueKey('crop-edge-$i'),
              position: Offset((actual[i].dx + actual[(i + 1) % 4].dx) / 2,
                  (actual[i].dy + actual[(i + 1) % 4].dy) / 2),
              size: edgeSize,
              accent: false,
              label: '—',
              edge: i,
            ),
          _dragHandle(
            key: const ValueKey('crop-center-handle'),
            position: middle,
            size: handleSize,
            accent: false,
            label: '✥',
          ),
        ]),
      ),
    ));
  }

  Widget _dragHandle({
    required Key key,
    required Offset position,
    required double size,
    required bool accent,
    required String label,
    int? corner,
    int? edge,
  }) {
    return Positioned(
      left: position.dx - size / 2,
      top: position.dy - size / 2,
      width: size,
      height: size,
      child: GestureDetector(
        key: key,
        behavior: HitTestBehavior.opaque,
        onTap: corner == null ? null : () => setState(() => _activeCorner = corner),
        onPanStart: (d) => _beginMove(d, corner: corner, edge: edge),
        onPanUpdate: (d) => _updateMove(d, corner: corner, edge: edge),
        onPanEnd: _finishMove,
        child: Center(child: Container(
          width: size * .50,
          height: size * .50,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: accent ? const Color(0xFFB9F8D3) : Colors.white,
            shape: BoxShape.circle,
            border: Border.all(color: const Color(0xFF13594D), width: 1.8 / _transformation.value.getMaxScaleOnAxis()),
            boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 4)],
          ),
          child: Text(label, style: TextStyle(
              color: const Color(0xFF15594D), fontWeight: FontWeight.w900,
              fontSize: size * .27)),
        )),
      ),
    );
  }

  Widget _bottomPanel() {
    return Container(
      color: const Color(0xFF1A2A35),
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
      child: _cropping ? Column(mainAxisSize: MainAxisSize.min, children: [
        Row(children: [
          Expanded(child: _tool(Icons.crop_free_rounded, 'كامل', _fullCrop)),
          Expanded(child: _tool(Icons.restart_alt_rounded, 'إعادة', _resetCrop)),
          Expanded(child: _tool(Icons.crop_din_rounded, 'مستطيل', _straightenCrop)),
          Expanded(child: _tool(Icons.rotate_right_rounded, 'تدوير', _rotatePhoto)),
          Expanded(child: _tool(Icons.zoom_out_rounded, '−', () => _changeZoom(false))),
          Expanded(child: _tool(Icons.zoom_in_rounded, '+', () => _changeZoom(true))),
        ]),
        const SizedBox(height: 5),
        // The corner selector and four nudge buttons cannot all fit in one
        // row on 320dp phones. Separate the controls at compact widths rather
        // than forcing DropdownButton's minimum intrinsic width to overflow.
        LayoutBuilder(builder: (context, constraints) {
          final selector = Expanded(child: DropdownButtonHideUnderline(
            child: DropdownButton<int>(
              value: _activeCorner,
              isExpanded: true,
              dropdownColor: const Color(0xFF1A2A35),
              style: const TextStyle(color: Colors.white, fontSize: 11),
              items: const [
                DropdownMenuItem(value: 0, child: Text('أعلى يسار')),
                DropdownMenuItem(value: 1, child: Text('أعلى يمين')),
                DropdownMenuItem(value: 2, child: Text('أسفل يمين')),
                DropdownMenuItem(value: 3, child: Text('أسفل يسار')),
              ],
              onChanged: _processing ? null : (i) {
                if (i != null) setState(() => _activeCorner = i);
              },
            ),
          ));
          final buttons = <Widget>[
            _nudgeButton(Icons.arrow_back_rounded, -1, 0),
            _nudgeButton(Icons.arrow_forward_rounded, 1, 0),
            _nudgeButton(Icons.keyboard_arrow_up_rounded, 0, -1),
            _nudgeButton(Icons.keyboard_arrow_down_rounded, 0, 1),
          ];
          final label = const Text('تحريك دقيق:',
              style: TextStyle(color: Colors.white70, fontSize: 11));
          if (constraints.maxWidth < 375) {
            return Column(mainAxisSize: MainAxisSize.min, children: [
              Row(children: [label, const SizedBox(width: 5), selector]),
              const SizedBox(height: 2),
              Row(children: [
                for (final button in buttons)
                  Expanded(child: Center(child: button)),
              ]),
            ]);
          }
          return Row(children: [
            label, const SizedBox(width: 5), selector, ...buttons,
          ]);
        }),
        const SizedBox(height: 7),
        LayoutBuilder(builder: (context, constraints) {
          final confirm = FilledButton.icon(
            onPressed: _processing ? null : _confirmCrop,
            icon: const Icon(Icons.check_rounded),
            label: Text(_processing ? 'جارٍ تجهيز القص...' : 'قص واستخراج النص'),
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xFFB9EBD0),
              foregroundColor: Palette.ink,
              padding: const EdgeInsets.symmetric(vertical: 12)),
          );
          final retake = OutlinedButton.icon(
            onPressed: _processing ? null : _retake,
            icon: const Icon(Icons.camera_alt_outlined, size: 18),
            label: const Text('إعادة تصوير', style: TextStyle(fontSize: 11)),
            style: OutlinedButton.styleFrom(foregroundColor: Colors.white,
              side: const BorderSide(color: Colors.white54)),
          );
          if (constraints.maxWidth < 380) {
            return Column(crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [confirm,
                if (widget.fromCamera) ...[
                  const SizedBox(height: 6), retake,
                ],
              ]);
          }
          return Row(children: [
            if (widget.fromCamera) ...[
              retake,
              const SizedBox(width: 8),
            ],
            Expanded(child: confirm),
          ]);
        }),
      ]) : SizedBox(width: double.infinity, child: FilledButton.icon(
        onPressed: _processing || _loading || _error != null ? null : _takeFullPhoto,
        icon: const Icon(Icons.camera_alt_rounded),
        label: Text(_processing ? 'جارٍ التقاط الصورة...' : 'تصوير الورقة كاملة'),
        style: FilledButton.styleFrom(backgroundColor: const Color(0xFFB9EBD0),
            foregroundColor: Palette.ink,
            padding: const EdgeInsets.symmetric(vertical: 15)),
      )),
    );
  }

  Widget _tool(IconData icon, String label, VoidCallback action) =>
      InkWell(onTap: _processing ? null : action,
        borderRadius: BorderRadius.circular(10),
        child: Padding(padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 19, color: Colors.white),
            Text(label, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 10, color: Colors.white)),
          ])));

  Widget _nudgeButton(IconData icon, int dx, int dy) => IconButton(
    onPressed: _processing ? null : () => _nudge(dx, dy),
    color: const Color(0xFFB9EBD0), icon: Icon(icon, size: 20),
    padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 32, minHeight: 36),
    tooltip: 'حرّك الزاوية المحددة بدقة',
  );
}

class _QuadOverlay extends CustomPainter {
  const _QuadOverlay({required this.p});
  final List<Offset> p;

  @override
  void paint(Canvas canvas, Size size) {
    final shape = Path()..moveTo(p[0].dx, p[0].dy);
    for (var i = 1; i < 4; i++) {
      shape.lineTo(p[i].dx, p[i].dy);
    }
    shape.close();
    final shade = Path()
      ..addRect(Offset.zero & size)
      ..addPath(shape, Offset.zero)
      ..fillType = PathFillType.evenOdd;
    canvas.drawPath(shade,
        Paint()..color = Colors.black.withValues(alpha: .58));
    canvas.drawPath(shape,
        Paint()..color = const Color(0xFFB9F8D3)
          ..strokeWidth = 2.5
          ..style = PaintingStyle.stroke);
    final grid = Paint()
      ..color = Colors.white.withValues(alpha: .34)
      ..strokeWidth = .8;
    Offset interpolate(Offset a, Offset b, double t) => a + (b - a) * t;
    for (final t in [1 / 3, 2 / 3]) {
      canvas.drawLine(interpolate(p[0], p[1], t),
          interpolate(p[3], p[2], t), grid);
      canvas.drawLine(interpolate(p[0], p[3], t),
          interpolate(p[1], p[2], t), grid);
    }
  }

  @override
  bool shouldRepaint(covariant _QuadOverlay oldDelegate) {
    for (var i = 0; i < 4; i++) {
      if (oldDelegate.p[i] != p[i]) return true;
    }
    return false;
  }
}
