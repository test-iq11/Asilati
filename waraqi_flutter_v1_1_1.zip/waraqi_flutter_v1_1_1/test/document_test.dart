import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:waraqi_studio/models/paper_document.dart';
import 'package:waraqi_studio/widgets/paper_pages.dart';

void main() {
  test('PaperDocument unnamed constructor is available across app entrypoints', () {
    final document = PaperDocument();
    expect(document.title, isNotEmpty);
    expect(document.questions, isNotEmpty);
    final fromEmptyJson = PaperDocument.fromJson(<String, dynamic>{});
    expect(fromEmptyJson.title, document.title);
    expect(fromEmptyJson.questions.length, document.questions.length);
    expect(PaperDocument.decode(document.encode()).title, document.title);
  });

  test('Arabic and English digits normalize across all source scripts', () {
    expect(formatDigits('س 1: 45.67 و ۱۲٣', DigitStyle.arabic), 'س ١: ٤٥.٦٧ و ١٢٣');
    expect(formatDigits('س ١: ٤٥.٦٧ و ۱۲٣', DigitStyle.english), 'س 1: 45.67 و 123');
    expect(formatDigits('رقم ١٢٣ 123 ۱۲۳', DigitStyle.english), 'رقم 123 123 123');
  });

  test('separate top and bottom A4 margins persist without clamping', () {
    final d = PaperDocument();
    d.topMarginMm = 0;
    d.bottomMarginMm = 27;
    d.digitStyle = DigitStyle.english;
    final copy = PaperDocument.decode(d.encode());
    expect(copy.topMarginMm, 0);
    expect(copy.bottomMarginMm, 27);
    expect(copy.digits('السؤال ٥: ٣+٢'), 'السؤال 5: 3+2');
    expect(PaperPages.mm(10), closeTo(28.346, .002));
  });

  test('OCR inserts editable question text without embedding source photo', () {
    final d = PaperDocument();
    final q = d.questions.first;
    q.text = 'أوجد ٣ × 4'; // same editable text field used by recognition results
    expect(q.elements, isEmpty);
    final copy = PaperDocument.decode(d.encode());
    expect(copy.questions.first.text, 'أوجد ٣ × 4');
    expect(copy.questions.first.elements, isEmpty);
    expect(copy.digits(copy.questions.first.text), 'أوجد ٣ × ٤');
  });

  test('separately inserted illustrative images survive persistence', () {
    final d = PaperDocument();
    d.questions.first.elements.add(
      PaperElement(id: 'figure', kind: 'image', imagePath: '/test/figure.jpg'),
    );
    final copy = PaperDocument.decode(d.encode());
    expect(copy.questions.first.elements.first.imagePath, '/test/figure.jpg');
    expect(copy.questions.first.branches.length, 2);
  });

  test('pagination always includes a page, even with no questions', () {
    final d = PaperDocument()..questions = [];
    expect(PaperPages.paginate(d, answers: false).length, 1);
  });

  testWidgets('question numbering and body render with the same digit setting', (tester) async {
    final d = PaperDocument()
      ..digitStyle = DigitStyle.english
      ..showRules = false
      ..questions = [PaperQuestion(id: 'q1', text: 'أوجد ٥ + 2', branches: ['٣ + 4'])];
    tester.view.physicalSize = const Size(1200, 1700);
    tester.view.devicePixelRatio = 1;
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    Widget page() => MaterialApp(home: Scaffold(body: Center(
      child: ExamPage(document: d, questions: d.questions, pageIndex: 0,
        pageCount: 1, startingNumber: 1, answers: false),
    )));
    await tester.pumpWidget(page());
    expect(find.textContaining('س 1: أوجد 5 + 2'), findsOneWidget);
    expect(find.text('(1) 3 + 4'), findsOneWidget);
    d.digitStyle = DigitStyle.arabic;
    await tester.pumpWidget(page());
    expect(find.textContaining('س ١: أوجد ٥ + ٢'), findsOneWidget);
    expect(find.text('(١) ٣ + ٤'), findsOneWidget);
  });
}
