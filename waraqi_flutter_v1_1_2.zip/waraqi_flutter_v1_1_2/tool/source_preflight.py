#!/usr/bin/env python3
"""Small dependency-free source/assets guard; NOT a substitute for flutter test."""
from pathlib import Path
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]

def require(ok, message):
    if not ok:
        raise AssertionError(message)

# Scan balanced Dart tokens while ignoring comments and literals. This is a
# quick smoke check; the real Dart parser is `flutter analyze` in CI.
def check_balanced(path):
    source = path.read_text(encoding='utf-8')
    stack = []
    quote = None
    triple = False
    offset = 0
    matches = {')': '(', ']': '[', '}': '{'}
    while offset < len(source):
        c = source[offset]
        nxt = source[offset+1:offset+2]
        if quote:
            if c == '\\':
                offset += 2
                continue
            if triple and source.startswith(quote*3, offset):
                quote = None
                offset += 3
                continue
            if not triple and c == quote:
                quote = None
                offset += 1
                continue
            offset += 1
            continue
        if c == '/' and nxt == '/':
            end = source.find('\n', offset)
            offset = end if end >= 0 else len(source)
            continue
        if c == '/' and nxt == '*':
            end = source.find('*/', offset+2)
            require(end >= 0, f'Unterminated comment: {path}')
            offset = end+2
            continue
        if c in ('"', "'"):
            quote = c
            triple = source.startswith(c*3, offset)
            offset += 3 if triple else 1
            continue
        if c in '([{':
            stack.append(c)
        elif c in ')]}':
            require(stack and stack.pop() == matches[c], f'Unbalanced {c} in {path}')
        offset += 1
    require(not stack and not quote, f'Unclosed Dart source: {path}')

sources = list(ROOT.rglob('*.dart'))
require(len(sources) >= 8, 'Missing Dart sources')
for path in sources:
    check_balanced(path)

pubspec = (ROOT/'pubspec.yaml').read_text(encoding='utf-8')
require('version: 1.1.2+4' in pubspec, 'Incorrect pubspec version')
require('name: waraqi_studio' in pubspec, 'Flutter package name mismatch')
require('tesseract_ocr:' in pubspec, 'Missing OCR dependency')

config = json.loads((ROOT/'assets/tessdata_config.json').read_text(encoding='utf-8'))
files = config.get('files', [])
require(set(files) == {'ara.traineddata', 'eng.traineddata'}, 'OCR models differ from config')
for name in files:
    require((ROOT/'assets/tessdata'/name).stat().st_size > 100000,
            f'Missing or empty OCR model: {name}')
    require(f'assets/tessdata/{name}' in pubspec, f'Model missing from assets: {name}')
require('assets/tessdata_config.json' in pubspec, 'Config is missing from Flutter assets')

model = (ROOT/'lib/models/paper_document.dart').read_text(encoding='utf-8')
page = (ROOT/'lib/widgets/paper_pages.dart').read_text(encoding='utf-8')
app = (ROOT/'lib/main.dart').read_text(encoding='utf-8')
tests = (ROOT/'test/document_test.dart').read_text(encoding='utf-8')
require(re.search(r'class PaperDocument\s*\{\s*[^}]*?PaperDocument\(\);', model, re.S),
        'Missing default PaperDocument constructor')
require('questionPrintLabel(d,index,q.text)' in page, 'Question title bypasses common digit formatter')
require('branchPrintLabel(d,i+1,q.branches[i])' in page, 'Branches bypass common digit formatter')
require("key:ValueKey('exam-question-$index')" in page, 'Rendered question cannot be located in widget tests')
require('insertExtractedText' in app and 'insertExtractedText' in model,
        'OCR extraction not connected to editable question field')
require('showFooter' in model and 'topMarginMm' in model and 'bottomMarginMm' in model,
        'Document layout options missing')
require('oversizedQuestions(_document,answers:_answers)' in app,
        'Large question export warning/guard missing')
require("testWidgets('question numbering and body render with the same digit setting'" in tests,
        'Numbering widget regression test missing')

manifest = (ROOT/'android/app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
require('android.permission.CAMERA' in manifest, 'Camera permission missing')
require('com.waraqi.studio' in (ROOT/'android/app/build.gradle.kts').read_text(encoding='utf-8'),
        'Wrong Android application namespace')
workflow = (ROOT/'.github/workflows/build-waraqi-android.yml').read_text(encoding='utf-8')
require('flutter analyze' in workflow and 'flutter test --reporter expanded' in workflow
        and 'flutter build apk --release' in workflow, 'Incomplete GitHub Actions quality gates')
require('waraqi-v1.1.2.apk' in workflow, 'APK version mismatch')

print(f'PASS: {len(sources)} Dart sources balanced, OCR asset config and Android/Flutter wiring checked')
print('PASS: print-digit renderer shares one formatter and widget test inspects real Text nodes')
print('PASS: CI quality gates, version and source metadata align')
print('NOTE: These are preflight checks only; Flutter analyzer/tests/build run on GitHub.')
