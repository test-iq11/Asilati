import 'package:flutter_test/flutter_test.dart';
import 'package:waraqi_studio/models/paper_document.dart';
import 'package:waraqi_studio/services/question_templates.dart';

void main() {
  test('all template questions contain editable content and unique IDs', () {
    final identifiers = <String>{};
    for (final kind in QuestionTemplateKind.values) {
      final question = QuestionTemplates.build(kind);
      expect(question.text.trim(), isNotEmpty);
      expect(identifiers.add(question.id), isTrue);
      expect(question.points, greaterThan(0));
      expect(question.id, isNot('sample-1'));
    }
  });
  test('alternate exam keeps original and independent question IDs', () {
    final original = PaperDocument()
      ..questions = [QuestionTemplates.build(QuestionTemplateKind.choices),
                      QuestionTemplates.build(QuestionTemplateKind.math),
                      QuestionTemplates.build(QuestionTemplateKind.table)];
    final before = original.encode();
    final copy = QuestionTemplates.alternateDocument(original, seed: 111);
    expect(original.encode(), before);
    expect(copy.documentId, isNot(original.documentId));
    expect(copy.title, contains('نموذج بديل'));
    expect(copy.questions.length, 3);
    final originals = original.questions.map((q) => q.id).toSet();
    for (final question in copy.questions) {
      expect(originals.contains(question.id), isFalse);
    }
    expect(copy.questions.map((q) => q.id).toSet().length, 3);
  });
  test('separate branch marks control totals and survive serialization', () {
    final question = PaperQuestion(id: 'one', points: 10,
      useBranchPoints: true, branches: ['A','B'], branchPoints: [3,7]);
    expect(question.effectivePoints, 10);
    question.branchPoints[0] = 2;
    expect(question.effectivePoints, 9);
    final doc = PaperDocument()..questions = [question];
    expect(doc.usedPoints, 9);
    final copy = PaperDocument.decode(doc.encode());
    expect(copy.questions.single.effectivePoints, 9);
    copy.questions.single.visible = false;
    expect(copy.usedPoints, 0);
  });

  test('booklet chapters and signatures survive copy and JSON import', () {
    final doc = PaperDocument()
      ..documentType = 'booklet'
      ..bookletChapters = [BookletChapter(id: 'c1', title: 'الفصل الأول',
          introduction: 'تعريفات وأمثلة')]
      ..signatures = [PaperSignature(id: 's1', name: 'معلم المادة', role: 'إعداد')]
      ..questions = [PaperQuestion(id: 'q1', chapterId: 'c1', text: 'سؤال')];
    final loaded = PaperDocument.decode(doc.encode());
    expect(loaded.bookletChapters.single.title, 'الفصل الأول');
    expect(loaded.signatures.single.name, 'معلم المادة');
    expect(loaded.questions.single.chapterId, 'c1');
    final alt = QuestionTemplates.alternateDocument(doc, seed: 10);
    expect(alt.bookletChapters.single.id, isNot('c1'));
    expect(alt.questions.single.chapterId, alt.bookletChapters.single.id);
  });

  test('paper fonts and layouts persist through archive serialization', () {
    final doc = PaperDocument()..paperFont = 'serif'..paperLayout='modernClean';
    final copy = PaperDocument.decode(doc.encode());
    expect(copy.paperFont, 'serif');
    expect(copy.paperLayout, 'modernClean');
    expect(PaperDocument.fromJson({'paperFont':'invalid','paperLayout':'invalid'}).paperFont,'default');
  });
}
