import 'dart:math' as math;

import 'package:flutter/material.dart';

/// A visual alternative to writing table rows using literal `|` delimiters.
/// The stored representation stays compatible with all existing paper exports.
class TableGridEditor extends StatefulWidget {
  const TableGridEditor({super.key, required this.initialText});
  final String initialText;

  @override
  State<TableGridEditor> createState() => _TableGridEditorState();
}

class _TableGridEditorState extends State<TableGridEditor> {
  late List<List<String>> _rows;
  late int _columns;

  @override
  void initState() {
    super.initState();
    final parsed = widget.initialText.trim().isEmpty
        ? <List<String>>[]
        : widget.initialText.split('\n').map((s) => s.split('|')).toList();
    _columns = parsed.fold<int>(2, (max, row) => math.max(max, row.length)).clamp(1, 8).toInt();
    _rows = parsed.isEmpty ? List.generate(3, (_) => List.filled(_columns, ''))
        : parsed.take(25).map((row) => List<String>.generate(_columns,
            (index) => index < row.length ? row[index].trim() : '')).toList();
  }

  void _addRow() => setState(() => _rows.add(List.filled(_columns, '')));
  void _removeRow() => setState(() => _rows.removeLast());
  void _addColumn() => setState(() {
    _columns++;
    for (final row in _rows) { row.add(''); }
  });
  void _removeColumn() => setState(() {
    _columns--;
    for (final row in _rows) { row.removeLast(); }
  });

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('محرر الجداول'),
    contentPadding: const EdgeInsets.fromLTRB(14, 8, 14, 5),
    content: SizedBox(
      width: math.min(MediaQuery.sizeOf(context).width - 64, 700.0),
      height: math.min(MediaQuery.sizeOf(context).height * .53, 430.0),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('أدخل البيانات في الخلايا، وأضف الصفوف والأعمدة حسب الحاجة.',
            style: TextStyle(fontSize: 12)),
        const SizedBox(height: 10),
        Wrap(spacing: 4, runSpacing: 4, children: [
          TextButton.icon(onPressed: _rows.length < 25 ? _addRow : null,
              icon: const Icon(Icons.add), label: const Text('صف')),
          TextButton.icon(onPressed: _rows.length > 1 ? _removeRow : null,
              icon: const Icon(Icons.remove), label: const Text('حذف صف')),
          TextButton.icon(onPressed: _columns < 8 ? _addColumn : null,
              icon: const Icon(Icons.add), label: const Text('عمود')),
          TextButton.icon(onPressed: _columns > 1 ? _removeColumn : null,
              icon: const Icon(Icons.remove), label: const Text('حذف عمود')),
        ]),
        const SizedBox(height: 8),
        Expanded(child: Scrollbar(child: SingleChildScrollView(
          child: SingleChildScrollView(scrollDirection: Axis.horizontal,
            child: Column(children: [
              for (var i = 0; i < _rows.length; i++) Row(children: [
                for (var j = 0; j < _columns; j++) Container(
                  width: 142, padding: const EdgeInsets.all(3),
                  decoration: BoxDecoration(border: Border.all(color: Colors.black12)),
                  child: TextFormField(
                    key: ValueKey('cell-$i-$j-${_rows.length}-$_columns'),
                    initialValue: _rows[i][j],
                    onChanged: (text) => _rows[i][j] = text,
                    minLines: 1, maxLines: 3,
                    decoration: InputDecoration(isDense: true,
                        hintText: 'خانة ${j + 1}'),
                  ),
                ),
              ]),
            ]),
          ),
        ))),
      ]),
    ),
    actions: [
      TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
      FilledButton(onPressed: () {
        final table = _rows.map((row) => row.join('|')).join('\n');
        Navigator.pop(context, table);
      }, child: const Text('حفظ الجدول')),
    ],
  );
}
