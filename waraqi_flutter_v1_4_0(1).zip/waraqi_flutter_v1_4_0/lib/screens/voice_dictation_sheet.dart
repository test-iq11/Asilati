import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

/// A speech session never silently writes into the question. On Android the
/// system speech input dialog is preferred; the embedded recognizer remains an
/// optional alternative, with bounded initialization to avoid a stuck spinner.
class VoiceDictationSheet extends StatefulWidget {
  const VoiceDictationSheet({super.key, this.preferEnglish = false});

  final bool preferEnglish;

  @override
  State<VoiceDictationSheet> createState() => _VoiceDictationSheetState();
}

class _VoiceDictationSheetState extends State<VoiceDictationSheet> {
  static const MethodChannel _systemVoice =
      MethodChannel('com.waraqi.studio/voice');
  final stt.SpeechToText _speech = stt.SpeechToText();
  final TextEditingController _text = TextEditingController();
  bool _initializing = false;
  bool _ready = false;
  bool _listening = false;
  String? _message;
  String _sessionPrefix = '';
  String? _locale;

  @override
  void dispose() {
    _speech.cancel();
    _text.dispose();
    super.dispose();
  }

  void _appendRecognized(String words) {
    final old = _text.text.trimRight();
    final cleaned = words.trim();
    if (cleaned.isEmpty) return;
    final combined = old.isEmpty ? cleaned : '$old $cleaned';
    _text.value = TextEditingValue(
      text: combined,
      selection: TextSelection.collapsed(offset: combined.length),
    );
  }

  /// Uses Android's installed speech input UI without waiting on the Flutter
  /// plugin's initialization. The phone still needs a speech service.
  Future<void> _startSystemDictation() async {
    if (_initializing || _listening) return;
    setState(() {
      _initializing = true;
      _message = null;
    });
    try {
      final words = await _systemVoice.invokeMethod<String>(
        'recognize',
        {'locale': widget.preferEnglish ? 'en-US' : 'ar-IQ'},
      ).timeout(const Duration(seconds: 45));
      if (!mounted) return;
      if (words != null) setState(() => _appendRecognized(words));
    } on TimeoutException {
      if (mounted) setState(() => _message =
          'لم تستجب خدمة الإملاء في الهاتف. جرب الإملاء داخل التطبيق أو لوحة مفاتيح الهاتف.');
    } on PlatformException catch (error) {
      if (mounted) setState(() => _message =
          '${error.message ?? 'خدمة الإملاء غير متاحة'}. يمكنك تجربة الإملاء داخل التطبيق أو لوحة المفاتيح.');
    } on MissingPluginException {
      if (mounted) setState(() => _message =
          'الواجهة الصوتية غير متاحة في هذا الإصدار؛ جرب الإملاء داخل التطبيق.');
    } catch (error) {
      if (mounted) setState(() => _message = 'تعذّر فتح الإملاء: $error');
    } finally {
      if (mounted) setState(() => _initializing = false);
    }
  }

  /// Optional live in-app recognizer. Every await has a timeout so the UI
  /// cannot remain stuck at «جارٍ التهيئة» indefinitely.
  Future<void> _toggleLive() async {
    if (_initializing) return;
    if (_listening) {
      try {
        await _speech.stop().timeout(const Duration(seconds: 8));
      } catch (_) {
        // A hung native service should not prevent ending the UI session.
      }
      if (mounted) setState(() => _listening = false);
      return;
    }
    setState(() {
      _initializing = true;
      _message = null;
    });
    try {
      if (!_ready) {
        final available = await _speech.initialize(
          onStatus: (status) {
            if (!mounted) return;
            if (status == 'done' || status == 'notListening') {
              setState(() => _listening = false);
            }
          },
          onError: (error) {
            if (mounted) setState(() {
              _listening = false;
              _message = 'تعذّر التعرف على الصوت: ${error.errorMsg}';
            });
          },
        ).timeout(const Duration(seconds: 12));
        if (!available) {
          if (mounted) setState(() => _message =
              'التعرف المباشر غير متاح. تحقق من إذن الميكروفون وخدمات التعرف الصوتي أو استخدم إملاء الهاتف.');
          return;
        }
        _ready = true;
        final locales = await _speech.locales()
            .timeout(const Duration(seconds: 7));
        final preferred = widget.preferEnglish ? 'en' : 'ar';
        for (final locale in locales) {
          if (locale.localeId.toLowerCase().startsWith(preferred)) {
            _locale = locale.localeId;
            break;
          }
        }
      }
      _sessionPrefix = _text.text.trimRight();
      if (!mounted) return;
      await _speech.listen(
        localeId: _locale,
        onResult: (result) {
          if (!mounted) return;
          final words = result.recognizedWords.trim();
          final next = [
            if (_sessionPrefix.isNotEmpty) _sessionPrefix,
            if (words.isNotEmpty) words,
          ].join(' ');
          _text.value = TextEditingValue(
            text: next,
            selection: TextSelection.collapsed(offset: next.length),
          );
          if (result.finalResult) setState(() => _listening = false);
        },
      ).timeout(const Duration(seconds: 12));
      if (mounted) setState(() {
        _listening = _speech.isListening;
        if (!_listening && _message == null) {
          _message = 'لم يبدأ التعرف المباشر. جرّب إملاء الهاتف أو تحقق من إذن الميكروفون.';
        }
      });
    } on TimeoutException {
      if (mounted) setState(() {
        _ready = false;
        _listening = false;
        _message = 'انتهت مهلة تهيئة الميكروفون. اختر «ابدأ الإملاء» لاستخدام واجهة أندرويد، أو تحقق من خدمة التعرف الصوتي.';
      });
    } catch (error) {
      if (mounted) setState(() {
        _ready = false;
        _listening = false;
        _message = 'فشل تشغيل الميكروفون: $error';
      });
    } finally {
      if (mounted) setState(() => _initializing = false);
    }
  }

  Future<void> _confirm() async {
    final result = _text.text.trim();
    if (result.isEmpty) return;
    if (_speech.isListening) {
      try {
        await _speech.stop().timeout(const Duration(seconds: 6));
      } catch (_) {
        // Keep manually approved text even if the native recognizer hangs.
      }
    }
    if (mounted) Navigator.of(context).pop(result);
  }

  @override
  Widget build(BuildContext context) => SafeArea(
    child: Padding(
      padding: EdgeInsets.fromLTRB(20, 10, 20,
          20 + MediaQuery.viewInsetsOf(context).bottom),
      child: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('الكتابة بالصوت',
              style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          const Text('ابدأ من واجهة إملاء الهاتف، ثم راجع النص قبل إضافته. إذا لم تكن الخدمة متاحة يمكنك تجربة الإملاء المباشر.',
              style: TextStyle(fontSize: 12, height: 1.55)),
          const SizedBox(height: 14),
          FilledButton.icon(
            onPressed: _initializing || _listening ? null : _startSystemDictation,
            icon: const Icon(Icons.mic),
            label: Text(_initializing ? 'الإملاء قيد التشغيل...' : 'ابدأ الإملاء'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: _initializing ? null : _toggleLive,
            icon: Icon(_listening ? Icons.stop_circle_outlined : Icons.mic_none_rounded),
            label: Text(_initializing ? 'جاري تهيئة الميكروفون...' :
                _listening ? 'إيقاف الإملاء المباشر' : 'الإملاء داخل التطبيق (بديل)'),
          ),
          if (_listening) const Padding(
            padding: EdgeInsets.only(top: 8),
            child: Text('الميكروفون يعمل الآن', textAlign: TextAlign.center),
          ),
          if (_message != null) Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Text(_message!, style: const TextStyle(color: Colors.redAccent)),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: _text,
            minLines: 4,
            maxLines: 8,
            textDirection: TextDirection.rtl,
            decoration: const InputDecoration(labelText: 'النص المُملى',
                hintText: 'النص الذي تتحدث به يظهر هنا ويمكن تصحيحه'),
          ),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(child: OutlinedButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('إلغاء'),
            )),
            const SizedBox(width: 10),
            Expanded(child: FilledButton.icon(
              onPressed: _confirm,
              icon: const Icon(Icons.check),
              label: const Text('إضافة النص'),
            )),
          ]),
        ]),
      ),
    ),
  );
}
