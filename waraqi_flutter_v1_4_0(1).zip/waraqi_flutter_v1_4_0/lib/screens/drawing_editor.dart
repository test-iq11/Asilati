import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

import '../theme.dart';

class _InkStroke {
  _InkStroke(this.color, this.width, Offset first) : points = [first];
  final Color color;
  final double width;
  final List<Offset> points;
}

/// Offline freehand diagram editor. Saves a user-created PNG independently of
/// photographed question OCR; undo never mutates the original question.
class DrawingEditor extends StatefulWidget {
  const DrawingEditor({super.key});

  @override
  State<DrawingEditor> createState() => _DrawingEditorState();
}

class _DrawingEditorState extends State<DrawingEditor> {
  final GlobalKey _canvasKey = GlobalKey();
  final List<_InkStroke> _strokes = [];
  static const _colors = <Color>[
    Color(0xFF101010), Color(0xFF2669AD), Color(0xFF108960),
    Color(0xFFB34847), Color(0xFF8648B5),
  ];
  Color _selected = _colors.first;
  double _width = 3;
  bool _saving = false;

  void _start(DragStartDetails details) {
    setState(() => _strokes.add(_InkStroke(_selected, _width,
        details.localPosition)));
  }

  void _update(DragUpdateDetails details) {
    if (_strokes.isEmpty) return;
    setState(() => _strokes.last.points.add(details.localPosition));
  }

  Future<void> _save() async {
    if (_saving || _strokes.isEmpty) return;
    setState(() => _saving = true);
    try {
      // Await a paint cycle so the image reflects the last pen movement.
      await WidgetsBinding.instance.endOfFrame;
      final boundary = _canvasKey.currentContext?.findRenderObject();
      if (boundary is! RenderRepaintBoundary) {
        throw StateError('اللوحة غير جاهزة للحفظ');
      }
      final image = await boundary.toImage(pixelRatio: 2.0);
      final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
      image.dispose();
      if (bytes == null) throw StateError('تعذّر إنشاء ملف الصورة');
      if (!mounted) return;
      Navigator.of(context).pop(Uint8List.view(
          bytes.buffer, bytes.offsetInBytes, bytes.lengthInBytes));
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('تعذّر حفظ الرسم: $error')));
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('رسم توضيحي'), actions: [
      IconButton(onPressed: _strokes.isEmpty || _saving ? null :
          () => setState(() => _strokes.removeLast()),
        tooltip: 'تراجع عن آخر خط', icon: const Icon(Icons.undo_rounded)),
      IconButton(onPressed: _strokes.isEmpty || _saving ? null :
          () => setState(_strokes.clear),
        tooltip: 'مسح اللوحة', icon: const Icon(Icons.delete_outline)),
    ]),
    body: SafeArea(child: Padding(
      padding: const EdgeInsets.all(12),
      child: Column(children: [
        const Text('ارسم بإصبعك ثم أضف الرسم إلى السؤال. يمكنك التراجع أو تغيير اللون وسماكة القلم.',
            textAlign: TextAlign.center, style: TextStyle(fontSize: 12)),
        const SizedBox(height: 10),
        Expanded(child: ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: RepaintBoundary(key: _canvasKey, child: Container(
            color: Colors.white,
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onPanStart: _start,
              onPanUpdate: _update,
              child: CustomPaint(
                painter: _InkPainter(_strokes),
                child: const SizedBox.expand(),
              ),
            ),
          )),
        )),
        const SizedBox(height: 12),
        Row(children: [
          for (final color in _colors) Padding(
            padding: const EdgeInsetsDirectional.only(end: 8),
            child: InkWell(
              onTap: () => setState(() => _selected = color),
              borderRadius: BorderRadius.circular(20),
              child: Container(width: 30, height: 30,
                decoration: BoxDecoration(shape: BoxShape.circle, color: color,
                  border: Border.all(color: _selected == color ? Palette.teal : Colors.white,
                    width: 3)),
              ),
            ),
          ),
          Expanded(child: Slider(value: _width, min: 1.0, max: 12.0,
            onChanged: (value) => setState(() => _width = value))),
        ]),
        const SizedBox(height: 9),
        SizedBox(width: double.infinity, child: FilledButton.icon(
          onPressed: _saving || _strokes.isEmpty ? null : _save,
          icon: Icon(_saving ? Icons.hourglass_bottom_rounded : Icons.check),
          label: Text(_saving ? 'جارٍ حفظ الرسم...' : 'إضافة الرسم إلى السؤال'),
        )),
      ]),
    )),
  );
}

class _InkPainter extends CustomPainter {
  const _InkPainter(this.strokes);
  final List<_InkStroke> strokes;

  @override
  void paint(Canvas canvas, Size size) {
    for (final stroke in strokes) {
      if (stroke.points.isEmpty) continue;
      final paint = Paint()
        ..color = stroke.color
        ..strokeWidth = stroke.width
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..style = PaintingStyle.stroke
        ..isAntiAlias = true;
      if (stroke.points.length == 1) {
        canvas.drawPoints(ui.PointMode.points, stroke.points, paint);
      } else {
        final path = Path()..moveTo(stroke.points.first.dx, stroke.points.first.dy);
        for (final point in stroke.points.skip(1)) {
          path.lineTo(point.dx, point.dy);
        }
        canvas.drawPath(path, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _InkPainter oldDelegate) => true;
}
