import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';

import '../models/paper_document.dart';
import '../widgets/paper_pages.dart';

/// Print image snapshots of Flutter-rendered A4 pages. This preserves Arabic
/// shaping and digit selection offline, without depending on remote PDF fonts.
class PrintService {
  static Future<Uint8List> generatePdf(
    PaperDocument document,
    List<GlobalKey> pageKeys,
  ) async {
    final pdf = pw.Document(compress: true);
    final format = document.landscape
        ? PdfPageFormat.a4.landscape
        : PdfPageFormat.a4;
    for (final key in pageKeys) {
      final boundary = key.currentContext?.findRenderObject()
          as RenderRepaintBoundary?;
      if (boundary == null) {
        throw StateError('صفحة غير جاهزة للتصدير');
      }
      await WidgetsBinding.instance.endOfFrame;
      final ui.Image image = await boundary.toImage(pixelRatio: 3);
      final data = await image.toByteData(format: ui.ImageByteFormat.png);
      image.dispose();
      if (data == null) {
        throw StateError('تعذّر قراءة صورة الصفحة');
      }
      final source = pw.MemoryImage(data.buffer.asUint8List());
      pdf.addPage(
        pw.Page(
          pageFormat: format,
          margin: pw.EdgeInsets.zero,
          build: (_) => pw.Image(
            source,
            width: format.width,
            height: format.height,
            fit: pw.BoxFit.fill,
          ),
        ),
      );
    }
    return pdf.save();
  }

  static Future<void> printPages(PaperDocument doc, List<GlobalKey> keys) async {
    final bytes = await generatePdf(doc, keys);
    await Printing.layoutPdf(onLayout: (_) => bytes, name: doc.title);
  }

  static Future<void> sharePdf(PaperDocument doc, List<GlobalKey> keys) async {
    final bytes = await generatePdf(doc, keys);
    final path = await _writeTempFile(
      '${_safeName(doc.title)}.pdf',
      bytes,
    );
    await Share.shareXFiles(
      [XFile(path)],
      text: 'ملف PDF من تطبيق ورقي',
    );
  }

  static Future<void> shareWord(PaperDocument doc, {required bool answers}) async {
    final html = await generateWordHtml(doc, answers: answers);
    final path = await _writeTempFile(
      '${_safeName(doc.title)}.doc',
      Uint8List.fromList(utf8.encode('\ufeff$html')),
    );
    await Share.shareXFiles(
      [XFile(path, mimeType: 'application/msword')],
      text: 'ملف Word من تطبيق ورقي',
    );
  }

  static Future<String> generateWordHtml(
    PaperDocument doc, {
    required bool answers,
  }) async {
    final buffer = StringBuffer();
    buffer.writeln('<!DOCTYPE html>');
    buffer.writeln('<html lang="ar" dir="rtl"><head>');
    buffer.writeln('<meta charset="UTF-8">');
    buffer.writeln('<meta name="viewport" content="width=device-width, initial-scale=1.0">');
    buffer.writeln('<title>${_escape(doc.title)}</title>');
    final wordFont = switch (doc.paperFont) {
      'serif' => 'Times New Roman, Georgia, serif',
      'sans' => 'Tahoma, Arial, sans-serif',
      _ => 'Tahoma, Arial, sans-serif',
    };
    // Use the paper's typography in Word too rather than fixed 16/22px sizes.
    buffer.writeln('''
<style>
body{font-family:$wordFont;direction:rtl;color:#1b1b1b;margin:20px;font-size:${doc.fontSize}px;line-height:${doc.lineSpacing};background:#fff;}
.page{page-break-after:always;max-width:850px;margin:0 auto;}
.math-frame{border:2px solid #242424;padding:16px;}
.arabic-lines{padding:8px;}
.header{border-bottom:1px solid #999;padding-bottom:10px;margin-bottom:12px;}
.header-grid{display:grid;grid-template-columns:1fr 1.2fr 1fr;gap:12px;align-items:start;}
.center{text-align:center;}
.right{text-align:right;}
.left{text-align:left;}
.title{font-size:${(doc.fontSize*1.1).toStringAsFixed(1)}px;font-weight:700;margin:4px 0;}
.meta{font-size:${doc.fontSize}px;font-weight:bold;margin:2px 0;}
.section-note,.footer-note{font-size:${(doc.fontSize*1.02).toStringAsFixed(1)}px;font-weight:700;text-align:center;margin:14px 0;color:#111;}
.identity{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin:10px 0 16px;}
.identity .line{border-bottom:1px solid #666;height:28px;display:flex;align-items:flex-start;gap:8px;}
.question{margin:0 0 ${doc.questionGap.toStringAsFixed(1)}px;padding-bottom:10px;border-bottom:1px solid #444;}
.section-title{font-weight:bold;font-size:18px;text-decoration:underline;text-align:right;margin:8px 0;}
.q-title{font-size:${doc.fontSize}px;font-weight:700;}
.points{display:inline-block;font-weight:bold;padding:2px 6px;font-size:${(doc.fontSize*.76).toStringAsFixed(1)}px;float:left;margin-inline-start:8px;}
.branch{margin:4px 16px 0 0;}
.rule{border-bottom:1px solid #bbb;height:24px;margin-top:14px;}
.answer{background:#eef7f0;border:1px solid #c8dfce;border-radius:8px;padding:8px 10px;margin-top:10px;}
.simple-table{border-collapse:collapse;width:100%;margin-top:8px;}
.simple-table td,.simple-table th{border:1px solid #666;padding:6px;text-align:center;}
.image-wrap{margin:8px 0;}
.image-wrap img{max-width:100%;max-height:280px;object-fit:contain;}
.footer-wrap{margin-top:22px;border-top:1px solid #ddd;padding-top:10px;}
.small-muted{color:#666;font-size:12px;}
.booklet-chapter{font-size:1.4em;text-align:center;margin:18px 0;font-weight:700;}
.school-classic{border:3px double #242424;padding:18px;}
.modern-clean .section-title{text-decoration:none;border-right:3px solid #333;padding-right:8px;}
.signature-row{display:flex;flex-wrap:wrap;gap:20px;justify-content:space-around;margin-top:22px;}
.signature{width:22%;min-width:120px;text-align:center;}
.booklet-cover{height:85vh;display:flex;flex-direction:column;align-items:center;justify-content:center;page-break-after:always;text-align:center;}
.booklet-cover h1{font-size:2em;}
.booklet-index{page-break-after:always;padding:20px;}
.booklet-index .entry{margin:12px 0;padding:7px;border-bottom:1px solid #ccc;}
</style>''');
    buffer.writeln('</head><body>');
    if (doc.documentType == 'booklet') {
      if (doc.showBookletCover) {
        final coverTitle = doc.bookletCoverTitle.trim().isNotEmpty
            ? doc.bookletCoverTitle : doc.title;
        buffer.writeln('<div class="booklet-cover">');
        buffer.writeln('<div>${_escape(doc.ministry)}</div><div>${_escape(doc.school)}</div>');
        buffer.writeln('<h1>${_escape(coverTitle)}</h1>');
        buffer.writeln('<p>${_escape(doc.bookletCoverSubtitle)}</p>');
        buffer.writeln('<p>${_escape(doc.subject)} — ${_escape(doc.grade)}</p>');
        buffer.writeln('<div>${_escape(doc.academicYear)}</div>');
        buffer.writeln('</div>');
      }
      if (doc.showBookletIndex) {
        buffer.writeln('<div class="booklet-index"><h2>الفهرس</h2>');
        for (final chapter in doc.bookletChapters) {
          buffer.writeln('<div class="entry">${_escape(chapter.title)}</div>');
        }
        buffer.writeln('</div>');
      }
    }
    buffer.writeln('<div class="page ${doc.paperLayout == 'schoolClassic' ? 'school-classic' : doc.paperLayout == 'mathFrame' ? 'math-frame' : doc.paperLayout == 'modernClean' ? 'modern-clean' : 'arabic-lines'}">');

    buffer.writeln('<div class="header">');
    buffer.writeln('<div class="header-grid">');
    buffer.writeln('<div class="right">');
    if (doc.headerFields.contains('country')) {
      buffer.writeln('<div class="meta">${_escape(doc.digits(doc.country))}</div>');
    }
    if (doc.headerFields.contains('ministry')) {
      buffer.writeln('<div class="meta">${_escape(doc.digits(doc.ministry))}</div>');
    }
    if (doc.headerFields.contains('directorate')) {
      buffer.writeln('<div class="meta">${_escape(doc.digits(doc.directorate))}</div>');
    }
    if (doc.headerFields.contains('school')) {
      buffer.writeln('<div class="meta">${_escape(doc.digits(doc.school))}</div>');
    }
    buffer.writeln('</div>');

    buffer.writeln('<div class="center">');
    buffer.writeln('<div class="meta">${_escape(doc.digits(doc.bismillah))}</div>');
    if (doc.headerFields.contains('title')) {
      buffer.writeln('<div class="title">${_escape(doc.digits(doc.title))}</div>');
    }
    if (doc.headerFields.contains('academicYear')) {
      buffer.writeln('<div class="meta">للعام الدراسي ${_escape(doc.digits(doc.academicYear))}</div>');
    }
    buffer.writeln('</div>');

    buffer.writeln('<div class="left">');
    if (doc.headerFields.contains('subject')) {
      buffer.writeln('<div class="meta">المادة: ${_escape(doc.digits(doc.subject))}</div>');
    }
    if (doc.headerFields.contains('grade')) {
      buffer.writeln('<div class="meta">الصف: ${_escape(doc.digits(doc.grade))}</div>');
    }
    if (doc.headerFields.contains('total')) {
      final totalText = doc.total == doc.total.roundToDouble()
          ? doc.total.toStringAsFixed(0)
          : doc.total.toStringAsFixed(1);
      buffer.writeln('<div class="meta">الدرجة الكلية: ${_escape(doc.digits(totalText))}</div>');
    }
    if (doc.headerFields.contains('duration')) {
      buffer.writeln('<div class="meta">الوقت: ${_escape(doc.digits(doc.duration))}</div>');
    }
    if (doc.headerFields.contains('date')) {
      buffer.writeln('<div class="meta">التاريخ: ${_escape(doc.digits(doc.date))}</div>');
    }
    buffer.writeln('</div>');

    buffer.writeln('</div></div>');

    if (doc.showStudentNameField || doc.showSectionField) {
      buffer.writeln('<div class="identity">');
      if (doc.showStudentNameField) {
        buffer.writeln('<div class="line"><strong>اسم الطالب:</strong><span style="flex:1"></span></div>');
      }
      if (doc.showSectionField) {
        buffer.writeln('<div class="line"><strong>الصف/الشعبة:</strong><span style="flex:1"></span></div>');
      }
      buffer.writeln('</div>');
    }

    if (doc.topNote.trim().isNotEmpty) {
      buffer.writeln('<div class="section-note">${_escape(doc.digits(doc.topNote))}</div>');
    }

    var printedNumber = 0;
    final printedChapterIds = <String>{};
    for (var i = 0; i < doc.questions.length; i++) {
      final q = doc.questions[i];
      if (!q.visible) continue;
      printedNumber++;
      final points = q.effectivePoints == q.effectivePoints.roundToDouble()
          ? q.effectivePoints.toStringAsFixed(0)
          : q.effectivePoints.toStringAsFixed(1);
      if (q.pageBreakBefore && printedNumber > 1) {
        buffer.writeln('<div style="page-break-before:always"></div>');
      }
      if (doc.documentType == 'booklet' && q.chapterId.isNotEmpty &&
          printedChapterIds.add(q.chapterId)) {
        final names = doc.bookletChapters.where((c) => c.id == q.chapterId)
            .map((c) => c.title);
        if (names.isNotEmpty) {
          buffer.writeln('<h2 class="booklet-chapter">${_escape(names.first)}</h2>');
          final intros = doc.bookletChapters.where((c) => c.id == q.chapterId)
              .map((c) => c.introduction);
          if (intros.isNotEmpty && intros.first.trim().isNotEmpty) {
            buffer.writeln('<p>${_escape(intros.first)}</p>');
          }
        }
      }
      buffer.writeln('<div class="question">');
      if (q.sectionTitle.trim().isNotEmpty) {
        buffer.writeln('<div class="section-title">${_escape(doc.digits(q.sectionTitle))}</div>');
      }
      buffer.writeln('<div class="q-title">${_escape(questionPrintLabel(doc, printedNumber, q.text))}${doc.showGrades ? '<span class="points">${_escape(doc.digits(points))} درجات</span>' : ''}</div>');
      for (var b = 0; b < q.branches.length; b++) {
        final mark = q.useBranchPoints
            ? ' (${_escape(doc.digits(b < q.branchPoints.length ? q.branchPoints[b] : 0))} درجات)' : '';
        buffer.writeln('<div class="branch">${_escape(branchPrintLabel(doc, b + 1, q.branches[b]))}$mark</div>');
      }
      for (final element in q.elements) {
        buffer.writeln(await _elementHtml(doc, element));
      }
      if (doc.showRules && q.type == 'essay' && q.branches.isEmpty && q.elements.isEmpty) {
        buffer.writeln('<div class="rule"></div><div class="rule"></div>');
      }
      if (answers && q.answer.trim().isNotEmpty) {
        buffer.writeln('<div class="answer"><strong>الإجابة:</strong> ${_escape(doc.digits(q.answer))}</div>');
      }
      buffer.writeln('</div>');
    }

    buffer.writeln('<div class="footer-wrap">');
    if (doc.teacherName.trim().isNotEmpty) {
      buffer.writeln('<div class="footer-note" style="text-align:left;">معلم المادة: ${_escape(doc.digits(doc.teacherName))}</div>');
    }
    if (doc.showFooter && doc.footerText.trim().isNotEmpty) {
      buffer.writeln('<div class="footer-note">${_escape(doc.digits(doc.footerText))}</div>');
    }
    if (doc.signatures.any((signature) => signature.name.trim().isNotEmpty)) {
      buffer.writeln('<div class="signature-row">');
      for (final signature in doc.signatures.where((s) => s.name.trim().isNotEmpty)) {
        buffer.writeln('<div class="signature"><strong>${_escape(signature.role)}</strong>'
            '<div>${_escape(signature.name)}</div></div>');
      }
      buffer.writeln('</div>');
    }
    buffer.writeln('</div>');
    buffer.writeln('</div></body></html>');
    return buffer.toString();
  }

  static Future<String> _elementHtml(PaperDocument doc, PaperElement e) async {
    if (e.imagePath != null && File(e.imagePath!).existsSync()) {
      final file = File(e.imagePath!);
      final bytes = await file.readAsBytes();
      final ext = file.path.split('.').last.toLowerCase();
      final mime = switch (ext) {
        'jpg' || 'jpeg' => 'image/jpeg',
        'webp' => 'image/webp',
        _ => 'image/png',
      };
      final encoded = base64Encode(bytes);
      return '<div class="image-wrap"><img src="data:$mime;base64,$encoded" alt="صورة"></div>';
    }
    switch (e.kind) {
      case 'space':
        final count = int.tryParse(e.text) ?? 3;
        return List.generate(
          count.clamp(1, 9).toInt(),
          (_) => '<div class="rule"></div>',
        ).join();
      case 'options':
        final items = e.text
            .split('\n')
            .where((x) => x.trim().isNotEmpty)
            .map((x) => '<div>□ ${_escape(doc.digits(x.trim()))}</div>')
            .join();
        return '<div>$items</div>';
      case 'tf':
        return '<div>□ صح&nbsp;&nbsp;&nbsp; □ خطأ&nbsp;&nbsp;&nbsp; ${_escape(doc.digits(e.text))}</div>';
      case 'table':
        final rows = e.text
            .split('\n')
            .where((x) => x.trim().isNotEmpty)
            .map((line) => line.split('|'))
            .toList();
        if (rows.isEmpty) return '';
        final tableRows = rows
            .map((row) => '<tr>${row.map((cell) => '<td>${_escape(doc.digits(cell.trim()))}</td>').join()}</tr>')
            .join();
        return '<table class="simple-table">$tableRows</table>';
      case 'math':
      case 'chem':
        return '<div style="text-align:center;font-weight:700;margin:8px 0;direction:ltr;">${_escape(doc.digits(e.text))}</div>';
      default:
        return '<div style="margin:8px 0;">${_escape(doc.digits(e.text))}</div>';
    }
  }

  static Future<String> _writeTempFile(String name, Uint8List bytes) async {
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/$name');
    await file.writeAsBytes(bytes, flush: true);
    return file.path;
  }

  static String _safeName(String value) {
    final raw = value.trim().isEmpty ? 'waraqi_export' : value.trim();
    return raw.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
  }

  static String _escape(String value) {
    return value
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#39;')
        .replaceAll('\n', '<br>');
  }
}
