import 'dart:math';

import '../models/paper_document.dart';

/// Fresh editable templates; no copied exam text or assets from other apps.
enum QuestionTemplateKind {
  essay('سؤال مقالي', 'نص حر ومساحة للإجابة'),
  choices('اختيار من متعدد', 'أربعة خيارات قابلة للتحرير'),
  trueFalse('صح أم خطأ', 'عبارات مع مربعات صح وخطأ'),
  complete('أكمل الفراغات', 'فروع تحتوي على خطوط منقطة'),
  match('الربط والمطابقة', 'عمودان من العناصر'),
  math('مسألة رياضية', 'معادلة وسطر للحل'),
  reading('نص وفهم المقروء', 'نص ثم أسئلة فرعية'),
  table('جدول', 'صفوف وأعمدة قابلة للتعديل');

  const QuestionTemplateKind(this.title, this.help);
  final String title;
  final String help;
}

class QuestionTemplates {
  static PaperQuestion build(QuestionTemplateKind kind) {
    final question = PaperQuestion(id: newId(), points: 5);
    switch (kind) {
      case QuestionTemplateKind.essay:
        question.text = 'أجب عن السؤال الآتي:';
        question.type = 'essay';
      case QuestionTemplateKind.choices:
        question.text = 'اختر الإجابة الصحيحة مما يأتي:';
        question.type = 'choices';
        question.elements.add(PaperElement(id:newId(), kind:'options',
          text:'الخيار الأول\nالخيار الثاني\nالخيار الثالث\nالخيار الرابع'));
      case QuestionTemplateKind.trueFalse:
        question.text = 'ضع علامة (✓) أمام العبارة الصحيحة و(✗) أمام العبارة الخاطئة:';
        question.type = 'trueFalse';
        question.branches.addAll(['العبارة الأولى', 'العبارة الثانية']);
        question.elements.add(PaperElement(id:newId(), kind:'tf', text:'صح أم خطأ'));
      case QuestionTemplateKind.complete:
        question.text = 'أكمل الفراغات الآتية:';
        question.type = 'complete';
        question.branches.addAll(['...................', '...................']);
      case QuestionTemplateKind.match:
        question.text = 'صل كل عنصر من العمود الأول بما يناسبه من العمود الثاني:';
        question.type = 'match';
        question.elements.add(PaperElement(id:newId(), kind:'table',
          text:'العمود الأول|العمود الثاني\nالعنصر الأول|المقابل الأول\nالعنصر الثاني|المقابل الثاني'));
      case QuestionTemplateKind.math:
        question.text = 'حل المسألة الرياضية الآتية موضحاً خطوات الحل:';
        question.type = 'math';
        question.elements.add(PaperElement(id:newId(), kind:'math', text:'2 × 3 = ........'));
        question.elements.add(PaperElement(id:newId(), kind:'space', text:'3'));
      case QuestionTemplateKind.reading:
        question.text = 'اقرأ النص الآتي ثم أجب عن الأسئلة:';
        question.type = 'reading';
        question.elements.add(PaperElement(id:newId(), kind:'text', text:'اكتب نص القراءة هنا.'));
        question.branches.addAll(['الفكرة الرئيسية:', 'استخرج من النص:']);
      case QuestionTemplateKind.table:
        question.text = 'أكمل الجدول الآتي:';
        question.type = 'table';
        question.elements.add(PaperElement(id:newId(), kind:'table',
          text:'العنوان الأول|العنوان الثاني|العنوان الثالث\n | | \n | | '));
    }
    return question;
  }

  /// New independent exam (document/question/element IDs). Original stays intact.
  /// A seeded shuffle supports deterministic testing while user mode uses random seed.
  static PaperDocument alternateDocument(PaperDocument source, {int? seed}) {
    final copy = PaperDocument.decode(source.encode());
    copy.documentId = newId();
    copy.title = '${source.title} — نموذج بديل';
    copy.questions = source.questions.map((item) {
      final json = item.toJson();
      json['id'] = newId();
      json['pageBreakBefore'] = false;
      json['elements'] = item.elements.map((element) {
        final updated = element.toJson();
        updated['id'] = newId();
        return updated;
      }).toList();
      return PaperQuestion.fromJson(json);
    }).toList();
    // Give the copy its own chapter IDs too, preserving relations.
    final idMap = <String, String>{};
    copy.bookletChapters = copy.bookletChapters.map((chapter) {
      final id = newId();
      idMap[chapter.id] = id;
      return BookletChapter(id: id, title: chapter.title,
          introduction: chapter.introduction);
    }).toList();
    for (final question in copy.questions) {
      if (idMap.containsKey(question.chapterId)) {
        question.chapterId = idMap[question.chapterId]!;
      }
    }
    copy.questions.shuffle(Random(seed));
    return copy;
  }
}
