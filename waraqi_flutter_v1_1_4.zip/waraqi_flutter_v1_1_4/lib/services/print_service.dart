import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';

import '../models/paper_document.dart';
import '../widgets/paper_pages.dart';

/// Print image snapshots of Flutter-rendered A4 pages. This preserves Arabic
/// shaping and digit selection offline, without depending on remote PDF fonts.
class PrintService {
  static Future<Uint8List> generatePdf(
    PaperDocument document,
    List<GlobalKey> pageKeys,
  ) async {
    final pdf = pw.Document(compress: true);
    final format = document.landscape
        ? PdfPageFormat.a4.landscape
        : PdfPageFormat.a4;
    for (final key in pageKeys) {
      final boundary = key.currentContext?.findRenderObject()
          as RenderRepaintBoundary?;
      if (boundary == null) {
        throw StateError('صفحة غير جاهزة للتصدير');
      }
      await WidgetsBinding.instance.endOfFrame;
      final ui.Image image = await boundary.toImage(pixelRatio: 3);
      final data = await image.toByteData(format: ui.ImageByteFormat.png);
      image.dispose();
      if (data == null) {
        throw StateError('تعذّر قراءة صورة الصفحة');
      }
      final source = pw.MemoryImage(data.buffer.asUint8List());
      pdf.addPage(
        pw.Page(
          pageFormat: format,
          margin: pw.EdgeInsets.zero,
          build: (_) => pw.Image(
            source,
            width: format.width,
            height: format.height,
            fit: pw.BoxFit.fill,
          ),
        ),
      );
    }
    return pdf.save();
  }

  static Future<void> printPages(PaperDocument doc, List<GlobalKey> keys) async {
    final bytes = await generatePdf(doc, keys);
    await Printing.layoutPdf(onLayout: (_) => bytes, name: doc.title);
  }

  static Future<void> sharePdf(PaperDocument doc, List<GlobalKey> keys) async {
    final bytes = await generatePdf(doc, keys);
    final path = await _writeTempFile(
      '${_safeName(doc.title)}.pdf',
      bytes,
    );
    await SharePlus.instance.share(
      ShareParams(
        text: 'ملف PDF من تطبيق ورقي',
        files: [XFile(path)],
      ),
    );
  }

  static Future<void> shareWord(PaperDocument doc, {required bool answers}) async {
    final html = await generateWordHtml(doc, answers: answers);
    final path = await _writeTempFile(
      '${_safeName(doc.title)}.doc',
      Uint8List.fromList(utf8.encode('\ufeff$html')),
    );
    await SharePlus.instance.share(
      ShareParams(
        text: 'ملف Word من تطبيق ورقي',
        files: [XFile(path, mimeType: 'application/msword')],
      ),
    );
  }

  static Future<String> generateWordHtml(
    PaperDocument doc, {
    required bool answers,
  }) async {
    final buffer = StringBuffer();
    buffer.writeln('<!DOCTYPE html>');
    buffer.writeln('<html lang="ar" dir="rtl"><head>');
    buffer.writeln('<meta charset="UTF-8">');
    buffer.writeln('<meta name="viewport" content="width=device-width, initial-scale=1.0">');
    buffer.writeln('<title>${_escape(doc.title)}</title>');
    buffer.writeln('''
<style>
body{font-family:Tahoma,Arial,sans-serif;direction:rtl;color:#1b1b1b;margin:20px;line-height:1.8;background:#fff;}
.page{page-break-after:always;max-width:850px;margin:0 auto;}
.header{border-bottom:1px solid #999;padding-bottom:10px;margin-bottom:12px;}
.header-grid{display:grid;grid-template-columns:1fr 1.2fr 1fr;gap:12px;align-items:start;}
.center{text-align:center;}
.right{text-align:right;}
.left{text-align:left;}
.title{font-size:22px;font-weight:700;margin:4px 0;}
.meta{font-size:14px;margin:2px 0;}
.section-note,.footer-note{font-size:18px;font-weight:700;text-align:center;margin:14px 0;color:#111;}
.identity{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin:10px 0 16px;}
.identity .line{border-bottom:1px solid #666;height:28px;display:flex;align-items:flex-start;gap:8px;}
.question{margin:0 0 16px;}
.q-title{font-size:16px;font-weight:700;}
.points{display:inline-block;border:1px solid #777;border-radius:6px;padding:2px 6px;font-size:12px;margin-inline-start:8px;}
.branch{margin:4px 16px 0 0;}
.rule{border-bottom:1px solid #bbb;height:24px;margin-top:14px;}
.answer{background:#eef7f0;border:1px solid #c8dfce;border-radius:8px;padding:8px 10px;margin-top:10px;}
.simple-table{border-collapse:collapse;width:100%;margin-top:8px;}
.simple-table td,.simple-table th{border:1px solid #666;padding:6px;text-align:center;}
.image-wrap{margin:8px 0;}
.image-wrap img{max-width:100%;max-height:280px;object-fit:contain;}
.footer-wrap{margin-top:22px;border-top:1px solid #ddd;padding-top:10px;}
.small-muted{color:#666;font-size:12px;}
</style>''');
    buffer.writeln('</head><body><div class="page">');

    buffer.writeln('<div class="header">');
    buffer.writeln('<div class="header-grid">');
    buffer.writeln('<div class="right">');
    if (doc.headerFields.contains('country')) {
      buffer.writeln('<div class="meta">${_escape(doc.digits(doc.country))}</div>');
    }
    if (doc.headerFields.contains('ministry')) {
      buffer.writeln('<div class="meta">${_escape(doc.digits(doc.ministry))}</div>');
    }
    if (doc.headerFields.contains('directorate')) {
      buffer.writeln('<div class="meta">${_escape(doc.digits(doc.directorate))}</div>');
    }
    if (doc.headerFields.contains('school')) {
      buffer.writeln('<div class="meta">${_escape(doc.digits(doc.school))}</div>');
    }
    buffer.writeln('</div>');

    buffer.writeln('<div class="center">');
    buffer.writeln('<div class="meta">${_escape(doc.digits(doc.bismillah))}</div>');
    if (doc.headerFields.contains('title')) {
      buffer.writeln('<div class="title">${_escape(doc.digits(doc.title))}</div>');
    }
    if (doc.headerFields.contains('academicYear')) {
      buffer.writeln('<div class="meta">للعام الدراسي ${_escape(doc.digits(doc.academicYear))}</div>');
    }
    buffer.writeln('</div>');

    buffer.writeln('<div class="left">');
    if (doc.headerFields.contains('subject')) {
      buffer.writeln('<div class="meta">المادة: ${_escape(doc.digits(doc.subject))}</div>');
    }
    if (doc.headerFields.contains('grade')) {
      buffer.writeln('<div class="meta">الصف: ${_escape(doc.digits(doc.grade))}</div>');
    }
    if (doc.headerFields.contains('total')) {
      final totalText = doc.total == doc.total.roundToDouble()
          ? doc.total.toStringAsFixed(0)
          : doc.total.toStringAsFixed(1);
      buffer.writeln('<div class="meta">الدرجة الكلية: ${_escape(doc.digits(totalText))}</div>');
    }
    if (doc.headerFields.contains('duration')) {
      buffer.writeln('<div class="meta">الوقت: ${_escape(doc.digits(doc.duration))}</div>');
    }
    if (doc.headerFields.contains('date')) {
      buffer.writeln('<div class="meta">التاريخ: ${_escape(doc.digits(doc.date))}</div>');
    }
    buffer.writeln('</div>');

    buffer.writeln('</div></div>');

    if (doc.showStudentNameField || doc.showSectionField) {
      buffer.writeln('<div class="identity">');
      if (doc.showStudentNameField) {
        buffer.writeln('<div class="line"><strong>اسم الطالب:</strong><span style="flex:1"></span></div>');
      }
      if (doc.showSectionField) {
        buffer.writeln('<div class="line"><strong>الصف/الشعبة:</strong><span style="flex:1"></span></div>');
      }
      buffer.writeln('</div>');
    }

    if (doc.topNote.trim().isNotEmpty) {
      buffer.writeln('<div class="section-note">${_escape(doc.digits(doc.topNote))}</div>');
    }

    for (var i = 0; i < doc.questions.length; i++) {
      final q = doc.questions[i];
      if (!q.visible) continue;
      final points = q.points == q.points.roundToDouble()
          ? q.points.toStringAsFixed(0)
          : q.points.toStringAsFixed(1);
      buffer.writeln('<div class="question">');
      buffer.writeln('<div class="q-title">${_escape(questionPrintLabel(doc, i + 1, q.text))}${doc.showGrades ? '<span class="points">${_escape(doc.digits(points))} درجات</span>' : ''}</div>');
      for (var b = 0; b < q.branches.length; b++) {
        buffer.writeln('<div class="branch">${_escape(branchPrintLabel(doc, b + 1, q.branches[b]))}</div>');
      }
      for (final element in q.elements) {
        buffer.writeln(await _elementHtml(doc, element));
      }
      if (doc.showRules && q.type == 'essay' && q.branches.isEmpty && q.elements.isEmpty) {
        buffer.writeln('<div class="rule"></div><div class="rule"></div>');
      }
      if (answers && q.answer.trim().isNotEmpty) {
        buffer.writeln('<div class="answer"><strong>الإجابة:</strong> ${_escape(doc.digits(q.answer))}</div>');
      }
      buffer.writeln('</div>');
    }

    buffer.writeln('<div class="footer-wrap">');
    if (doc.teacherName.trim().isNotEmpty) {
      buffer.writeln('<div class="footer-note">معلم المادة: ${_escape(doc.digits(doc.teacherName))}</div>');
    }
    if (doc.showFooter && doc.footerText.trim().isNotEmpty) {
      buffer.writeln('<div class="footer-note">${_escape(doc.digits(doc.footerText))}</div>');
    }
    buffer.writeln('</div>');
    buffer.writeln('</div></body></html>');
    return buffer.toString();
  }

  static Future<String> _elementHtml(PaperDocument doc, PaperElement e) async {
    if (e.imagePath != null && File(e.imagePath!).existsSync()) {
      final file = File(e.imagePath!);
      final bytes = await file.readAsBytes();
      final ext = file.path.split('.').last.toLowerCase();
      final mime = switch (ext) {
        'jpg' || 'jpeg' => 'image/jpeg',
        'webp' => 'image/webp',
        _ => 'image/png',
      };
      final encoded = base64Encode(bytes);
      return '<div class="image-wrap"><img src="data:$mime;base64,$encoded" alt="صورة"></div>';
    }
    switch (e.kind) {
      case 'space':
        final count = int.tryParse(e.text) ?? 3;
        return List.generate(
          count.clamp(1, 9).toInt(),
          (_) => '<div class="rule"></div>',
        ).join();
      case 'options':
        final items = e.text
            .split('\n')
            .where((x) => x.trim().isNotEmpty)
            .map((x) => '<div>□ ${_escape(doc.digits(x.trim()))}</div>')
            .join();
        return '<div>$items</div>';
      case 'tf':
        return '<div>□ صح&nbsp;&nbsp;&nbsp; □ خطأ&nbsp;&nbsp;&nbsp; ${_escape(doc.digits(e.text))}</div>';
      case 'table':
        final rows = e.text
            .split('\n')
            .where((x) => x.trim().isNotEmpty)
            .map((line) => line.split('|'))
            .toList();
        if (rows.isEmpty) return '';
        final tableRows = rows
            .map((row) => '<tr>${row.map((cell) => '<td>${_escape(doc.digits(cell.trim()))}</td>').join()}</tr>')
            .join();
        return '<table class="simple-table">$tableRows</table>';
      case 'math':
      case 'chem':
        return '<div style="text-align:center;font-weight:700;margin:8px 0;direction:ltr;">${_escape(doc.digits(e.text))}</div>';
      default:
        return '<div style="margin:8px 0;">${_escape(doc.digits(e.text))}</div>';
    }
  }

  static Future<String> _writeTempFile(String name, Uint8List bytes) async {
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/$name');
    await file.writeAsBytes(bytes, flush: true);
    return file.path;
  }

  static String _safeName(String value) {
    final raw = value.trim().isEmpty ? 'waraqi_export' : value.trim();
    return raw.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
  }

  static String _escape(String value) {
    return value
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#39;')
        .replaceAll('\n', '<br>');
  }
}
