#!/usr/bin/env python3
"""Small dependency-free source/assets guard; NOT a substitute for flutter test."""
from pathlib import Path
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]

def require(ok, message):
    if not ok:
        raise AssertionError(message)

# Scan balanced Dart tokens while ignoring comments and literals. This is a
# quick smoke check; the real Dart parser is `flutter analyze` in CI.
def check_balanced(path):
    source = path.read_text(encoding='utf-8')
    stack = []
    quote = None
    triple = False
    offset = 0
    matches = {')': '(', ']': '[', '}': '{'}
    while offset < len(source):
        c = source[offset]
        nxt = source[offset+1:offset+2]
        if quote:
            if c == '\\':
                offset += 2
                continue
            if triple and source.startswith(quote*3, offset):
                quote = None
                offset += 3
                continue
            if not triple and c == quote:
                quote = None
                offset += 1
                continue
            offset += 1
            continue
        if c == '/' and nxt == '/':
            end = source.find('\n', offset)
            offset = end if end >= 0 else len(source)
            continue
        if c == '/' and nxt == '*':
            end = source.find('*/', offset+2)
            require(end >= 0, f'Unterminated comment: {path}')
            offset = end+2
            continue
        if c in ('"', "'"):
            quote = c
            triple = source.startswith(c*3, offset)
            offset += 3 if triple else 1
            continue
        if c in '([{':
            stack.append(c)
        elif c in ')]}':
            require(stack and stack.pop() == matches[c], f'Unbalanced {c} in {path}')
        offset += 1
    require(not stack and not quote, f'Unclosed Dart source: {path}')

sources = list(ROOT.rglob('*.dart'))
require(len(sources) >= 8, 'Missing Dart sources')
for path in sources:
    check_balanced(path)

pubspec = (ROOT/'pubspec.yaml').read_text(encoding='utf-8')
version_match = re.search(r'(?m)^version:\s*(\d+\.\d+\.\d+)\+(\d+)\s*$', pubspec)
require(version_match, 'Missing or invalid pubspec version')
version_name = version_match.group(1)
expected_folder = 'waraqi_flutter_v' + version_name.replace('.', '_')
require(ROOT.name == expected_folder,
        f'Project directory {ROOT.name} does not match pubspec version {version_name}')
require('name: waraqi_studio' in pubspec, 'Flutter package name mismatch')
require('tesseract_ocr:' in pubspec, 'Missing OCR dependency')

# Contract checks for the versioned share_plus API and actual export UI wiring.
share_dependency = re.search(r'(?m)^\s*share_plus:\s*\^?(\d+)\.(\d+)\.(\d+)\s*$', pubspec)
require(share_dependency, 'share_plus dependency is missing or unsupported')
share_major = int(share_dependency.group(1))
share_service = (ROOT/'lib/services/print_service.dart').read_text(encoding='utf-8')
if share_major == 10:
    require('Share.shareXFiles(' in share_service and 'SharePlus.instance' not in share_service
            and 'ShareParams(' not in share_service,
            'share_plus v10 must use Share.shareXFiles, not the v11 SharePlus API')
elif share_major >= 11:
    require('SharePlus.instance.share(' in share_service and 'ShareParams(' in share_service,
            'share_plus v11+ must use the SharePlus API')
else:
    require(False, 'This project supports only share_plus v10 or later')


config = json.loads((ROOT/'assets/tessdata_config.json').read_text(encoding='utf-8'))
files = config.get('files', [])
require(set(files) == {'ara.traineddata', 'eng.traineddata'}, 'OCR models differ from config')
for name in files:
    require((ROOT/'assets/tessdata'/name).stat().st_size > 100000,
            f'Missing or empty OCR model: {name}')
    require(f'assets/tessdata/{name}' in pubspec, f'Model missing from assets: {name}')
require('assets/tessdata_config.json' in pubspec, 'Config is missing from Flutter assets')

model = (ROOT/'lib/models/paper_document.dart').read_text(encoding='utf-8')
page = (ROOT/'lib/widgets/paper_pages.dart').read_text(encoding='utf-8')
app = (ROOT/'lib/main.dart').read_text(encoding='utf-8')
tests = (ROOT/'test/document_test.dart').read_text(encoding='utf-8')
require(re.search(r'class PaperDocument\s*\{\s*[^}]*?PaperDocument\(\);', model, re.S),
        'Missing default PaperDocument constructor')
require('_studentIdentityFields()' in page and 'constraints.maxWidth < 400' in page,
        'A4 student identity row must adapt to printable width')
require('_fitPageSection(' in page and 'headerLimit = contentHeight * 0.53' in page
        and 'footerLimit = contentHeight * 0.22' in page
        and 'BoxFit.scaleDown' in page,
        'A4 header/footer must be constrained before the question area is laid out')
require("A4 header and footer cannot overrun the page at extreme settings" in tests,
        'Missing page overflow regression test for extreme header/footer settings')
require('questionPrintLabel(d,index,q.text)' in page, 'Question title bypasses common digit formatter')
require('branchPrintLabel(d,i+1,q.branches[i])' in page, 'Branches bypass common digit formatter')
require("key:ValueKey('exam-question-$index')" in page, 'Rendered question cannot be located in widget tests')
require('insertExtractedText' in app and 'insertExtractedText' in model,
        'OCR extraction not connected to editable question field')
screen = (ROOT/'lib/screens/crop_capture_screen.dart').read_text(encoding='utf-8')
crop_service = (ROOT/'lib/services/ocr_crop_service.dart').read_text(encoding='utf-8')
require('_takeFullPhoto' in screen and '_confirmCrop' in screen
        and 'OcrCropService.cropEncoded' in screen and 'img.bakeOrientation' in crop_service,
        'OCR full-photo capture then manual crop workflow is missing')
require('img.copyCrop' in crop_service,
        'OCR crop must be derived from original image pixels')
require(all(x in screen for x in [
    'InteractiveViewer(', 'TransformationController()',
    'crop-corner-$i', 'crop-edge-$i', 'crop-center-handle',
    '_scenePoint(', '_updateMove(', '_nudge(',
    '_rotatePhoto(', 'OcrCropService.cropEncoded', 'compute<',
]), 'Precision crop gestures, zoom, and asynchronous original-image crop must remain wired')
require(all(x in crop_service for x in [
    'class CropQuad', 'moveCorner(', 'moveEdge(', 'translate(',
    'isValid', 'cropQuadrilateral(', 'img.copyRectify(', 'rotateEncoded(', 'previewEncoded(',
]), 'Four-corner crop geometry and original-image rectification must remain present')
require(all(x in tests for x in [
    'four independent crop corners cannot cross or leave photo',
    'independent edge, center move and clamp preserve a valid crop',
    'free four-corner crop rectifies source pixels and bounds output size',
    'crop editor exposes independent handles without screen overflow',
]), 'Four-corner crop regression tests missing')
require('showFooter' in model and 'topMarginMm' in model and 'bottomMarginMm' in model,
        'Document layout options missing')
require('_chooseExportFormat,dark:true' in app
        and 'PrintService.shareWord' in app and 'PrintService.sharePdf' in app,
        'The Word/PDF format selector must be connected to preview UI')
require('oversizedQuestions(_document,answers:_answers)' in app,
        'Large question export warning/guard missing')
require("testWidgets('question numbering and body render with the same digit setting'" in tests,
        'Numbering widget regression test missing')

# Prevent incompatible Android build plugins from reaching a slow Gradle build.
wrapper_config = (ROOT/'android/gradle/wrapper/gradle-wrapper.properties').read_text(encoding='utf-8')
settings_gradle = (ROOT/'android/settings.gradle.kts').read_text(encoding='utf-8')
android_app_gradle = (ROOT/'android/app/build.gradle.kts').read_text(encoding='utf-8')
require('gradle-8.14.3-bin.zip' in wrapper_config, 'Gradle wrapper must be 8.14.3')
require(re.search(r'id\("com\.android\.application"\)\s+version\s+"8\.11\.1"', settings_gradle),
        'Android Gradle Plugin must be 8.11.1')
require(re.search(r'id\("org\.jetbrains\.kotlin\.android"\)\s+version\s+"2\.2\.20"', settings_gradle),
        'Kotlin Gradle Plugin must be 2.2.20')
require('JavaVersion.VERSION_17' in android_app_gradle,
        'Java source/target compatibility must stay on 17')
# Flutter's Gradle plugin enables resource shrinking for release by default.
# Never leave it enabled when minification is explicitly disabled.
release_match = re.search(r'buildTypes\s*\{\s*release\s*\{(.*?)\n\s*\}',
                          android_app_gradle, re.S)
require(release_match, 'Release build configuration missing')
release_config = release_match.group(1)
require(re.search(r'\bisMinifyEnabled\s*=\s*false\b', release_config)
        and re.search(r'\bisShrinkResources\s*=\s*false\b', release_config),
        'Release minification and resource shrinking must both be disabled')

manifest = (ROOT/'android/app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
require('speech_to_text: 7.5.0' in pubspec, 'Speech dependency version must stay pinned and verified')
require('android.permission.RECORD_AUDIO' in manifest and
        'android.speech.RecognitionService' in manifest,
        'Microphone permission or speech recognition query is missing')
voice = (ROOT/'lib/screens/voice_dictation_sheet.dart').read_text(encoding='utf-8')
ocr = (ROOT/'lib/services/ocr_text_tools.dart').read_text(encoding='utf-8')
require('_dictateQuestion(q)' in app and 'VoiceDictationSheet' in app
        and 'Icons.mic_none_rounded' in app and 'speech.listen(' in voice,
        'Voice dictation buttons are missing or not connected to speech recognition')
require('OcrTextTools.prepareForOcr' in app and "language == 'ara'" in app
        and 'arabicOnly' in ocr and 'OcrTextTools.clean' in app,
        'Arabic-first OCR or post-review workflow is not connected')
require('paperLayout' in model and 'paperLayout' in page and
        'sectionTitle' in model and 'sectionTitle' in page,
        'Question layouts and group headings must be persisted and printable')
main_activity = (ROOT/'android/app/src/main/kotlin/com/waraqi/studio/MainActivity.kt').read_text(encoding='utf-8')
require('MethodChannel(flutterEngine.dartExecutor.binaryMessenger' in main_activity
        and 'RecognizerIntent.ACTION_RECOGNIZE_SPEECH' in main_activity
        and 'onActivityResult(' in main_activity
        and 'com.waraqi.studio/voice' in main_activity,
        'Native speech fallback channel missing after Android scaffolding')
require('com.waraqi.studio/voice' in voice and 'TimeoutException' in voice
        and 'seconds: 12' in voice and '_startSystemDictation' in voice,
        'Speech recognition must have a fallback and bounded initialization')
require('tessedit_pageseg_mode' in app and 'pageMode: pageMode' in app
        and "choice == 'keep-image'" in app,
        'OCR layout choices or lossless image fallback are disconnected')
require('InteractiveViewer(' in app and '_showZoomedPage' in app,
        'A4 preview needs a legible zoom route')
require('android.permission.CAMERA' in manifest, 'Camera permission missing')
require('com.waraqi.studio' in (ROOT/'android/app/build.gradle.kts').read_text(encoding='utf-8'),
        'Wrong Android application namespace')
workflow = (ROOT/'.github/workflows/build-waraqi-android.yml').read_text(encoding='utf-8')
require('flutter analyze' in workflow and 'flutter test --reporter expanded' in workflow
        and 'flutter build apk --release' in workflow, 'Incomplete GitHub Actions quality gates')
require(f'waraqi-v{version_name}.apk' in workflow,
        f'APK version mismatch: expected waraqi-v{version_name}.apk')
require(f'{expected_folder}.zip' in workflow,
        f'GitHub workflow source archive mismatch: expected {expected_folder}.zip')



# v1.6.1: analyzer regression guards for the two errors reported from v1.6.0,
# plus the default premium-template question Text key used by widget tests.
require("import 'dart:convert';" in share_service and 'base64Encode(bytes)' in share_service,
        'Image embedding calls base64Encode without importing dart:convert')
require('_metaText(' not in page,
        'Unused _metaText helper reintroduced (flutter analyze fails on warnings)')
require("Text(questionTitle,key:ValueKey('exam-question-$index')" in page,
        'Premium template must expose the same question Text key as the legacy layout')
require("..paperLayout = 'globalEmerald'" in app,
        'New documents must start with the selected premium default template')
require('premium final-result template defaults and historical layout migration' in tests,
        'Premium layout persistence and migration regression test missing')

# Added offline library, question bank, image-complete backup and page breaks.
archive = (ROOT/'lib/services/paper_archive.dart').read_text(encoding='utf-8')
require('file_picker: ^10.3.10' in pubspec and 'package:file_picker/file_picker.dart' in app,
        'Backup restore requires the pinned file_picker API')
require(all(x in archive for x in (
    'saveDocument(', 'documents()', 'addToBank(', 'bank()',
    'exportBackup()', 'importBackup(', 'backupSchema', 'images',
)), 'Paper archive and question bank methods are incomplete')
require(all(x in app for x in (
    '_openDocuments()', '_openQuestionBank()', '_backupOptions()',
    '_saveQuestionToBank(', 'إدراج سؤال من البنك',
)), 'Document library or question bank is not reachable from the UI')
require('pageBreakBefore' in model and 'q.pageBreakBefore' in page
        and 'page-break-before:always' in share_service,
        'Manual page breaks must persist and export into PDF pagination and Word')

print(f'PASS: {len(sources)} Dart sources balanced, OCR asset config and Android/Flutter wiring checked')
print('PASS: print-digit renderer shares one formatter and widget test inspects real Text nodes')
print('PASS: CI quality gates, version and source metadata align')
print('PASS: Release resource shrinking and code minification flags are compatible')
print('NOTE: These are preflight checks only; Flutter analyzer/tests/build run on GitHub.')

# Advanced editor and genuine DOCX safeguards: source preflight, not execution.
advanced_docx = (ROOT/'lib/services/docx_export.dart').read_text(encoding='utf-8')
math_widget = (ROOT/'lib/widgets/math_renderer.dart').read_text(encoding='utf-8')
geometry_widget = (ROOT/'lib/widgets/geometry_editor.dart').read_text(encoding='utf-8')
booklet_widget = (ROOT/'lib/widgets/booklet_pages.dart').read_text(encoding='utf-8')
require('archive: ^4.0.9' in pubspec and 'ZipEncoder().encode(archive)' in advanced_docx
        and 'word/document.xml' in advanced_docx
        and 'DocxExport.generate(doc, answers: answers)' in share_service,
        'Real editable DOCX export must remain connected')
require('MathRenderer' in page and 'GeometryCanvas' in page and
        'showGeometryEditor' in app and 'TableEditorDialog' in app,
        'Geometry, math, or interactive table editing is disconnected')
require('BookletCoverPage' in app and 'BookletTocPage' in app
        and 'BookletPages.sections' in app and 'static List<BookletSectionEntry> sections' in booklet_widget and 'includeCover' in model,
        'Booklet front matter and TOC are disconnected')
require('branchPoints' in model and 'requiredBranches' in model
        and 'customNumber' in model and 'showSignatureLine' in page,
        'Advanced question scores or signature settings are missing')
require("test('Word export is real DOCX ZIP with editable OOXML and equations'" in tests,
        'DOCX regression test is missing')
print('PASS: advanced DOCX, geometry, math, table, booklet and question model wiring checked')


# v1.5.0: independently check new feature persistence/export wiring.
validator = (ROOT/'lib/services/document_validator.dart').read_text(encoding='utf-8')
rich = (ROOT/'lib/widgets/rich_school_text.dart').read_text(encoding='utf-8')
require(all(token in model for token in (
    'class PaperSubPoint', 'branchSubpoints', 'independentCopy()',
    'class PaperSignature', 'class PaperGridImage', 'galleryImages',
    'coverDesign', 'paperLanguage',
)), 'Nested question points, gallery or signature state is not persisted')
require(all(token in app for token in (
    '_branchEditor(', '_editSubPoint(', '_galleryEditor(', '_chemElementDialog(',
    '_richTextElementDialog(', 'signatures.add(', 'coverPalette(i)',
    '_validateForExport(', 'onPageOverflow:',
)), 'Advanced editing, gallery, covers or pre-export validation is disconnected')
require(all(token in page for token in (
    '_MeasuredQuestionBody(', 'RichSchoolText(', "case 'gallery':",
    "case 'poetry':", "case 'verse':", "case 'matching':",
    'q.branchSubpoints', 'd.signatures',
)), 'Print rendering of advanced elements is incomplete')
require(all(token in advanced_docx for token in (
    '_richParagraph(', "e.kind == 'gallery'", "e.kind == 'poetry'",
    "e.kind == 'verse'", "e.kind == 'matching'", 'q.branchSubpoints',
    'd.signatures',
)), 'DOCX rendering of advanced elements is incomplete')
require('galleryImages' in archive and 'image.path = mapping[image.path]' in archive,
    'Backup does not preserve and remap gallery images')
require('DocumentValidator.inspect' in app and 'blocking: true' in validator,
    'Missing pre-export validator')
require('Twenty original combinations' in booklet_widget and
    'static (Color, Color) coverPalette' in booklet_widget,
    'Twenty cover variants are missing')
require('class RichSchoolText' in rich and '_richParagraph' in advanced_docx,
    'Rich Arabic formatting must be rendered in both PDF and DOCX')
require(all(token in tests for token in (
    'nested points preserve individual scores',
    'cover designs, bilingual header, signatures and image-grid',
    'DOCX contains editable nested points and multiple signatures',
    'A4 reports an overlong body instead of automatically shrinking print text',
)), 'v1.5.0 regression tests are missing')
print('PASS: nested points, gallery, print/docx, 20 covers and export safety are wired')
