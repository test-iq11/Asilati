# OCR language models

This app bundles `ara.traineddata` and `eng.traineddata` for Tesseract OCR,
originally distributed with the open-source Tesseract language data packages.
The Tesseract project and its language data are published under Apache 2.0:
https://github.com/tesseract-ocr/tessdata_fast
https://github.com/tesseract-ocr/tesseract/blob/main/LICENSE
The language data files were copied from the locally installed Tesseract 5
runtime, not modified or trained by this application.

Both files are included in the Flutter `assets` section so OCR can work offline.
Their inclusion increases the app size, but avoids relying on a server.
