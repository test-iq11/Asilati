package com.waraqi.studio

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/**
 * Android speech input dialog is an independent fallback when an embedded
 * SpeechRecognizer does not initialize on a particular device.
 */
class MainActivity : FlutterActivity() {
    private val voiceRequestCode = 8127
    private var voiceResult: MethodChannel.Result? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "com.waraqi.studio/voice")
            .setMethodCallHandler { call, result ->
                if (call.method != "recognize") {
                    result.notImplemented()
                } else if (voiceResult != null) {
                    result.error("VOICE_BUSY", "هناك جلسة إملاء قيد التشغيل", null)
                } else {
                    val locale = call.argument<String>("locale") ?: "ar-IQ"
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, locale)
                        putExtra(RecognizerIntent.EXTRA_PROMPT, "تحدث لكتابة نص السؤال")
                        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                    }
                    try {
                        voiceResult = result
                        startActivityForResult(intent, voiceRequestCode)
                    } catch (error: Exception) {
                        voiceResult = null
                        result.error("VOICE_UNAVAILABLE",
                            "لا يوجد تطبيق للتعرف الصوتي يدعم الإملاء على هذا الهاتف: ${error.message}", null)
                    }
                }
            }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == voiceRequestCode) {
            val reply = voiceResult
            voiceResult = null
            if (reply != null) {
                if (resultCode == Activity.RESULT_OK) {
                    reply.success(data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                        ?.firstOrNull()?.trim())
                } else {
                    reply.success(null) // User canceled; leave the draft unchanged.
                }
            }
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }
}
