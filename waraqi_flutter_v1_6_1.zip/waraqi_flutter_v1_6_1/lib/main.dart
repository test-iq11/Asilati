import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:tesseract_ocr/tesseract_ocr.dart';
import 'package:tesseract_ocr/ocr_engine_config.dart';
import 'services/ocr_text_tools.dart';
import 'screens/voice_dictation_sheet.dart';
import 'models/paper_document.dart';
import 'services/paper_storage.dart';
import 'services/paper_archive.dart';
import 'services/print_service.dart';
import 'services/document_validator.dart';
import 'screens/crop_capture_screen.dart';
import 'widgets/paper_pages.dart';
import 'widgets/booklet_pages.dart';
import 'widgets/math_renderer.dart';
import 'widgets/geometry_editor.dart';
import 'screens/table_editor_dialog.dart';
import 'theme.dart';

void main() { WidgetsFlutterBinding.ensureInitialized(); runApp(const WaraqiApp()); }

class WaraqiApp extends StatelessWidget {
  const WaraqiApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner:false,
    title:'ورقتي | منشئ الأوراق الامتحانية',
    theme:appTheme(),
    locale:const Locale('ar','IQ'),
    supportedLocales:const [Locale('ar','IQ'),Locale('en','US')],
    localizationsDelegates:const [
      GlobalMaterialLocalizations.delegate,
      GlobalCupertinoLocalizations.delegate,
      GlobalWidgetsLocalizations.delegate,
    ],
    builder:(context,child)=>Directionality(textDirection:TextDirection.rtl,child:child!),
    home:const StudioScreen(),
  );
}

const _subjects = ['الرياضيات','اللغة العربية','اللغة الإنجليزية','العلوم','الفيزياء','الكيمياء','الأحياء','التربية الإسلامية','الاجتماعيات','اللغة الكردية','مادة عامة'];
const _fieldLabels = <String,String>{
  'country':'الدولة','ministry':'الوزارة','directorate':'المديرية',
  'school':'المدرسة','title':'عنوان الورقة','academicYear':'العام الدراسي',
  'subject':'المادة','grade':'الصف','total':'الدرجة الكلية',
  'duration':'الوقت','date':'التاريخ',
};
const _elements = <String,String>{
  'math':'معادلة رياضية','chem':'معادلة كيميائية','table':'جدول','drawing':'رسم توضيحي',
  'poetry':'شعر','text':'نص منسق','tf':'صح أو خطأ','options':'اختيارات',
  'verse':'آية أو حديث','space':'مساحة إجابة','columns':'فقرات بأعمدة',
  'matching':'مطابقة','geometry':'رسم هندسي تفاعلي','gallery':'شبكة صور','photo':'استخراج نص من صورة','image':'صورة توضيحية',
};
const _elementIcons = <String,IconData>{
  'math':Icons.functions,'chem':Icons.science_outlined,'table':Icons.table_chart_outlined,
  'drawing':Icons.draw_outlined,'poetry':Icons.format_quote,'text':Icons.text_fields,
  'tf':Icons.fact_check_outlined,'options':Icons.list_alt,'verse':Icons.menu_book_outlined,
  'space':Icons.edit_note,'columns':Icons.view_column_outlined,'matching':Icons.compare_arrows,
  'gallery':Icons.grid_view_outlined,'geometry':Icons.architecture_outlined,'photo':Icons.document_scanner_outlined,'image':Icons.image_outlined,
};

class StudioScreen extends StatefulWidget {
  const StudioScreen({super.key});
  @override State<StudioScreen> createState()=>_StudioScreenState();
}

class _StudioScreenState extends State<StudioScreen> with WidgetsBindingObserver {
  final _storage=PaperStorage();
  final _archive=PaperArchive();
  PaperDocument _document=PaperDocument();
  int _tab=0;
  bool _loading=true;
  bool _answers=false;
  bool _busy=false;
  final _recognizing=<String>{};
  final _questionTextControllers=<String,TextEditingController>{};
  final _collapsed=<String>{};
  final _answersOpen=<String>{};
  List<GlobalKey> _previewKeys=[];
  final _pageOverflow=<int,bool>{};
  final _scroll=ScrollController();

  @override void initState(){super.initState();WidgetsBinding.instance.addObserver(this);_load();}
  @override void didChangeAppLifecycleState(AppLifecycleState state){
    if(!_loading && state!=AppLifecycleState.resumed){
      unawaited(_storage.saveNow(_document));
      unawaited(_archive.saveDocument(_document));
    }
  }
  Future<void> _load() async {
    final doc=await _storage.load();
    try {await _archive.saveDocument(doc);} catch (_) {}
    if(mounted)setState((){_document=doc;_loading=false;});
  }
  @override void dispose(){
    for(final controller in _questionTextControllers.values){controller.dispose();}
    WidgetsBinding.instance.removeObserver(this);
    _storage.dispose();_archive.dispose();_scroll.dispose();super.dispose();
  }
  TextEditingController _textController(PaperQuestion question)=>
      _questionTextControllers.putIfAbsent(question.id,()=>TextEditingController(text:question.text));
  void _saveSoon() {
    _storage.queueSave(_document);
    _archive.queueSave(_document);
  }
  void _edit(VoidCallback fn){setState(fn);_saveSoon();}
  void _to(int page){setState(()=>_tab=page);if(_scroll.hasClients)_scroll.jumpTo(0);}
  void _notice(String message){if(!mounted)return;ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(message),behavior:SnackBarBehavior.floating));}

  void _switchToDocument(PaperDocument doc) {
    for (final controller in _questionTextControllers.values) {
      controller.dispose();
    }
    _questionTextControllers.clear();
    _collapsed.clear();
    _answersOpen.clear();
    setState(() {
      _document = doc;
      _answers = false;
      _tab = 1;
    });
    _saveSoon();
  }

  Future<void> _openDocuments() async {
    await _archive.saveDocument(_document);
    final documents = await _archive.documents();
    if (!mounted) return;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(child:FractionallySizedBox(
        heightFactor: .78,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 9),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('مكتبتي — الأوراق والملازم', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
            const SizedBox(height: 5),
            const Text('يمكن فتح أي مستند أو إنشاء نسخة مستقلة منه دون فقدان المستند الحالي.', style: TextStyle(color: Palette.muted, fontSize: 12)),
            const SizedBox(height: 15),
            Expanded(child: ListView.separated(
              itemCount: documents.length,
              separatorBuilder: (_, __) => const SizedBox(height: 7),
              itemBuilder: (_, i) {
                final doc = documents[i];
                final current = doc.documentId == _document.documentId;
                return Container(
                  decoration: BoxDecoration(color: current ? Palette.mint : Palette.background, borderRadius: BorderRadius.circular(17)),
                  child: ListTile(
                    leading: Icon(doc.documentType == 'booklet' ? Icons.menu_book_outlined : Icons.description_outlined, color: Palette.teal),
                    title: Text(doc.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: Text('${doc.subject} • ${doc.grade} • ${doc.questions.length} سؤال', style: const TextStyle(fontSize: 11)),
                    onTap: () async {
                      Navigator.pop(sheetContext);
                      if (!current) {
                        await _archive.saveDocument(_document);
                        if (mounted) _switchToDocument(doc);
                      }
                    },
                    trailing: PopupMenuButton<String>(
                      onSelected: (value) async {
                        if (value == 'duplicate') {
                          final copy = PaperDocument.decode(doc.encode())
                            ..documentId = newId()
                            ..title = 'نسخة من ${doc.title}';
                          await _archive.saveDocument(copy);
                          if (sheetContext.mounted) Navigator.pop(sheetContext);
                          if (mounted) _switchToDocument(copy);
                        } else if (value == 'delete' && !current) {
                          await _archive.removeDocument(doc.documentId);
                          if (sheetContext.mounted) Navigator.pop(sheetContext);
                          _notice('حُذف المستند من مكتبتي.');
                        }
                      },
                      itemBuilder: (_) => [
                        const PopupMenuItem(value: 'duplicate', child: Text('حفظ كنسخة جديدة')),
                        if (!current) const PopupMenuItem(value: 'delete', child: Text('حذف المستند')),
                      ],
                    ),
                  ),
                );
              },
            )),
          ]),
        ),
      )),
    );
  }

  Future<void> _saveQuestionToBank(PaperQuestion question) async {
    try {
      await _archive.addToBank(question, subject: _document.subject, grade: _document.grade);
      _notice('تم حفظ السؤال بفروعه وعناصره في بنك الأسئلة.');
    } catch (e) {
      _notice('تعذّر حفظ السؤال: $e');
    }
  }

  Future<void> _openQuestionBank() async {
    final entries = await _archive.bank();
    if (!mounted) return;
    var search = '';
    var subjectFilter = 'الكل';
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => StatefulBuilder(builder: (sheetContext, refresh) => SafeArea(
        child: FractionallySizedBox(heightFactor: .80, child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 7),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('بنك الأسئلة', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 5),
            const Text('اضغط على السؤال لإدراج نسخة مستقلة في الورقة الحالية.', style: TextStyle(fontSize: 12, color: Palette.muted)),
            const SizedBox(height: 13),
            TextField(onChanged: (value) => refresh(() => search = value.trim().toLowerCase()),
              decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'ابحث عن السؤال أو المادة أو الصف')),
            const SizedBox(height: 8),
            SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: [
              for(final subject in ['الكل', ...entries.map((e)=>e.subject).toSet().take(9)])
                Padding(padding: const EdgeInsets.only(left: 6), child: ChoiceChip(
                  label: Text(subject), selected: subjectFilter==subject,
                  onSelected: (_) => refresh(()=>subjectFilter=subject))),
            ])),
            const SizedBox(height: 13),
            Expanded(child: Builder(builder: (_) {
              final filtered = entries.where((entry) => (subjectFilter=='الكل'||entry.subject==subjectFilter) &&
                '${entry.question.text} ${entry.subject} ${entry.grade} ${entry.question.sectionTitle} ${entry.question.tags}'
                  .toLowerCase().contains(search)).take(200).toList();
              if (filtered.isEmpty) return const Center(child: Text('لا توجد أسئلة مطابقة. احفظ سؤالاً أولاً من قائمة خياراته.'));
              return ListView.separated(
                itemCount: filtered.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (_, i) {
                  final entry = filtered[i];
                  return Container(
                    decoration: BoxDecoration(color: Palette.background, borderRadius: BorderRadius.circular(16)),
                    child: ListTile(
                      leading: const Icon(Icons.library_books_outlined, color: Palette.teal),
                      title: Text(entry.question.text.isEmpty ? 'سؤال بلا نص' : entry.question.text,
                        maxLines: 2, overflow: TextOverflow.ellipsis),
                      subtitle: Text('${entry.subject} • ${entry.grade} • ${entry.question.points} درجة', style: const TextStyle(fontSize: 11)),
                      onTap: () {
                        final independentCopy = entry.question.independentCopy();
                        _edit(() => _document.questions.add(independentCopy));
                        Navigator.pop(sheetContext);
                        _notice('أُدرج السؤال من البنك ويمكن تعديله مستقلاً.');
                      },
                      trailing: IconButton(
                        tooltip: 'حذف من البنك', icon: const Icon(Icons.delete_outline),
                        onPressed: () async {
                          await _archive.removeFromBank(entry.id);
                          refresh(() => entries.removeWhere((item) => item.id == entry.id));
                        },
                      ),
                    ),
                  );
                },
              );
            })),
          ]),
        )),
      )),
    );
  }

  Future<void> _shareBackup() async {
    try {
      await _archive.saveDocument(_document);
      final bytes = await _archive.exportBackup();
      final directory = await getTemporaryDirectory();
      final file = File('${directory.path}/waraqi_backup.json');
      await file.writeAsBytes(bytes, flush: true);
      await Share.shareXFiles([XFile(file.path, mimeType: 'application/json')], text: 'نسخة احتياطية من ورقتي');
    } catch (e) { _notice('تعذّر إنشاء النسخة الاحتياطية: $e'); }
  }

  Future<void> _importBackup() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom, allowedExtensions: ['json'], withData: true,
      );
      if (result == null || result.files.isEmpty) return;
      final picked = result.files.first;
      final bytes = picked.bytes ?? (picked.path == null ? null : await File(picked.path!).readAsBytes());
      if (bytes == null) throw const FormatException('تعذّر قراءة ملف النسخة الاحتياطية');
      final count = await _archive.importBackup(Uint8List.fromList(bytes));
      _notice('استُعيدت $count ورقة/ملزمة، وبنك الأسئلة، دون حذف المستندات الحالية.');
    } catch (e) { _notice('تعذّر استيراد النسخة الاحتياطية: $e'); }
  }

  Future<void> _backupOptions() async {
    await showModalBottomSheet<void>(context: context, showDragHandle: true, builder: (sheetContext) => SafeArea(
      child: Padding(padding: const EdgeInsets.all(18), child: Column(
        mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text('النسخ الاحتياطي', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          const Text('احفظ أوراقك وبنك الأسئلة والصور في ملف JSON على جهازك، أو استعد نسخة دون حذف الملفات الموجودة.', style: TextStyle(color: Palette.muted)),
          const SizedBox(height: 17),
          _secondaryButton('حفظ ومشاركة نسخة احتياطية', Icons.file_upload_outlined, () { Navigator.pop(sheetContext); _shareBackup(); }),
          const SizedBox(height: 10),
          _secondaryButton('استيراد نسخة احتياطية', Icons.file_download_outlined, () { Navigator.pop(sheetContext); _importBackup(); }),
        ],
      )),
    ));
  }

  Future<void> _newDocument() async {
    var subject=_document.subject;
    var type='exam';
    final created=await showModalBottomSheet<bool>(context:context,isScrollControlled:true,backgroundColor:Colors.transparent,builder:(context)=>StatefulBuilder(builder:(context,change)=>SafeArea(child:Container(
      padding:EdgeInsets.fromLTRB(20,24,20,24+MediaQuery.of(context).viewInsets.bottom),
      decoration:const BoxDecoration(color:Colors.white,borderRadius:BorderRadius.vertical(top:Radius.circular(30))),
      child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('إنشاء مستند جديد',style:TextStyle(fontSize:23,fontWeight:FontWeight.w900)),
        const SizedBox(height:7),const Text('اختر المادة ونوع الورقة ثم ابدأ التحرير.',style:TextStyle(color:Palette.muted)),
        const SizedBox(height:22),const Text('نوع المستند',style:TextStyle(fontWeight:FontWeight.w800)),
        const SizedBox(height:9),Row(children:[Expanded(child:_choice('ورقة أسئلة',type=='exam',()=>change(()=>type='exam'))),const SizedBox(width:10),Expanded(child:_choice('ملزمة',type=='booklet',()=>change(()=>type='booklet')))]),
        const SizedBox(height:23),const Text('المادة الدراسية',style:TextStyle(fontWeight:FontWeight.w800)),const SizedBox(height:10),
        Wrap(spacing:8,runSpacing:8,children:_subjects.map((s)=>_choice(s,subject==s,()=>change(()=>subject=s))).toList()),
        const SizedBox(height:25),_mainButton('إنشاء المستند',Icons.add_circle_outline,()=>Navigator.pop(context,true)),
        const SizedBox(height:7),Center(child:TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('إلغاء'))),
      ])),
    ))));
    if(created==true){
      await _archive.saveDocument(_document);
      final createdDoc = PaperDocument()
        ..subject = subject
        ..title = '${type == 'booklet' ? 'ملزمة' : 'ورقة'} $subject'
        ..documentType = type
        ..paperLayout = 'globalEmerald'
        ..questions = [];
      _switchToDocument(createdDoc);
      await _archive.saveDocument(createdDoc);
      _notice('تم إنشاء مستند جديد وحفظ المستند السابق في مكتبتي.');
    }
  }

  /// OCR is the intended outcome of photographing a question: its pixels are
  /// only inserted as an image if the user explicitly chooses to keep the crop.
  Future<void> _captureQuestion(PaperQuestion question, bool fromCamera,
      {String? language, String pageMode = '6'}) async {
    if (_recognizing.contains(question.id)) return;
    try {
      final cropped = await Navigator.push<List<int>>(context,
          MaterialPageRoute(builder: (_) =>
              CropCaptureScreen(fromCamera: fromCamera)));
      if (!mounted || cropped == null || cropped.isEmpty) return;
      setState(() => _recognizing.add(question.id));
      File? temporary;
      try {
        final directory = await getTemporaryDirectory();
        temporary = File('${directory.path}/waraqi_ocr_${newId()}.png');
        await temporary.writeAsBytes(
            OcrTextTools.prepareForOcr(cropped), flush: true);
        final effectiveLanguage = language ??
            (_document.subject == 'اللغة الإنجليزية' ? 'eng' : 'ara');
        final recognized = await TesseractOcr.extractText(
          temporary.path,
          config: OCRConfig(language: effectiveLanguage,
              engine: OCREngine.tesseract, options: {
                'preserve_interword_spaces': '1',
                'tessedit_pageseg_mode': pageMode,
              }),
        );
        if (!mounted) return;
        await _reviewExtractedText(question, recognized, sourceImage: cropped,
            arabicOnly: effectiveLanguage == 'ara');
      } finally {
        if (temporary != null && await temporary.exists()) {
          await temporary.delete();
        }
      }
    } catch (e) {
      _notice('تعذّر استخراج النص. حاول قص منطقة أصغر أو تحسين التصوير: $e');
    } finally {
      if (mounted) setState(() => _recognizing.remove(question.id));
    }
  }

  Future<void> _reviewExtractedText(PaperQuestion question, String raw,
      {required bool arabicOnly, required List<int> sourceImage}) async {
    final normalized = OcrTextTools.clean(raw, arabicOnly: arabicOnly);
    if (normalized.isEmpty) {
      if (!mounted) return;
      final keep = await showDialog<bool>(context: context, builder: (dialog) =>
          AlertDialog(
            title: const Text('تعذّر قراءة النص'),
            content: const Text('لم يكتشف المحرك نصاً موثوقاً. يمكنك الاحتفاظ بصورة السؤال دون تغيير أرقامه، أو المحاولة من جديد بصورة أوضح.'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(dialog, false),
                  child: const Text('إعادة المحاولة')),
              FilledButton(onPressed: () => Navigator.pop(dialog, true),
                  child: const Text('إضافة صورة السؤال كما هي')),
            ],
          ));
      if (keep == true) {
        final imagePath = await _storage.saveImage(sourceImage);
        if (!mounted) return;
        _edit(() => question.elements.add(PaperElement(
            id: newId(), kind: 'image', imagePath: imagePath)));
        _notice('تم حفظ صورة السؤال الأصلية.');
      }
      return;
    }
    final controller = TextEditingController(text: normalized);
    final removedLatin = arabicOnly && OcrTextTools.hasLatinWords(raw);
    try {
      final choice = await showDialog<String>(context: context,
          builder: (dialog) => AlertDialog(
        title: const Text('مراجعة النص المستخرج',
            style: TextStyle(fontWeight: FontWeight.w900)),
        content: SizedBox(width: 500, child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('التعرف الآلي غير مضمون، وخاصة أرقام ٠١٢٣٤٥٦٧٨٩ والعمليات الرياضية. قارن كل سطر بالصورة قبل الإضافة.',
                style: TextStyle(color: Palette.muted, fontSize: 12)),
            if (removedLatin) const Padding(
              padding: EdgeInsets.only(top: 9),
              child: Text('تم استبعاد سلاسل لاتينية أثناء وضع العربية فقط. يمكنك إرجاع النص الخام أدناه إن كانت بعض الكلمات مقصودة.',
                  style: TextStyle(color: Color(0xFF8A611B), fontSize: 12)),
            ),
            if (removedLatin) TextButton(
              onPressed: () => controller.text = raw.trim(),
              child: const Text('استعادة النص الخام'),
            ),
            const SizedBox(height: 10),
            const Text('الصورة الأصلية — قارن خصوصاً الأرقام',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800)),
            Container(
              height: 255, padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(color: Colors.white,
                  border: Border.all(color: Palette.line),
                  borderRadius: BorderRadius.circular(12)),
              child: InteractiveViewer(
                minScale: 1, maxScale: 7,
                child: Image.memory(Uint8List.fromList(sourceImage),
                  fit: BoxFit.contain),
              ),
            ),
            const Text('كبّر الصورة بإصبعين لمقارنة كل رقم. يمكن الاحتفاظ بصورة السؤال كما هي إذا أخطأ OCR.',
                style: TextStyle(fontSize: 11, color: Palette.muted)),
            const SizedBox(height: 12),
            TextField(controller: controller, textDirection: TextDirection.rtl,
                textAlign: TextAlign.right, minLines: 5, maxLines: 10,
                style: const TextStyle(fontSize: 16, height: 1.55),
                decoration: const InputDecoration(
                    labelText: 'نص قابل للتحرير', hintText: 'صحح النص والأرقام هنا')),
            TextButton.icon(
              icon: const Icon(Icons.restore_outlined),
              label: const Text('عرض النص الخام كما اكتشفه المحرك'),
              onPressed: () => controller.text = raw.trim(),
            ),
          ]),
        )),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialog),
              child: const Text('إلغاء')),
          OutlinedButton(onPressed: () => Navigator.pop(dialog, 'keep-image'),
              child: const Text('احتفظ بالصورة كما هي')),
          OutlinedButton(onPressed: () => Navigator.pop(dialog, 'append'),
              child: const Text('إضافة للنص')),
          FilledButton(onPressed: () => Navigator.pop(dialog, 'replace'),
              child: const Text('استبدال النص')),
        ],
      ));
      if (choice == null || !mounted) return;
      if (choice == 'keep-image') {
        final imagePath = await _storage.saveImage(sourceImage);
        if (!mounted) return;
        _edit(() => question.elements.add(
            PaperElement(id: newId(), kind: 'image', imagePath: imagePath)));
        _notice('احتفظت بصورة السؤال الأصلية دون تغيير الأرقام.');
        return;
      }
      final result = controller.text.trim();
      if (result.isEmpty) { _notice('النص فارغ ولم يُضف'); return; }
      _edit(() {
        question.insertExtractedText(result, append: choice == 'append');
        final questionController = _textController(question);
        questionController.value = TextEditingValue(text: question.text,
            selection: TextSelection.collapsed(offset: question.text.length));
      });
      _notice('تم إدراج النص ويمكنك تحريره يدوياً.');
    } finally {
      controller.dispose();
    }
  }

  Future<void> _dictateQuestion(PaperQuestion question, {int? branch}) async {
    final result = await showModalBottomSheet<String>(context: context,
      isScrollControlled: true, showDragHandle: true,
      builder: (_) => VoiceDictationSheet(
          preferEnglish: _document.subject == 'اللغة الإنجليزية'));
    if (!mounted || result == null || result.trim().isEmpty) return;
    _edit(() {
      if (branch != null && branch >= 0 && branch < question.branches.length) {
        final old = question.branches[branch];
        question.branches[branch] = old.trim().isEmpty ? result.trim() :
            '$old ${result.trim()}';
      } else {
        question.insertExtractedText(result, append: true);
        _textController(question).value = TextEditingValue(
            text: question.text,
            selection: TextSelection.collapsed(offset: question.text.length));
      }
    });
  }

  /// Illustrative image elements stay separate from OCR and are explicitly
  /// opt-in (charts and pictures only, not question text capture).
  Future<void> _addIllustration(PaperQuestion question,bool fromCamera,{String kind='image'}) async {
    try {
      final image=await Navigator.push<List<int>>(context,MaterialPageRoute(
        builder:(_)=>CropCaptureScreen(fromCamera:fromCamera)));
      if(image==null || image.isEmpty || !mounted)return;
      final path=await _storage.saveImage(image);
      _edit(()=>question.elements.add(PaperElement(id:newId(),kind:kind,imagePath:path)));
      _notice('تمت إضافة الصورة التوضيحية إلى السؤال.');
    }catch(e){_notice('تعذّر إضافة الرسم: $e');}
  }

  Future<void> _pickLogo() async {
    try {
      final selected=await ImagePicker().pickImage(source:ImageSource.gallery,imageQuality:80,maxWidth:800);
      if(selected==null)return;
      final path=await _storage.saveImage(await selected.readAsBytes());
      _edit(()=>_document.logoPath=path);
    } catch(e){_notice('تعذّر اختيار الشعار: $e');}
  }

  void _addQuestion(){_edit(()=>_document.questions.add(PaperQuestion(id:newId(),points:5)));}
  void _removeQuestion(PaperQuestion question){_edit(()=>_document.questions.remove(question));}
  void _moveQuestion(int oldIndex,int diff){final next=oldIndex+diff;if(next<0||next>=_document.questions.length)return;_edit((){final q=_document.questions.removeAt(oldIndex);_document.questions.insert(next,q);});}
  void _cloneQuestion(PaperQuestion q){_edit((){_document.questions.insert(_document.questions.indexOf(q)+1,q.independentCopy());});}

  void _showElements(PaperQuestion q){
    showModalBottomSheet<void>(context:context,backgroundColor:Colors.transparent,isScrollControlled:true,builder:(context)=>SafeArea(child:Container(
      padding:const EdgeInsets.fromLTRB(17,17,17,27),
      decoration:const BoxDecoration(color:Colors.white,borderRadius:BorderRadius.vertical(top:Radius.circular(29))),
      child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
        Center(child:Container(width:40,height:4,decoration:BoxDecoration(color:Palette.line,borderRadius:BorderRadius.circular(2)))),
        const SizedBox(height:20),const Text('مكتبة العناصر',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),
        const Text('اختر العنصر المناسب، وستظهر البطاقات بألوان مريحة لتسهيل التمييز بين الأنواع.',style:TextStyle(color:Palette.muted)),const SizedBox(height:17),
        ConstrainedBox(constraints:BoxConstraints(maxHeight:MediaQuery.of(context).size.height*.60),child:SingleChildScrollView(child:LayoutBuilder(builder:(context,box){
          final items=_elements.entries.toList();
          final cell=(box.maxWidth-20)/3;
          const palettes=<({Color bg,Color fg})>[
            (bg:Color(0xFFE9F7F2),fg:Color(0xFF0F8A6A)),
            (bg:Color(0xFFEAF3FF),fg:Color(0xFF2B6CB0)),
            (bg:Color(0xFFFFF1E5),fg:Color(0xFFB8661F)),
            (bg:Color(0xFFF2ECFF),fg:Color(0xFF7754C3)),
            (bg:Color(0xFFFFEDF2),fg:Color(0xFFB83260)),
            (bg:Color(0xFFEAF7E7),fg:Color(0xFF4A8F29)),
          ];
          return Wrap(spacing:10,runSpacing:10,children:items.asMap().entries.map((entry){
            final index=entry.key;
            final e=entry.value;
            final palette=palettes[index%palettes.length];
            return InkWell(
              onTap:(){Navigator.pop(context);if(e.key=='photo'){_photoChoice(q);} else if(e.key=='gallery'){_galleryEditor(q);} else if(['image','drawing'].contains(e.key)){
                _addIllustration(q,false,kind:e.key);
              } else {_textElement(q,e.key);}},
              borderRadius:BorderRadius.circular(19),
              child:Container(
                width:cell,height:107,padding:const EdgeInsets.all(10),
                decoration:BoxDecoration(color:palette.bg,borderRadius:BorderRadius.circular(19),border:Border.all(color:palette.fg.withValues(alpha:.12))),
                child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
                  Container(width:42,height:42,decoration:BoxDecoration(color:Colors.white.withValues(alpha:.85),borderRadius:BorderRadius.circular(14)),child:Icon(_elementIcons[e.key],size:25,color:palette.fg)),
                  const SizedBox(height:9),
                  Text(e.value,textAlign:TextAlign.center,style:TextStyle(fontWeight:FontWeight.w800,fontSize:11.5,color:palette.fg,height:1.3)),
                ]),
              ),
            );
          }).toList());
        }))),
      ]),
    )));
  }

  void _photoChoice(PaperQuestion q) {
    var language = _document.subject == 'اللغة الإنجليزية' ? 'eng' : 'ara';
    var pageMode = '6';
    showModalBottomSheet<void>(context: context, showDragHandle: true,
      isScrollControlled: true, builder: (context) =>
      StatefulBuilder(builder: (context, update) => SafeArea(
        child: Padding(padding: const EdgeInsets.all(18),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('نص من صورة',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            const Text('صوّر الورقة كاملة أولاً ثم قص الجزء المطلوب. اختر لغة النص لتقليل الأحرف الوهمية.',
                style: TextStyle(color: Palette.muted), textAlign: TextAlign.center),
            const SizedBox(height: 14),
            Wrap(spacing: 7, runSpacing: 7, children: [
              _choice('عربي فقط', language == 'ara',
                  () => update(() => language = 'ara')),
              _choice('عربي + إنجليزي', language == 'ara+eng',
                  () => update(() => language = 'ara+eng')),
              _choice('إنجليزي فقط', language == 'eng',
                  () => update(() => language = 'eng')),
            ]),
            const SizedBox(height: 10),
            const Text('شكل الجزء المصوّر', style: TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            Wrap(spacing: 7, runSpacing: 7, children: [
              _choice('فقرة أو عدة أسطر', pageMode == '6',
                  () => update(() => pageMode = '6')),
              _choice('صفحة متعددة الفقرات', pageMode == '3',
                  () => update(() => pageMode = '3')),
              _choice('سطر واحد', pageMode == '7',
                  () => update(() => pageMode = '7')),
            ]),
            const SizedBox(height: 13),
            ListTile(leading: const Icon(Icons.camera_alt_rounded,
                color: Palette.teal),
              title: const Text('تصوير الورقة كاملة'),
              subtitle: const Text('ثم اختيار القص من الصورة الملتقطة'),
              onTap: () { Navigator.pop(context);
                _captureQuestion(q, true, language: language, pageMode: pageMode); }),
            ListTile(leading: const Icon(Icons.photo_library_outlined,
                color: Palette.teal),
              title: const Text('صورة محفوظة في الهاتف'),
              subtitle: const Text('ثم قص النص واستخراجه'),
              onTap: () { Navigator.pop(context);
                _captureQuestion(q, false, language: language, pageMode: pageMode); }),
          ]),
        ),
      )));
  }

  Future<void> _textElement(PaperQuestion q,String kind,{PaperElement? existing}) async {
    if(kind=='math'){
      await _mathElementDialog(q,existing:existing);
      return;
    }
    if(kind=='gallery'){
      await _galleryEditor(q,existing:existing);
      return;
    }
    if(kind=='text'){
      await _richTextElementDialog(q,existing:existing);
      return;
    }
    if(kind=='chem'){
      await _chemElementDialog(q,existing:existing);
      return;
    }
    if(kind=='table'){
      final text=await showDialog<String>(context:context,builder:(_)=>TableEditorDialog(initialText:existing?.text??''));
      if(text!=null){_edit((){if(existing!=null){existing.text=text;}else{q.elements.add(PaperElement(id:newId(),kind:kind,text:text));}});}
      return;
    }
    if(kind=='geometry'){
      final text=await showGeometryEditor(context,existing?.text??'');
      if(text!=null){_edit((){if(existing!=null){existing.text=text;}else{q.elements.add(PaperElement(id:newId(),kind:kind,text:text));}});}
      return;
    }
    final description=kind=='space'?'عدد أسطر الإجابة (مثال: 4)':kind=='poetry'?'كل بيت في سطر، وافصل الصدر والعجز بعلامة |':kind=='verse'?'اكتب النص ثم السورة ورقم الآية بعد علامة |':kind=='matching'?'كل سطر: العمود الأول | العمود الثاني | الإجابة (اختياري)':kind=='options'?'اكتب كل اختيار في سطر مستقل':'أدخل محتوى ${_elements[kind]}';
    final controller=TextEditingController(text:existing?.text??(kind=='space'?'3':''));
    final value=await showDialog<String>(context:context,builder:(context)=>AlertDialog(
      title:Text(existing==null?'إضافة ${_elements[kind]}':'تعديل ${_elements[kind]}'),
      content:Column(mainAxisSize:MainAxisSize.min,children:[Text(description,style:const TextStyle(color:Palette.muted,fontSize:12)),const SizedBox(height:12),TextField(controller:controller,maxLines:kind=='space'?1:5,decoration:const InputDecoration(hintText:'اكتب هنا...'))]),
      actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(context,controller.text),child:const Text('حفظ'))],
    ));
    controller.dispose();
    if(value!=null){_edit((){if(existing!=null){existing.text=value;} else {q.elements.add(PaperElement(id:newId(),kind:kind,text:value));}});}
  }

  Future<void> _richTextElementDialog(PaperQuestion q,{PaperElement? existing}) async {
    final controller=TextEditingController(text:existing?.text??'');
    void wrapSelection(String marker){
      final value=controller.value;
      final from=value.selection.isValid?value.selection.start:value.text.length;
      final to=value.selection.isValid?value.selection.end:value.text.length;
      final selected=value.text.substring(from,to);
      final wrapped='$marker$selected$marker';
      controller.value=TextEditingValue(text:value.text.replaceRange(from,to,wrapped),
        selection:TextSelection.collapsed(offset:from+wrapped.length));
    }
    try {
      final result=await showDialog<String>(context:context,builder:(dialogContext)=>
        AlertDialog(title:const Text('النص العربي المنسق'),
          content:SizedBox(width:500,child:Column(mainAxisSize:MainAxisSize.min,children:[
            const Text('حدّد عبارة ثم اختر نوع التنسيق. يمكن إضافة الحركات العربية من لوحة المفاتيح.',
              style:TextStyle(fontSize:12,color:Palette.muted)),
            const SizedBox(height:10),
            Wrap(spacing:8,runSpacing:8,children:[
              OutlinedButton.icon(onPressed:()=>wrapSelection('**'),
                icon:const Icon(Icons.format_bold),label:const Text('غامق')),
              OutlinedButton.icon(onPressed:()=>wrapSelection('__'),
                icon:const Icon(Icons.format_underlined),label:const Text('تحته خط')),
              OutlinedButton.icon(onPressed:()=>wrapSelection('~~'),
                icon:const Icon(Icons.format_strikethrough),label:const Text('شطب')),
            ]),
            const SizedBox(height:10),
            TextField(controller:controller,minLines:4,maxLines:10,
              decoration:const InputDecoration(labelText:'محتوى النص')),
          ])),
          actions:[TextButton(onPressed:()=>Navigator.pop(dialogContext),child:const Text('إلغاء')),
            FilledButton(onPressed:()=>Navigator.pop(dialogContext,controller.text),child:const Text('حفظ'))],
        ));
      if(result!=null && mounted)_edit((){
        if(existing!=null){existing.text=result;}else{
          q.elements.add(PaperElement(id:newId(),kind:'text',text:result));
        }
      });
    }finally{controller.dispose();}
  }

  Future<void> _chemElementDialog(PaperQuestion q,{PaperElement? existing}) async {
    final controller=TextEditingController(text:existing?.text??'');
    const groups=<String,List<String>>{
      'التفاعلات':['→','⇌','↑','↓','Δ','+','(s)','(l)','(g)','(aq)'],
      'العناصر والرموز':['H₂O','CO₂','O₂','H⁺','OH⁻','e⁻','Na⁺','Cl⁻','⇄'],
      'الروابط':['—','=','≡','·','[',']','(',')','°C'],
    };
    var selected=groups.keys.first;
    void insert(String token) {
      final value=controller.value;
      final from=value.selection.isValid?value.selection.start:value.text.length;
      final to=value.selection.isValid?value.selection.end:value.text.length;
      final updated=value.text.replaceRange(from,to,token);
      controller.value=TextEditingValue(text:updated,
        selection:TextSelection.collapsed(offset:from+token.length));
    }
    try {
      final result=await showDialog<String>(context:context,builder:(dialogContext)=>
        StatefulBuilder(builder:(dialogContext,refresh)=>AlertDialog(
          title:const Text('محرر المعادلة الكيميائية'),
          content:SizedBox(width:520,child:SingleChildScrollView(child:Column(
            mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.stretch,children:[
              const Text('اكتب الصيغة واستعمل أزرار الروابط وحالات المادة والتفاعلات.',
                style:TextStyle(color:Palette.muted,fontSize:12)),
              const SizedBox(height:9),
              Wrap(spacing:6,runSpacing:6,children:[for(final category in groups.keys)
                ChoiceChip(label:Text(category),selected:selected==category,
                  onSelected:(_)=>refresh(()=>selected=category))]),
              const SizedBox(height:8),
              Wrap(spacing:7,runSpacing:7,children:[for(final token in groups[selected]!)
                ActionChip(label:Text(token),onPressed:()=>refresh(()=>insert(token)))]),
              const SizedBox(height:14),
              TextField(controller:controller,textDirection:TextDirection.ltr,minLines:3,maxLines:6,
                decoration:const InputDecoration(labelText:'المعادلة',hintText:'2H₂ + O₂ → 2H₂O')),
            ]))),
          actions:[TextButton(onPressed:()=>Navigator.pop(dialogContext),child:const Text('إلغاء')),
            FilledButton(onPressed:()=>Navigator.pop(dialogContext,controller.text),child:const Text('حفظ'))],
        )));
      if(result!=null && mounted){_edit((){if(existing!=null){existing.text=result;}else{
        q.elements.add(PaperElement(id:newId(),kind:'chem',text:result));}});}
    }finally{controller.dispose();}
  }

  Future<void> _galleryEditor(PaperQuestion q,{PaperElement? existing}) async {
    final items=(existing?.galleryImages ?? <PaperGridImage>[])
      .map((item)=>PaperGridImage(path:item.path,caption:item.caption)).toList();
    if(items.isEmpty && existing?.imagePath!=null){
      items.add(PaperGridImage(path:existing!.imagePath!));
    }
    await showDialog<void>(context:context,builder:(dialogContext)=>StatefulBuilder(
      builder:(dialogContext,refresh)=>AlertDialog(
        title:const Text('شبكة الصور'),
        content:SizedBox(width:540,height:360,child:Column(children:[
          const Text('اختر صوراً متعددة، ثم ضع عنواناً اختيارياً تحت كل صورة.',
            style:TextStyle(color:Palette.muted,fontSize:12)),
          const SizedBox(height:10),
          Expanded(child:ListView(children:[
            for(var i=0;i<items.length;i++) Card(child:Padding(
              padding:const EdgeInsets.all(8),child:Row(children:[
                SizedBox(width:55,height:55,child:Image.file(File(items[i].path),fit:BoxFit.cover,
                  errorBuilder:(_,__,___)=>const Icon(Icons.broken_image_outlined))),
                const SizedBox(width:8),
                Expanded(child:TextFormField(key:ValueKey('grid-caption-${items[i].path}'),
                  initialValue:items[i].caption,onChanged:(value)=>items[i].caption=value,
                  decoration:InputDecoration(labelText:'تعليق الصورة ${i+1}',isDense:true))),
                IconButton(onPressed:()=>refresh(()=>items.removeAt(i)),
                  icon:const Icon(Icons.delete_outline)),
              ]))),
          ])),
          const SizedBox(height:8),
          OutlinedButton.icon(onPressed:() async {
            final chosen=await ImagePicker().pickMultiImage(maxWidth:1800,imageQuality:88);
            if(chosen.isEmpty)return;
            for(final image in chosen.take(200-items.length)){
              final path=await _storage.saveImage(await image.readAsBytes());
              items.add(PaperGridImage(path:path));
            }
            if(dialogContext.mounted)refresh((){});
          },icon:const Icon(Icons.add_photo_alternate_outlined),label:const Text('إضافة صور من المعرض')),
        ])),
        actions:[TextButton(onPressed:()=>Navigator.pop(dialogContext),child:const Text('إلغاء')),
          FilledButton(onPressed:items.isEmpty?null:(){
            _edit((){if(existing!=null){
              existing.galleryImages..clear()..addAll(items);
              existing.imagePath=null;
            }else{
              q.elements.add(PaperElement(id:newId(),kind:'gallery',galleryImages:items));
            }});
            Navigator.pop(dialogContext);
          },child:const Text('حفظ الشبكة'))],
      )));
  }

  Future<void> _mathElementDialog(PaperQuestion q,{PaperElement? existing}) async {
    final controller=TextEditingController(text:existing?.text??'');
    const categories=<String,List<String>>{
      'أساسي':['xₙ','x^n','ⁿ√','√','a/b','( )','|x|','±'],
      'العمليات':['+','−','×','÷','=','≠','≈','≤','≥','∑','∏'],
      'المجموعات':['∈','∉','⊂','⊆','∪','∩','∅','ℕ','ℤ','ℚ','ℝ'],
      'الهندسة والمثلثات':['∠','△','°','π','⊥','∥','sin','cos','tan'],
      'التفاضل والتكامل':['lim','d/dx','∫','∬','∂','∇','f(x)','dx'],
      'المتجهات والوحدات':['v⃗','x̄','m/s','m/s²','N','μ','Ω','kg'],
    };
    var selected=categories.keys.first;
    void insertToken(String token){
      final value=controller.value;
      final selection=value.selection;
      final text=value.text;
      final start=selection.isValid?selection.start:text.length;
      final end=selection.isValid?selection.end:text.length;
      final newText=text.replaceRange(start,end,token);
      controller.value=TextEditingValue(text:newText,selection:TextSelection.collapsed(offset:start+token.length));
    }
    final result=await showDialog<String>(context:context,builder:(context)=>StatefulBuilder(builder:(context,setLocal)=>AlertDialog(
      title:Text(existing==null?'إضافة معادلة رياضية':'تعديل معادلة رياضية'),
      content:SizedBox(width:560,child:SingleChildScrollView(child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,mainAxisSize:MainAxisSize.min,children:[
        const Text('اختر القسم المناسب، ثم اضغط على الرموز لإدراجها داخل المعادلة. يمكنك كتابة LaTeX أو نص رياضي مباشرة أيضًا.',style:TextStyle(color:Palette.muted,fontSize:12,height:1.5)),
        const SizedBox(height:12),
        Wrap(spacing:8,runSpacing:8,children:categories.keys.map((name)=>_choice(name,selected==name,()=>setLocal(()=>selected=name))).toList()),
        const SizedBox(height:12),
        Wrap(spacing:8,runSpacing:8,children:categories[selected]!.map((token)=>ActionChip(label:Text(token,style:const TextStyle(fontWeight:FontWeight.w800)),onPressed:()=>setLocal(()=>insertToken(token)),backgroundColor:Colors.white)).toList()),
        const SizedBox(height:10),Wrap(spacing:8,runSpacing:8,children:[
          ActionChip(label:const Text('كسر مرتب'),onPressed:()=>setLocal(()=>insertToken(r'\frac{a}{b}'))),
          ActionChip(label:const Text('جذر'),onPressed:()=>setLocal(()=>insertToken(r'\sqrt{x}'))),
          ActionChip(label:const Text('أس'),onPressed:()=>setLocal(()=>insertToken('x^{2}'))),
        ]),
        const SizedBox(height:10),
        ValueListenableBuilder<TextEditingValue>(valueListenable:controller,builder:(context,value,_)=>Container(
          width:double.infinity,padding:const EdgeInsets.all(12),
          decoration:BoxDecoration(color:const Color(0xFFF4F8FA),borderRadius:BorderRadius.circular(12)),
          child:MathRenderer(value.text.isEmpty?'x² + 1':value.text,fontSize:19),
        )),
        const SizedBox(height:14),
        Container(padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:const Color(0xFFFFF7DA),borderRadius:BorderRadius.circular(16)),child:const Row(children:[Icon(Icons.info_outline,color:Color(0xFF8C6A1B)),SizedBox(width:8),Expanded(child:Text('إذا تُركت المعادلة فارغة تبقى المسودة محفوظة كما كتبتها لاحقًا.',style:TextStyle(fontSize:11.5,color:Color(0xFF6E5317))))])),
        const SizedBox(height:12),
        TextField(controller:controller,minLines:5,maxLines:8,textDirection:TextDirection.ltr,decoration:const InputDecoration(labelText:'المعادلة',hintText:'مثال: x^2-5x+6=0 أو LaTeX')),
      ]))),
      actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(context,controller.text),child:const Text('حفظ'))],
    )));
    controller.dispose();
    if(result!=null){_edit((){if(existing!=null){existing.text=result;} else {q.elements.add(PaperElement(id:newId(),kind:'math',text:result));}});}
  }

  Future<bool> _validateForExport() async {
    final issues=DocumentValidator.inspect(_document,answers:_answers);
    if(issues.isEmpty)return true;
    if(!mounted)return false;
    final blocked=issues.any((issue)=>issue.blocking);
    final choice=await showDialog<bool>(context:context,builder:(dialogContext)=>AlertDialog(
      title:Text(blocked?'مشكلات تمنع التصدير':'ملاحظات قبل التصدير'),
      content:SizedBox(width:490,child:SingleChildScrollView(child:Column(
        mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
          for(final issue in issues)Padding(padding:const EdgeInsets.only(bottom:10),
            child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
              Icon(issue.blocking?Icons.error_outline:Icons.info_outline,
                color:issue.blocking?Colors.redAccent:const Color(0xFF95671C),size:19),
              const SizedBox(width:7),Expanded(child:Text(issue.message)),
            ])),
        ]))),
      actions:[
        TextButton(onPressed:()=>Navigator.pop(dialogContext,false),
          child:Text(blocked?'رجوع للتحرير':'إلغاء')),
        if(!blocked)FilledButton(onPressed:()=>Navigator.pop(dialogContext,true),
          child:const Text('متابعة التصدير')),
      ],
    ));
    return choice==true && !blocked;
  }

  Future<void> _chooseExportFormat() async {
    if(_busy)return;
    showModalBottomSheet<void>(context:context,showDragHandle:true,builder:(context)=>SafeArea(child:Padding(
      padding:const EdgeInsets.fromLTRB(18,10,18,18),
      child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        const Text('اختر الصيغة النهائية',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),
        const SizedBox(height:8),
        const Text('يمكنك الآن إخراج الورقة النهائية بصيغة PDF أو Word حسب حاجتك.',style:TextStyle(color:Palette.muted)),
        const SizedBox(height:16),
        _secondaryButton('حفظ أو مشاركة PDF',Icons.picture_as_pdf_outlined,(){Navigator.pop(context);_exportPdf();}),
        const SizedBox(height:10),
        _secondaryButton('حفظ أو مشاركة Word',Icons.description_outlined,(){Navigator.pop(context);_exportWord();}),
      ]),
    )));
  }

  Future<void> _exportPdf() async {
    await _export(true);
  }

  Future<void> _exportWord() async {
    if(_busy)return;
    if(!await _validateForExport())return;
    if(!mounted)return;
    setState(()=>_busy=true);
    try{
      await PrintService.shareWord(_document,answers:_answers);
    }catch(e){_notice('تعذّر تجهيز ملف Word: $e');}
    if(mounted)setState(()=>_busy=false);
  }

  @override Widget build(BuildContext context){
    if(_loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    final pages=['الرئيسية','بيانات الورقة','محرر الأسئلة','التنسيق','معاينة الورقة'];
    return Scaffold(
      appBar:AppBar(title:Row(children:[Container(width:39,height:39,decoration:BoxDecoration(color:Palette.teal,borderRadius:BorderRadius.circular(13)),child:const Icon(Icons.description_rounded,color:Colors.white,size:22)),const SizedBox(width:10),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('ورقتي',style:TextStyle(fontWeight:FontWeight.w900,fontSize:21)),Text(pages[_tab],style:const TextStyle(fontSize:11,color:Palette.muted,fontWeight:FontWeight.w400))]))]),actions:[IconButton(tooltip:'حفظ',onPressed:() async {await _storage.saveNow(_document);await _archive.saveDocument(_document);_notice('تم حفظ الورقة في مكتبتي');},icon:const Icon(Icons.save_outlined)),IconButton(tooltip:'مستند جديد',onPressed:_newDocument,icon:const Icon(Icons.add_box_outlined)),const SizedBox(width:5)]),
      body:SingleChildScrollView(controller:_scroll,padding:const EdgeInsets.fromLTRB(14,6,14,110),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:1050),child:Center(child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        if(_tab==0)_home(),if(_tab==1)_data(),if(_tab==2)_questions(),if(_tab==3)_format(),if(_tab==4)_preview(),
      ])))),
      bottomNavigationBar:SafeArea(top:false,child:Container(margin:const EdgeInsets.fromLTRB(12,0,12,9),padding:const EdgeInsets.symmetric(vertical:7,horizontal:4),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(25),boxShadow:[BoxShadow(color:Palette.ink.withValues(alpha:.10),blurRadius:22,offset:const Offset(0,5))]),child:Row(children:[
        _nav(0,Icons.grid_view_rounded,'الرئيسية'),_nav(1,Icons.ballot_outlined,'البيانات'),_nav(2,Icons.list_alt_rounded,'الأسئلة'),_nav(3,Icons.tune_rounded,'التنسيق'),_nav(4,Icons.preview_outlined,'المعاينة'),
      ]))),
    );
  }

  Widget _nav(int index,IconData icon,String label){final active=_tab==index;return Expanded(child:InkWell(onTap:()=>_to(index),borderRadius:BorderRadius.circular(17),child:AnimatedContainer(duration:const Duration(milliseconds:180),padding:const EdgeInsets.symmetric(vertical:8),decoration:BoxDecoration(color:active?Palette.mint:Colors.transparent,borderRadius:BorderRadius.circular(17)),child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(icon,size:22,color:active?Palette.teal:Palette.muted),const SizedBox(height:3),Text(label,style:TextStyle(fontSize:10.5,fontWeight:active?FontWeight.w900:FontWeight.w600,color:active?Palette.teal:Palette.muted))]))));}
  Widget _hero(String number,String heading,String subtitle,IconData icon,Color surface,Color accent){return Container(margin:const EdgeInsets.only(bottom:14),padding:const EdgeInsets.all(20),decoration:BoxDecoration(color:surface,borderRadius:BorderRadius.circular(27)),child:Row(children:[Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(number,style:TextStyle(color:accent,fontWeight:FontWeight.w900,fontSize:11)),const SizedBox(height:8),Text(heading,style:const TextStyle(color:Palette.ink,fontSize:22,fontWeight:FontWeight.w900)),const SizedBox(height:6),Text(subtitle,style:const TextStyle(color:Palette.muted,fontSize:12.5,height:1.55))])),const SizedBox(width:8),Container(height:65,width:65,decoration:BoxDecoration(color:Colors.white.withValues(alpha:.8),borderRadius:BorderRadius.circular(21)),child:Icon(icon,color:accent,size:30))]));}
  Widget _panel(String title,IconData icon,Widget body,{String? subtitle,Color? iconColor}) => Container(margin:const EdgeInsets.only(bottom:13),padding:const EdgeInsets.all(17),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(25),border:Border.all(color:Palette.line)),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    Row(children:[Container(width:39,height:39,decoration:BoxDecoration(color:(iconColor??Palette.teal).withValues(alpha:.10),borderRadius:BorderRadius.circular(13)),child:Icon(icon,color:iconColor??Palette.teal,size:21)),const SizedBox(width:11),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:16,fontWeight:FontWeight.w900)),if(subtitle!=null)Text(subtitle,style:const TextStyle(color:Palette.muted,fontSize:11.5))]))]),const SizedBox(height:16),body,
  ]));
  Widget _choice(String title,bool selected,VoidCallback tap,{IconData? icon})=>InkWell(onTap:tap,borderRadius:BorderRadius.circular(13),child:Container(padding:const EdgeInsets.symmetric(horizontal:13,vertical:11),decoration:BoxDecoration(color:selected?Palette.mint:Palette.background,borderRadius:BorderRadius.circular(13),border:Border.all(color:selected?Palette.teal.withValues(alpha:.2):Palette.line)),child:Row(mainAxisSize:MainAxisSize.min,children:[if(icon!=null)...[Icon(icon,size:17,color:selected?Palette.teal:Palette.muted),const SizedBox(width:7)],Text(title,style:TextStyle(fontSize:12.5,fontWeight:selected?FontWeight.w800:FontWeight.w500,color:Palette.ink)),if(selected)...[const SizedBox(width:6),const Icon(Icons.check_circle_rounded,size:16,color:Palette.teal)]])));
  Widget _mainButton(String label,IconData icon,VoidCallback tap,{bool dark=false})=>SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:tap,icon:Icon(icon,size:19),label:Padding(padding:const EdgeInsets.symmetric(vertical:12),child:Text(label,style:const TextStyle(fontSize:14,fontWeight:FontWeight.w900))),style:FilledButton.styleFrom(backgroundColor:dark?Palette.ink:Palette.teal,foregroundColor:Colors.white,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(17)))));
  Widget _secondaryButton(String title,IconData icon,VoidCallback? action)=>OutlinedButton.icon(onPressed:action,icon:Icon(icon,size:17),label:Text(title,style:const TextStyle(fontWeight:FontWeight.w800)),style:OutlinedButton.styleFrom(foregroundColor:Palette.ink,side:const BorderSide(color:Palette.line),padding:const EdgeInsets.symmetric(vertical:11,horizontal:12),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(15))));
  Widget _editField(String label,String value,ValueChanged<String> update,{int lines=1,String? hint,TextInputType? keyboard})=>Padding(padding:const EdgeInsets.only(bottom:13),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Padding(padding:const EdgeInsets.only(bottom:7),child:Text(label,style:const TextStyle(fontSize:12,fontWeight:FontWeight.w800))),TextFormField(key:ValueKey('$label-${_document.hashCode}'),initialValue:value,onChanged:(v){update(v);_saveSoon();},keyboardType:keyboard,minLines:lines,maxLines:lines,decoration:InputDecoration(hintText:hint??label))]));
  Widget _stats(String label,String number,IconData icon,Color background,Color foreground){return Expanded(child:Container(padding:const EdgeInsets.all(13),decoration:BoxDecoration(color:background,borderRadius:BorderRadius.circular(19)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,color:foreground,size:20),const SizedBox(height:12),Text(number,style:TextStyle(color:Palette.ink,fontWeight:FontWeight.w900,fontSize:19)),Text(label,style:const TextStyle(fontSize:11,color:Palette.muted))])));}

  Widget _home(){final d=_document;return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    Container(height:245,clipBehavior:Clip.antiAlias,decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xFF193A47),Color(0xFF147B7B)],begin:Alignment.topRight,end:Alignment.bottomLeft),borderRadius:BorderRadius.circular(29)),child:Stack(children:[
      Positioned(left:-80,top:40,child:Container(width:235,height:235,decoration:BoxDecoration(shape:BoxShape.circle,border:Border.all(color:Colors.white24,width:37)))),
      Positioned(left:24,top:30,child:Transform.rotate(angle:-.15,child:Container(width:115,height:155,decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(14),boxShadow:const [BoxShadow(color:Colors.black26,blurRadius:17)]),child:const Padding(padding:EdgeInsets.all(15),child:Column(children:[Icon(Icons.school_outlined,color:Palette.teal),Divider(),SizedBox(height:19),Divider(),Divider(),Divider(),Divider()]))))),
      Positioned.fill(child:Padding(padding:const EdgeInsets.all(23),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Container(padding:const EdgeInsets.symmetric(horizontal:12,vertical:6),decoration:BoxDecoration(color:Colors.white24,borderRadius:BorderRadius.circular(30)),child:const Text('استوديو إنشاء الامتحانات',style:TextStyle(color:Colors.white,fontSize:11,fontWeight:FontWeight.w700))),const SizedBox(height:17),const Text('ورقة احترافية،\nبلمساتك الخاصة',style:TextStyle(fontSize:25,fontWeight:FontWeight.w900,color:Colors.white,height:1.4)),const Spacer(),SizedBox(width:180,child:FilledButton.icon(onPressed:()=>_to(2),icon:const Icon(Icons.edit_note_rounded),label:const Text('تابع التحرير'),style:FilledButton.styleFrom(backgroundColor:const Color(0xFFCCF6DC),foregroundColor:Palette.ink)))]))),
    ])),const SizedBox(height:13),
    _panel('مكتبتي وأدواتي',Icons.folder_copy_outlined,Column(
      crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      _secondaryButton('الأوراق والملازم',Icons.folder_open_outlined,_openDocuments),
      const SizedBox(height:8),
      _secondaryButton('بنك الأسئلة',Icons.library_books_outlined,_openQuestionBank),
      const SizedBox(height:8),
      _secondaryButton('النسخ الاحتياطي والاستيراد',Icons.cloud_upload_outlined,_backupOptions),
    ]),subtitle:'المستندات والأسئلة محفوظة على جهازك ويمكن استعادتها من ملف'),
    Row(children:[_stats('الأسئلة','${d.digits(d.questions.length)}',Icons.quiz_outlined,Palette.mint,Palette.teal),const SizedBox(width:9),_stats('الدرجات',d.digits(d.usedPoints.toStringAsFixed(0)),Icons.analytics_outlined,Palette.blue,const Color(0xFF448FAE)),const SizedBox(width:9),_stats('المستند','A4',Icons.description_outlined,Palette.lilac,const Color(0xFF7B65B1))]),
    const SizedBox(height:20),const Text('مساحة العمل',style:TextStyle(fontSize:21,fontWeight:FontWeight.w900)),const SizedBox(height:5),const Text('كل أدواتك منظمة في أقسام واضحة',style:TextStyle(fontSize:12,color:Palette.muted)),const SizedBox(height:12),
    GridView.count(crossAxisCount:2,childAspectRatio:1.34,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),mainAxisSpacing:11,crossAxisSpacing:11,children:[
      _homeCard('بيانات الورقة','الترويسة، المدرسة، المادة',Icons.ballot_outlined,Palette.mint,Palette.teal,1),
      _homeCard('الأسئلة','كتابة، تصوير، درجات',Icons.library_books_outlined,Palette.blue,const Color(0xFF3C87A9),2),
      _homeCard('التنسيق','الخطوط، الأرقام، الهوامش',Icons.tune_outlined,Palette.lilac,const Color(0xFF7B65B1),3),
      _homeCard('المعاينة','نسخة الطالب والإجابات',Icons.print_outlined,Palette.sand,const Color(0xFFA77A3E),4),
    ]),const SizedBox(height:14),_panel('الورقة الحالية',Icons.description_outlined,Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(d.title,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:17)),const SizedBox(height:5),Text('${d.subject} • ${d.grade} • ${d.digits(d.academicYear)}',style:const TextStyle(color:Palette.muted,fontSize:12)),const SizedBox(height:14),Row(children:[Expanded(child:_secondaryButton('مستند جديد',Icons.add,_newDocument)),const SizedBox(width:9),Expanded(child:_secondaryButton('عرض الورقة',Icons.visibility_outlined,()=>_to(4)))] )])),
  ]);}

  Widget _homeCard(String title,String subtitle,IconData icon,Color bg,Color fg,int page)=>InkWell(onTap:()=>_to(page),borderRadius:BorderRadius.circular(23),child:Container(padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:bg,borderRadius:BorderRadius.circular(23)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Container(height:37,width:37,decoration:BoxDecoration(color:Colors.white70,borderRadius:BorderRadius.circular(13)),child:Icon(icon,color:fg,size:21)),const Spacer(),Text(title,style:const TextStyle(fontSize:15,fontWeight:FontWeight.w900)),const SizedBox(height:3),Text(subtitle,maxLines:2,style:const TextStyle(fontSize:10.5,color:Palette.muted))])));

  Widget _data(){final d=_document;return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    _hero('01 / بيانات المستند','هوية ورقتك','أدخل المعلومات مرة واحدة وحدّد العناصر التي تريد إظهارها في رأس الورقة وأسفلها.',Icons.assignment_outlined,Palette.mint,Palette.teal),
    _panel('معلومات المدرسة',Icons.school_outlined,Column(children:[
      _editField('الدولة',d.country,(v)=>d.country=v),_editField('الوزارة',d.ministry,(v)=>d.ministry=v),_editField('المديرية',d.directorate,(v)=>d.directorate=v),_editField('اسم المدرسة',d.school,(v)=>d.school=v),
    ]),subtitle:'بيانات الترويسة الرسمية'),
    _panel('بيانات الاختبار',Icons.fact_check_outlined,Column(children:[
      _editField('عنوان الورقة',d.title,(v)=>d.title=v),_editField('المادة',d.subject,(v)=>d.subject=v),
      _editField('الصف',d.grade,(v)=>d.grade=v),_editField('العام الدراسي',d.academicYear,(v)=>d.academicYear=v),
      _editField('نوع الاختبار',d.examLabel,(v)=>d.examLabel=v),_editField('التاريخ',d.date,(v)=>d.date=v),
      _editField('مدة الامتحان',d.duration,(v)=>d.duration=v),
      _editField('الدرجة الكلية',d.total.toStringAsFixed(0),(v){d.total=(parseLocalizedNumber(v)??0).clamp(0,1000000).toDouble();},keyboard:TextInputType.number),
    ]),iconColor:const Color(0xFF448FAE)),
    _panel('الجزء العلوي للورقة',Icons.vertical_align_top,Column(children:[
      _editField('البسملة',d.bismillah,(v)=>d.bismillah=v),_editField('ملاحظة أعلى الورقة',d.topNote,(v)=>d.topNote=v,lines:2),
      Align(alignment:Alignment.centerRight,child:Text('الحقول الظاهرة في الترويسة',style:Theme.of(context).textTheme.titleSmall)),const SizedBox(height:10),
      Wrap(spacing:8,runSpacing:8,children:_fieldLabels.entries.map((e)=>_choice(e.value,d.headerFields.contains(e.key),()=>_edit((){if(!d.headerFields.add(e.key))d.headerFields.remove(e.key);}))).toList()),
    ]),subtitle:'عرض أو إخفاء كل حقل دون حذف معلوماته',iconColor:const Color(0xFF7B65B1)),
    _panel('الجزء السفلي والبيانات الاختيارية',Icons.vertical_align_bottom,Column(children:[
      _editField('معلم المادة',d.teacherName,(v)=>d.teacherName=v),
      _editField('ملاحظة أسفل الورقة',d.footerText,(v)=>d.footerText=v,lines:2),
      const SizedBox(height:6),
      _switch('إظهار حقل اسم الطالب',d.showStudentNameField,(v)=>_edit(()=>d.showStudentNameField=v)),
      _switch('إظهار حقل الصف/الشعبة',d.showSectionField,(v)=>_edit(()=>d.showSectionField=v)),
    ]),subtitle:'يمكن جعل اسم الطالب والشعبة اختياريين، كما يظهر معلم المادة في أسفل الورقة',iconColor:const Color(0xFFB8661F)),
    _panel('توقيع المعلم',Icons.draw_outlined,Column(children:[
      _editField('صفة المعلم (اختياري)',d.teacherRole,(v)=>d.teacherRole=v),
      _switch('إظهار سطر للتوقيع',d.showSignatureLine,(v)=>_edit(()=>d.showSignatureLine=v)),
      Wrap(spacing:8,runSpacing:8,children:[
        _choice('التوقيع يساراً',d.signatureSide=='left',()=>_edit(()=>d.signatureSide='left')),
        _choice('التوقيع يميناً',d.signatureSide=='right',()=>_edit(()=>d.signatureSide='right')),
      ]),
    ]),subtitle:'الاسم والصفة والتوقيع في ذيل الصفحة',iconColor:const Color(0xFF51748B)),
    _panel('التواقيع الإضافية',Icons.draw_rounded,Column(children:[
      const Text('يمكن إضافة عدة تواقيع، وتُرتّب تلقائياً بحد أقصى أربعة في كل صف بالطباعة.',
        style:TextStyle(fontSize:11,color:Palette.muted)),
      const SizedBox(height:8),
      for(final signature in d.signatures) Padding(padding:const EdgeInsets.only(bottom:9),child:Row(children:[
        Expanded(child:TextFormField(key:ValueKey('signature-name-${signature.id}'),
          initialValue:signature.name,onChanged:(v){signature.name=v;_saveSoon();},
          decoration:const InputDecoration(labelText:'الاسم',isDense:true))),
        const SizedBox(width:6),
        Expanded(child:TextFormField(key:ValueKey('signature-role-${signature.id}'),
          initialValue:signature.role,onChanged:(v){signature.role=v;_saveSoon();},
          decoration:const InputDecoration(labelText:'الصفة',isDense:true))),
        IconButton(onPressed:()=>_edit(()=>d.signatures.remove(signature)),
          icon:const Icon(Icons.delete_outline,color:Colors.redAccent)),
      ])),
      OutlinedButton.icon(onPressed:()=>_edit(()=>d.signatures.add(PaperSignature(id:newId()))),
        icon:const Icon(Icons.add),label:const Text('إضافة توقيع')),
    ]),subtitle:'أسماء وصفات متعددة مع سطر توقيع اختياري'),
    _panel('لغة بيانات الورقة',Icons.translate,Wrap(spacing:8,runSpacing:8,children:[
      _choice('العربية',d.paperLanguage=='ar',()=>_edit(()=>d.paperLanguage='ar')),
      _choice('English',d.paperLanguage=='en',()=>_edit(()=>d.paperLanguage='en')),
    ]),subtitle:'تغيير عبارات الرأس والحقول في المعاينة وWord'),
    if(d.documentType=='booklet') _panel('غلاف وفهرس الملزمة',Icons.menu_book_outlined,Column(children:[
      _switch('إضافة صفحة غلاف',d.includeCover,(v)=>_edit(()=>d.includeCover=v)),
      _switch('إنشاء فهرس تلقائي من عناوين المجموعات',d.includeToc,(v)=>_edit(()=>d.includeToc=v)),
      const SizedBox(height:9),
      const Align(alignment:Alignment.centerRight,child:Text('تصاميم الغلاف — 20 اختياراً',
        style:TextStyle(fontWeight:FontWeight.w800))),
      const SizedBox(height:7),
      GridView.builder(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),
        gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:5,
          childAspectRatio:.90,crossAxisSpacing:7,mainAxisSpacing:7),itemCount:20,
        itemBuilder:(context,i){
          final color=BookletPages.coverPalette(i);
          return InkWell(onTap:()=>_edit(()=>d.coverDesign=i),
            borderRadius:BorderRadius.circular(12),child:Container(
              decoration:BoxDecoration(color:color.$2,borderRadius:BorderRadius.circular(12),
                border:Border.all(color:d.coverDesign==i?color.$1:Palette.line,
                  width:d.coverDesign==i?3:1)),
              child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
                Icon(Icons.auto_stories,color:color.$1,size:21),
                Text('${i+1}',style:TextStyle(color:color.$1,fontWeight:FontWeight.w900)),
              ])));
        }),
      _editField('عنوان فرعي للغلاف',d.coverSubtitle,(v)=>d.coverSubtitle=v),
      _editField('مقدمة الملزمة',d.bookletIntroduction,(v)=>d.bookletIntroduction=v,lines:3),
      const Text('أنشئ فصلًا أو وحدة بكتابة عنوان المجموعة في أول سؤال من كل فصل. الفهرس يستخرجها تلقائياً.',style:TextStyle(fontSize:11,color:Palette.muted)),
    ]),subtitle:'غلاف مستقل وفهرس بأرقام صفحات المحتوى',iconColor:const Color(0xFF8465A8)),
    _panel('شعار المدرسة',Icons.image_outlined,Row(children:[Container(width:72,height:72,decoration:BoxDecoration(color:Palette.background,borderRadius:BorderRadius.circular(16)),child:d.logoPath!=null&&File(d.logoPath!).existsSync()?ClipRRect(borderRadius:BorderRadius.circular(16),child:Image.file(File(d.logoPath!),fit:BoxFit.cover)):const Icon(Icons.add_photo_alternate_outlined,color:Palette.muted,size:28)),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('ضع شعار المدرسة أعلى الورقة',style:TextStyle(fontSize:12,fontWeight:FontWeight.w700)),const SizedBox(height:7),_secondaryButton('اختيار شعار',Icons.photo_library_outlined,_pickLogo)]))])),
    _mainButton('متابعة إلى الأسئلة',Icons.arrow_back_rounded,()=>_to(2)),
  ]);}

  Widget _questions(){
    final d=_document;
    final used=d.usedPoints;
    final difference=(used-d.total).abs();
    return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      _hero('02 / محرر الأسئلة','صمّم أسئلتك بحرية','كتابة، استخراج النص من صورة بعد قصها، فروع، عناصر ونماذج إجابة.',Icons.edit_document,Palette.blue,const Color(0xFF3685A8)),
      Container(margin:const EdgeInsets.only(bottom:14),padding:const EdgeInsets.all(17),decoration:BoxDecoration(color:Palette.dark,borderRadius:BorderRadius.circular(25)),child:Column(children:[
        Row(children:[const Icon(Icons.analytics_outlined,color:Color(0xFFB9EBD2),size:26),const SizedBox(width:9),Expanded(child:const Text('ملخص درجات الورقة',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w900))),Text('${d.digits(d.questions.length)} سؤال',style:const TextStyle(color:Colors.white70))]),
        const SizedBox(height:15),Row(children:[Expanded(child:_darkMetric('درجات الأسئلة',d.digits(used.toStringAsFixed(used==used.roundToDouble()?0:1)))),const SizedBox(width:9),Expanded(child:_darkMetric('الدرجة الكلية',d.digits(d.total.toStringAsFixed(d.total==d.total.roundToDouble()?0:1))))]),
        if(difference>.001)Padding(padding:const EdgeInsets.only(top:13),child:Row(children:[const Icon(Icons.info_outline,color:Color(0xFFFFD390),size:18),const SizedBox(width:7),Expanded(child:Text('هناك فرق مقداره ${d.digits(difference.toStringAsFixed(difference==difference.roundToDouble()?0:1))} درجة. يمكنك تعديله في بيانات الورقة.',style:const TextStyle(color:Color(0xFFFFE3B6),fontSize:11)))])),
      ])),
      _panel('الأرقام في جميع الأسئلة',Icons.pin_outlined,Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Wrap(spacing:9,runSpacing:9,children:[_choice('عربية ١٢٣',d.digitStyle==DigitStyle.arabic,()=>_edit(()=>d.digitStyle=DigitStyle.arabic)),_choice('إنجليزية 123',d.digitStyle==DigitStyle.english,()=>_edit(()=>d.digitStyle=DigitStyle.english))]),
        const SizedBox(height:8),const Text('ينطبق الاختيار على أرقام نصوص الأسئلة وفروعها وأرقام السؤال والصفحة في المعاينة والطباعة.',style:TextStyle(fontSize:11,color:Palette.muted,height:1.5)),
      ]),iconColor:const Color(0xFF9A7CBE)),
      if(d.questions.isEmpty) Container(margin:const EdgeInsets.only(bottom:16),padding:const EdgeInsets.symmetric(vertical:43,horizontal:22),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(25),border:Border.all(color:Palette.line)),child:Column(children:[Container(width:87,height:87,decoration:BoxDecoration(color:Palette.mint,borderRadius:BorderRadius.circular(27)),child:const Icon(Icons.library_add_check_outlined,color:Palette.teal,size:43)),const SizedBox(height:16),const Text('ابدأ بالسؤال الأول',style:TextStyle(fontSize:21,fontWeight:FontWeight.w900)),const SizedBox(height:5),const Text('اكتب سؤالك أو استخرج نصه من صورة بعد تحديد إطار الالتقاط.',style:TextStyle(color:Palette.muted,fontSize:12),textAlign:TextAlign.center)])),
      for(var i=0;i<d.questions.length;i++) _questionCard(d.questions[i],i),
      const SizedBox(height:6),
      _secondaryButton('إدراج سؤال من البنك',Icons.library_books_outlined,_openQuestionBank),
      const SizedBox(height:9),
      _mainButton('إضافة سؤال جديد',Icons.add_circle_outline,_addQuestion),
      const SizedBox(height:10),_mainButton('الانتقال إلى المعاينة',Icons.visibility_outlined,()=>_to(4),dark:true),
    ]);
  }

  Widget _darkMetric(String label,String value)=>Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:Colors.white.withValues(alpha:.10),borderRadius:BorderRadius.circular(15)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(label,style:const TextStyle(color:Colors.white70,fontSize:11)),Text(value,style:const TextStyle(color:Colors.white,fontSize:24,fontWeight:FontWeight.w900))]));

  Widget _questionCard(PaperQuestion q,int index){
    final d=_document;
    final collapsed=_collapsed.contains(q.id);
    final answerOpen=_answersOpen.contains(q.id);
    return Container(margin:const EdgeInsets.only(bottom:14),padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(24),border:Border.all(color:Palette.line),boxShadow:[BoxShadow(color:Palette.ink.withValues(alpha:.025),blurRadius:12,offset:const Offset(0,4))]),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      Row(children:[Container(padding:const EdgeInsets.symmetric(horizontal:14,vertical:9),decoration:BoxDecoration(color:Palette.dark,borderRadius:BorderRadius.circular(12)),child:Text('السؤال ${d.digits(index+1)}',style:const TextStyle(fontWeight:FontWeight.w900,color:Colors.white,fontSize:13))),const Spacer(),IconButton(tooltip:'نقل لأعلى',onPressed:index==0?null:()=>_moveQuestion(index,-1),icon:const Icon(Icons.keyboard_arrow_up)),IconButton(tooltip:'نقل لأسفل',onPressed:index==d.questions.length-1?null:()=>_moveQuestion(index,1),icon:const Icon(Icons.keyboard_arrow_down)),PopupMenuButton<String>(tooltip:'خيارات السؤال',onSelected:(action){if(action=='copy')_cloneQuestion(q);if(action=='bank')_saveQuestionToBank(q);if(action=='break')_edit(()=>q.pageBreakBefore=!q.pageBreakBefore);if(action=='remove')_removeQuestion(q);if(action=='visible')_edit(()=>q.visible=!q.visible);},itemBuilder:(_)=>[const PopupMenuItem(value:'copy',child:Text('نسخ السؤال')),const PopupMenuItem(value:'bank',child:Text('حفظ في بنك الأسئلة')),PopupMenuItem(value:'break',child:Text(q.pageBreakBefore?'إلغاء فاصل الصفحة':'بدء هذا السؤال في صفحة جديدة')),PopupMenuItem(value:'visible',child:Text(q.visible?'إخفاء من الطباعة':'إظهار في الطباعة')),const PopupMenuItem(value:'remove',child:Text('حذف السؤال',style:TextStyle(color:Colors.red)))])]),
      const SizedBox(height:11),Row(children:[const Text('درجة السؤال',style:TextStyle(fontSize:12,fontWeight:FontWeight.w700)),const SizedBox(width:9),SizedBox(width:81,child:TextFormField(key:ValueKey('points-${q.id}'),initialValue:q.points.toStringAsFixed(0),keyboardType:const TextInputType.numberWithOptions(decimal:true),textAlign:TextAlign.center,onChanged:(v){setState(()=>q.points=(parseLocalizedNumber(v)??0).clamp(0,1000000).toDouble());_saveSoon();},decoration:const InputDecoration(isDense:true,contentPadding:EdgeInsets.all(10)))),const Spacer(),_choice(q.visible?'ظاهر':'مخفي',q.visible,()=>_edit(()=>q.visible=!q.visible),icon:Icons.visibility_outlined),IconButton(onPressed:()=>setState((){if(!_collapsed.add(q.id))_collapsed.remove(q.id);}),icon:Icon(collapsed?Icons.expand_more:Icons.expand_less))]),
      if(!collapsed)...[
        const SizedBox(height:12),TextFormField(key:ValueKey('question-section-${q.id}'),initialValue:q.sectionTitle,
          onChanged:(value){q.sectionTitle=value;_saveSoon();},
          decoration:const InputDecoration(labelText:'عنوان المجموعة (اختياري)',hintText:'مثال: القواعد، الإنشاء والتعبير')),
        const SizedBox(height:10),
        Wrap(spacing:7,runSpacing:7,children:[
          _choice('سؤال',q.type=='essay',()=>_edit(()=>q.type='essay')),
          _choice('شرح',q.type=='explanation',()=>_edit(()=>q.type='explanation')),
          _choice('مثال محلول',q.type=='example',()=>_edit(()=>q.type='example')),
          _choice('تمرين',q.type=='exercise',()=>_edit(()=>q.type='exercise')),
        ]),
        const SizedBox(height:9),
        TextFormField(key:ValueKey('custom-number-${q.id}'),initialValue:q.customNumber,
          onChanged:(v){q.customNumber=v;_saveSoon();},
          decoration:const InputDecoration(labelText:'ترقيم مخصص (اختياري)',hintText:'مثال: ١-أ أو السؤال الأول')),
        const SizedBox(height:9),
        TextFormField(key:ValueKey('tags-${q.id}'),initialValue:q.tags,
          onChanged:(v){q.tags=v;_saveSoon();},
          decoration:const InputDecoration(labelText:'وسوم بنك الأسئلة',hintText:'كسور، هندسة، الفصل الأول')),
        const SizedBox(height:9),
        _switch('حساب درجة السؤال من درجات الفروع',q.useBranchPoints,(value)=>_edit(()=>q.useBranchPoints=value)),
        TextFormField(key:ValueKey('required-${q.id}'),initialValue:q.requiredBranches.toString(),keyboardType:TextInputType.number,
          onChanged:(v){q.requiredBranches=(parseLocalizedNumber(v)??0).round().clamp(0,q.branches.length);_saveSoon();},
          decoration:const InputDecoration(labelText:'عدد الفروع المطلوب حلّها (0 = جميعها)')),
        const SizedBox(height:10),TextFormField(key:ValueKey('question-text-${q.id}'),controller:_textController(q),maxLines:3,minLines:2,textInputAction:TextInputAction.newline,onChanged:(v){q.text=v;_saveSoon();},decoration:const InputDecoration(hintText:'اكتب نص السؤال أو استخرجه من صورة...')),
        const SizedBox(height:11),Row(children:[Expanded(child:_secondaryButton(_recognizing.contains(q.id)?'جارٍ استخراج النص...':'نص من صورة',Icons.document_scanner_outlined,_recognizing.contains(q.id)?null:()=>_photoChoice(q))),const SizedBox(width:7),Expanded(child:_secondaryButton('إضافة عنصر',Icons.add_box_outlined,()=>_showElements(q)))]),
        const SizedBox(height:8),_secondaryButton('الكتابة بالصوت — إملاء السؤال',Icons.mic_none_rounded,()=>_dictateQuestion(q)),
        if(q.branches.isNotEmpty)...[const SizedBox(height:14),const Text('فروع السؤال',style:TextStyle(fontWeight:FontWeight.w800,fontSize:12)),const SizedBox(height:7)],
        for(var j=0;j<q.branches.length;j++) _branchEditor(q,j,d),
        if(q.elements.isNotEmpty)...[const SizedBox(height:8),const Text('العناصر المضافة',style:TextStyle(fontWeight:FontWeight.w800,fontSize:12)),const SizedBox(height:8)],
        for(final element in q.elements) _elementChip(q,element),
        const SizedBox(height:11),Row(children:[Expanded(child:_secondaryButton('إضافة فرع',Icons.add,()=>_edit((){q.branches.add('');q.branchPoints.add(0);q.branchSubpoints.add([]);}))),const SizedBox(width:7),Expanded(child:_secondaryButton('استخراج من المعرض',Icons.photo_library_outlined,_recognizing.contains(q.id)?null:()=>_photoChoice(q)))]),
        const SizedBox(height:11),InkWell(onTap:()=>setState((){if(!_answersOpen.add(q.id))_answersOpen.remove(q.id);}),borderRadius:BorderRadius.circular(15),child:Container(padding:const EdgeInsets.all(13),decoration:BoxDecoration(color:Palette.background,borderRadius:BorderRadius.circular(15)),child:Row(children:[const Icon(Icons.key_outlined,color:Palette.teal,size:19),const SizedBox(width:9),const Expanded(child:Text('نموذج الإجابة',style:TextStyle(fontWeight:FontWeight.w800))),Icon(answerOpen?Icons.keyboard_arrow_up:Icons.keyboard_arrow_down)]))),
        if(answerOpen)Padding(padding:const EdgeInsets.only(top:9),child:TextFormField(key:ValueKey('answer-${q.id}'),initialValue:q.answer,maxLines:3,onChanged:(v){q.answer=v;_saveSoon();},decoration:const InputDecoration(hintText:'الإجابة النموذجية (لا تظهر في نسخة الطالب)'))),
      ],
    ]));
  }

  Widget _branchEditor(PaperQuestion q,int j,PaperDocument d){
    final points=j<q.branchSubpoints.length?q.branchSubpoints[j]:<PaperSubPoint>[];
    return Container(margin:const EdgeInsets.only(bottom:10),padding:const EdgeInsets.all(10),
      decoration:BoxDecoration(color:const Color(0xFFF7F9FA),borderRadius:BorderRadius.circular(16),
        border:Border.all(color:Palette.line)),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        Row(children:[
          Container(width:31,height:34,alignment:Alignment.center,
            decoration:BoxDecoration(color:Palette.mint,borderRadius:BorderRadius.circular(10)),
            child:Text(d.digits(j+1),style:const TextStyle(color:Palette.teal,fontWeight:FontWeight.w800))),
          const SizedBox(width:7),
          Expanded(child:TextFormField(key:ValueKey('branch-${q.id}-$j'),initialValue:q.branches[j],
            minLines:1,maxLines:3,onChanged:(v){q.branches[j]=v;_saveSoon();},
            decoration:const InputDecoration(isDense:true,labelText:'نص الفرع'))),
          IconButton(tooltip:'إملاء الفرع',onPressed:()=>_dictateQuestion(q,branch:j),
            icon:const Icon(Icons.mic_none_rounded,color:Palette.teal)),
          IconButton(tooltip:'حذف الفرع',onPressed:()=>_edit((){
            q.branches.removeAt(j);
            if(j<q.branchPoints.length)q.branchPoints.removeAt(j);
            if(j<q.branchSubpoints.length)q.branchSubpoints.removeAt(j);
            if(q.requiredBranches>q.branches.length)q.requiredBranches=q.branches.length;
          }),icon:const Icon(Icons.delete_outline,color:Colors.redAccent,size:19)),
        ]),
        if(q.useBranchPoints)Padding(padding:const EdgeInsets.only(top:8),child:Row(children:[
          const Text('درجة الفرع',style:TextStyle(fontSize:11)),const SizedBox(width:8),
          SizedBox(width:88,child:TextFormField(key:ValueKey('branch-points-${q.id}-$j'),
            initialValue:j<q.branchPoints.length?q.branchPoints[j].toStringAsFixed(1):'0',
            enabled:points.isEmpty,keyboardType:const TextInputType.numberWithOptions(decimal:true),
            onChanged:(v){while(q.branchPoints.length<=j){q.branchPoints.add(0);}
              q.branchPoints[j]=(parseLocalizedNumber(v)??0).clamp(0,1000000).toDouble();_saveSoon();},
            decoration:const InputDecoration(isDense:true,labelText:'درجة'))),
          if(points.isNotEmpty)Expanded(child:Text('تُحسب من نقاط الفرع: ${d.digits(q.effectiveBranchPoints(j))}',
            textAlign:TextAlign.end,style:const TextStyle(fontSize:11,color:Palette.muted))),
        ])),
        if(points.isNotEmpty)const Padding(padding:EdgeInsets.only(top:10,bottom:5),
          child:Text('نقاط الفرع',style:TextStyle(fontWeight:FontWeight.w800,fontSize:12))),
        for(var k=0;k<points.length;k++) Padding(padding:const EdgeInsets.only(bottom:6),
          child:Row(children:[
            Expanded(child:TextFormField(key:ValueKey('point-text-${points[k].id}'),
              initialValue:points[k].text,minLines:1,maxLines:2,
              onChanged:(v){points[k].text=v;_saveSoon();},
              decoration:InputDecoration(isDense:true,labelText:'النقطة ${d.digits(k+1)}'))),
            const SizedBox(width:6),
            SizedBox(width:70,child:TextFormField(key:ValueKey('point-grade-${points[k].id}'),
              initialValue:points[k].points.toStringAsFixed(1),
              keyboardType:const TextInputType.numberWithOptions(decimal:true),
              onChanged:(v){_edit(()=>points[k].points=(parseLocalizedNumber(v)??0).clamp(0,1000000).toDouble());},
              decoration:const InputDecoration(isDense:true,labelText:'درجة'))),
            IconButton(tooltip:'تفاصيل النقطة وترقيمها وإجابتها',
              onPressed:()=>_editSubPoint(points[k]),
              icon:const Icon(Icons.tune,size:18)),
            IconButton(tooltip:'حذف النقطة',onPressed:()=>_edit(()=>points.removeAt(k)),
              icon:const Icon(Icons.close,size:18)),
          ])),
        Align(alignment:Alignment.centerRight,child:TextButton.icon(
          onPressed:()=>_edit((){
            while(q.branchSubpoints.length<=j){q.branchSubpoints.add([]);}
            q.branchSubpoints[j].add(PaperSubPoint(id:newId()));
            q.useBranchPoints=true;
          }),icon:const Icon(Icons.add_circle_outline,size:18),
          label:const Text('إضافة نقطة داخل الفرع'))),
      ]));
  }

  Future<void> _editSubPoint(PaperSubPoint point) async {
    final number=TextEditingController(text:point.customNumber);
    final answer=TextEditingController(text:point.answer);
    var visible=point.visible;
    try {
      final saved=await showDialog<bool>(context:context,builder:(dialogContext)=>
        StatefulBuilder(builder:(dialogContext,refresh)=>AlertDialog(
          title:const Text('إعدادات النقطة'),
          content:Column(mainAxisSize:MainAxisSize.min,children:[
            TextField(controller:number,decoration:const InputDecoration(
              labelText:'ترقيم خاص (اختياري)',hintText:'مثلاً: أ-١')),
            const SizedBox(height:10),
            TextField(controller:answer,maxLines:3,minLines:1,
              decoration:const InputDecoration(labelText:'الإجابة النموذجية للنقطة')),
            SwitchListTile(title:const Text('ظهور النقطة في ورقة الطالب'),
              value:visible,onChanged:(value)=>refresh(()=>visible=value)),
          ]),
          actions:[TextButton(onPressed:()=>Navigator.pop(dialogContext,false),child:const Text('إلغاء')),
            FilledButton(onPressed:()=>Navigator.pop(dialogContext,true),child:const Text('حفظ'))],
        )));
      if(saved==true && mounted){_edit((){
        point.customNumber=number.text;
        point.answer=answer.text;
        point.visible=visible;
      });}
    }finally{number.dispose();answer.dispose();}
  }

  Future<void> _imageElementSettings(PaperElement element) async {
    var scale=element.imageScale;
    var rotation=element.rotation;
    final caption=TextEditingController(text:element.caption);
    try {
      final save=await showDialog<bool>(context:context,builder:(context)=>StatefulBuilder(
        builder:(context,update)=>AlertDialog(
          title:const Text('حجم الصورة وتنسيقها'),
          content:Column(mainAxisSize:MainAxisSize.min,children:[
            const Text('تحكم بحجم الصورة داخل الورقة وقم بتدويرها.'),
            Slider(value:scale,min:.3,max:1.0,divisions:7,label:'${(scale*100).round()}%',onChanged:(v)=>update(()=>scale=v)),
            OutlinedButton.icon(onPressed:()=>update(()=>rotation=(rotation+1)%4),icon:const Icon(Icons.rotate_right),label:Text('تدوير ${rotation*90}°')),
            const SizedBox(height:8),TextField(controller:caption,decoration:const InputDecoration(labelText:'عنوان الصورة (اختياري)')),
          ]),
          actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('إلغاء')),
            FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('حفظ'))],
        ),
      ));
      if(save==true){_edit(() {element.imageScale=scale;element.rotation=rotation;element.caption=caption.text;});}
    } finally {caption.dispose();}
  }


  void _applyLayoutPreset(String layout){
    final d=_document;
    _edit((){
      d.paperLayout=layout;
      switch(layout){
        case 'globalEmerald':
          d.headingColor=0xFF0F5B4E;
          d.printAccentColor=0xFFB68B2F;
          d.paperFontFamily='system';
          d.questionSeparator='line';
          d.headerGapMm=5;
          d.topMarginMm=9;
          d.bottomMarginMm=10;
          d.sideMarginMm=10;
          d.showHeaderLine=false;
          d.showPageNumbers=false;
          d.showFooter=true;
          break;
        case 'royalBlue':
          d.headingColor=0xFF1F4E8C;
          d.printAccentColor=0xFF7BA7DA;
          d.paperFontFamily='sans-serif';
          d.questionSeparator='line';
          d.showHeaderLine=false;
          d.showPageNumbers=true;
          break;
        case 'sandGold':
          d.headingColor=0xFF815A18;
          d.printAccentColor=0xFFCFAE62;
          d.paperFontFamily='serif';
          d.questionSeparator='line';
          d.showHeaderLine=false;
          d.showPageNumbers=false;
          break;
        case 'mintClassic':
          d.headingColor=0xFF2A6652;
          d.printAccentColor=0xFF8EBEA8;
          d.paperFontFamily='system';
          d.questionSeparator='dots';
          d.showHeaderLine=false;
          d.showPageNumbers=false;
          break;
        case 'plumModern':
          d.headingColor=0xFF6A3F78;
          d.printAccentColor=0xFFB99BC6;
          d.paperFontFamily='sans-serif';
          d.questionSeparator='line';
          d.showHeaderLine=false;
          d.showPageNumbers=true;
          break;
        case 'arabicLines':
          d.headingColor=0xFF17333D;
          d.printAccentColor=0xFF485F63;
          d.paperFontFamily='serif';
          d.questionSeparator='line';
          d.showHeaderLine=true;
          break;
        default:
          d.headingColor=0xFF17333D;
          d.printAccentColor=0xFF485F63;
          d.paperFontFamily='system';
          d.questionSeparator='line';
          d.showHeaderLine=true;
      }
    });
  }

  Widget _elementChip(PaperQuestion q,PaperElement element)=>Container(margin:const EdgeInsets.only(bottom:7),decoration:BoxDecoration(color:Palette.background,borderRadius:BorderRadius.circular(15),border:Border.all(color:Palette.line)),child:ListTile(dense:true,leading:Icon(_elementIcons[element.kind]??Icons.article_outlined,color:Palette.teal),title:Text(_elements[element.kind]??element.kind,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:12)),subtitle:element.kind=='gallery' && element.galleryImages.isNotEmpty?Text('${element.galleryImages.length} صورة في الشبكة',style:const TextStyle(fontSize:11)):element.imagePath!=null?Padding(padding:const EdgeInsets.only(top:5),child:File(element.imagePath!).existsSync()?Image.file(File(element.imagePath!),height:90,alignment:Alignment.centerRight):const Text('الصورة غير موجودة')):Text(element.text,maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:11)),trailing:Row(mainAxisSize:MainAxisSize.min,children:[if(element.imagePath==null)IconButton(onPressed:()=>_textElement(q,element.kind,existing:element),icon:const Icon(Icons.edit_outlined,size:19)),if(element.imagePath!=null)IconButton(tooltip:'حجم الصورة',onPressed:()=>_imageElementSettings(element),icon:const Icon(Icons.tune_outlined,size:19)),IconButton(onPressed:()=>_edit(()=>q.elements.remove(element)),icon:const Icon(Icons.delete_outline,size:19,color:Colors.redAccent))])));

  Widget _format(){final d=_document;return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    _hero('03 / التنسيق والطباعة','محرر المظهر','تحكم دقيق في بداية ونهاية الكتابة والمسافات وشكل الأرقام.',Icons.tune_rounded,Palette.lilac,const Color(0xFF7860AF)),
    _panel('شكل الأرقام في الورقة',Icons.onetwothree,Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Wrap(spacing:10,runSpacing:9,children:[_choice('١٢٣ عربية',d.digitStyle==DigitStyle.arabic,()=>_edit(()=>d.digitStyle=DigitStyle.arabic)),_choice('123 إنجليزية',d.digitStyle==DigitStyle.english,()=>_edit(()=>d.digitStyle=DigitStyle.english))]),const SizedBox(height:12),Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:Palette.background,borderRadius:BorderRadius.circular(14)),child:Text(d.digits('س 1: احسب 45.67 × 100 =      (1) 250'),style:const TextStyle(fontWeight:FontWeight.w800,fontSize:14)))]),subtitle:'إعداد موحد لترقيم الأسئلة والفروع ونصوصها والمعاينة'),
    _panel('ترقيم الأسئلة والفروع',Icons.format_list_numbered,Column(children:[
      Wrap(spacing:7,runSpacing:7,children:[
        _choice('أسئلة بالأرقام',d.questionNumbering=='digits',()=>_edit(()=>d.questionNumbering='digits')),
        _choice('أسئلة بالحروف',d.questionNumbering=='letters',()=>_edit(()=>d.questionNumbering='letters')),
        _choice('أسئلة رومانية',d.questionNumbering=='roman',()=>_edit(()=>d.questionNumbering='roman')),
      ]),
      const SizedBox(height:8),Wrap(spacing:7,runSpacing:7,children:[
        _choice('فروع بالأرقام',d.branchNumbering=='digits',()=>_edit(()=>d.branchNumbering='digits')),
        _choice('فروع بالحروف',d.branchNumbering=='letters',()=>_edit(()=>d.branchNumbering='letters')),
      ]),
      const SizedBox(height:9),_range('بداية ترقيم الأسئلة',d.questionSequenceStart.toDouble(),1,30,'',
        (v)=>_edit(()=>d.questionSequenceStart=v.round())),
      const SizedBox(height:9),_range('عدد الأسئلة المطلوب الإجابة عنها (0 = كلها)',d.requiredQuestions.toDouble(),0,30,'',
        (v)=>_edit(()=>d.requiredQuestions=v.round())),
    ]),subtitle:'يمكن تجاوز الترقيم الافتراضي من إعدادات كل سؤال'),
    _panel('الخطوط وألوان الطباعة',Icons.palette_outlined,Column(children:[
      Wrap(spacing:7,runSpacing:7,children:[
        _choice('خط الهاتف',d.paperFontFamily=='system',()=>_edit(()=>d.paperFontFamily='system')),
        _choice('نسخي Serif',d.paperFontFamily=='serif',()=>_edit(()=>d.paperFontFamily='serif')),
        _choice('واضح Sans',d.paperFontFamily=='sans-serif',()=>_edit(()=>d.paperFontFamily='sans-serif')),
      ]),
      const SizedBox(height:12),const Text('لون عناوين الأسئلة',style:TextStyle(fontWeight:FontWeight.w700)),
      const SizedBox(height:6),Wrap(spacing:10,runSpacing:8,children:[
        for(final color in [0xFF17333D,0xFF171717,0xFF2869A4,0xFF8C3C62,0xFF4F6C2E])
          InkWell(onTap:()=>_edit(()=>d.headingColor=color),child:Container(width:39,height:39,
            decoration:BoxDecoration(color:Color(color),borderRadius:BorderRadius.circular(12),
              border:Border.all(color:d.headingColor==color?Colors.amber:Colors.transparent,width:3)),
            child:d.headingColor==color?const Icon(Icons.check,color:Colors.white,size:18):null)),
      ]),
      const SizedBox(height:12),const Text('لون الفواصل',style:TextStyle(fontWeight:FontWeight.w700)),
      const SizedBox(height:6),Wrap(spacing:9,runSpacing:8,children:[
        for(final color in [0xFF485F63,0xFF202020,0xFF447FA0,0xFFA36C2B,0xFF6E7496])
          InkWell(onTap:()=>_edit(()=>d.printAccentColor=color),child:Container(width:38,height:38,
            decoration:BoxDecoration(color:Color(color),borderRadius:BorderRadius.circular(12)),
            child:d.printAccentColor==color?const Icon(Icons.check,color:Colors.white,size:17):null)),
      ]),
    ]),subtitle:'خطوط النظام المتاحة دون الحاجة إلى تحميل خطوط إضافية'),
    _panel('موضع الكتابة في صفحة A4',Icons.vertical_align_center,Column(children:[
      _range('الهامش العلوي — قلّله لرفع بداية الكتابة',d.topMarginMm,0,45,'مم',(v)=>_edit(()=>d.topMarginMm=v)),
      const Divider(color:Palette.line,height:22),
      _range('الهامش السفلي — قلّله لإنزال نهاية الكتابة',d.bottomMarginMm,0,45,'مم',(v)=>_edit(()=>d.bottomMarginMm=v)),
      const Divider(color:Palette.line,height:22),
      _range('الهوامش الجانبية',d.sideMarginMm,5,30,'مم',(v)=>_edit(()=>d.sideMarginMm=v)),
      const Divider(color:Palette.line,height:22),
      _range('الفاصل بعد الترويسة',d.headerGapMm,0,28,'مم',(v)=>_edit(()=>d.headerGapMm=v)),
      const SizedBox(height:7),Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:Palette.mint,borderRadius:BorderRadius.circular(15)),child:Row(children:[const Icon(Icons.lightbulb_outline,color:Palette.teal),const SizedBox(width:9),Expanded(child:Text('يمكنك رفع الكتابة حتى أعلى الصفحة، لكن بعض الطابعات تحتاج هامش أمان ٥–١٠ مم.',style:TextStyle(color:Palette.ink,fontSize:11,height:1.5)))])),
    ]),subtitle:'تحريك مساحة الكتابة عموديًا بدقة الملّيمتر'),
    _panel('الخط والمسافات',Icons.format_size,Column(children:[
      _range('حجم الخط',d.fontSize,11,23,'نقطة',(v)=>_edit(()=>d.fontSize=v)),
      const Divider(color:Palette.line,height:22),
      _range('تباعد الأسطر',d.lineSpacing,1,2.2,'×',(v)=>_edit(()=>d.lineSpacing=v)),
      const Divider(color:Palette.line,height:22),
      _range('المسافة بين الأسئلة',d.questionGap,4,35,'نقطة',(v)=>_edit(()=>d.questionGap=v)),
    ])),
    _panel('قوالب النتيجة النهائية',Icons.auto_awesome_outlined,Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('هذا القسم يحدد الشكل النهائي للورقة المطبوعة. القالب الأساسي الافتراضي هو «العالمي الأخضر» المشابه للمعاينة التي اعتمدناها.',style:TextStyle(fontSize:11.5,color:Palette.muted,height:1.5)),
      const SizedBox(height:12),
      Wrap(spacing:8,runSpacing:8,children:[
        _choice('العالمي الأخضر',d.paperLayout=='globalEmerald',()=>_applyLayoutPreset('globalEmerald')),
        _choice('الملكي الأزرق',d.paperLayout=='royalBlue',()=>_applyLayoutPreset('royalBlue')),
        _choice('الذهبي الرملي',d.paperLayout=='sandGold',()=>_applyLayoutPreset('sandGold')),
        _choice('النعناع الكلاسيكي',d.paperLayout=='mintClassic',()=>_applyLayoutPreset('mintClassic')),
        _choice('البرقوقي الحديث',d.paperLayout=='plumModern',()=>_applyLayoutPreset('plumModern')),
        _choice('إطار الرياضيات',d.paperLayout=='mathFrame',()=>_applyLayoutPreset('mathFrame')),
        _choice('العربي التقليدي',d.paperLayout=='arabicLines',()=>_applyLayoutPreset('arabicLines')),
      ]),
      const SizedBox(height:14),
      Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:Palette.background,borderRadius:BorderRadius.circular(15),border:Border.all(color:Palette.line)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('القالب الحالي',style:TextStyle(fontWeight:FontWeight.w800)),const SizedBox(height:7),
        Text({
          'globalEmerald':'رأس منسق بثلاث مناطق، بطاقة عنوان مركزية، شارات درجات وأشرطة أسئلة فاخرة.',
          'royalBlue':'أسلوب رسمي أنيق بدرجات الأزرق مع تخطيط واضح للطباعة المدرسية الحديثة.',
          'sandGold':'طابع دافئ وفاخر يناسب الاختبارات النهائية والملزمات المميزة.',
          'mintClassic':'ألوان هادئة ومريحة مع صناديق ناعمة وحدود خفيفة.',
          'plumModern':'ستايل حديث جريء بعناوين بارزة ولمسات بنفسجية احترافية.',
          'mathFrame':'الإطار المدرسي الكلاسيكي لورقة الرياضيات.',
          'arabicLines':'تنسيق عربي تقليدي مناسب للقواعد والإنشاء والنصوص.',
        }[d.paperLayout] ?? '',style:const TextStyle(color:Palette.muted,fontSize:11.5,height:1.45)),
      ])),
    ]),iconColor:const Color(0xFF2B6CB0)),
    _panel('إعدادات الورقة',Icons.pages_outlined,Column(children:[
      Row(children:[Expanded(child:_choice('A4 عمودي',!d.landscape,()=>_edit(()=>d.landscape=false),icon:Icons.stay_current_portrait)),const SizedBox(width:8),Expanded(child:_choice('A4 أفقي',d.landscape,()=>_edit(()=>d.landscape=true),icon:Icons.stay_current_landscape))]),
      const SizedBox(height:12),Wrap(spacing:7,runSpacing:7,children:[
        _choice('فاصل خط',d.questionSeparator=='line',()=>_edit(()=>d.questionSeparator='line')),
        _choice('فاصل منقط',d.questionSeparator=='dots',()=>_edit(()=>d.questionSeparator='dots')),
        _choice('بلا فواصل',d.questionSeparator=='none',()=>_edit(()=>d.questionSeparator='none')),
      ]),
      const SizedBox(height:9),
      _switch('تقليل المسافات لمحاولة احتواء الورقة في صفحة',d.compactForOnePage,
        (value)=>_edit(()=>d.compactForOnePage=value)),
      _switch('إظهار تنبيهات الدرجات والفروع الاختيارية',d.showQuestionWarnings,
        (value)=>_edit(()=>d.showQuestionWarnings=value)),
      const SizedBox(height:14),_switch('خط فاصل أسفل الترويسة',d.showHeaderLine,(v)=>_edit(()=>d.showHeaderLine=v)),
      _switch('إظهار درجات الأسئلة',d.showGrades,(v)=>_edit(()=>d.showGrades=v)),
      _switch('سطور للإجابة',d.showRules,(v)=>_edit(()=>d.showRules=v)),
      _switch('عبارة نهاية الورقة',d.showFooter,(v)=>_edit(()=>d.showFooter=v)),
      _switch('ترقيم الصفحات',d.showPageNumbers,(v)=>_edit(()=>d.showPageNumbers=v)),
      _switch('شعار المدرسة',d.showLogo,(v)=>_edit(()=>d.showLogo=v)),
    ])),
    _mainButton('شاهد نتيجة التنسيق',Icons.preview_outlined,()=>_to(4)),
  ]);}

  Widget _range(String title,double value,double min,double max,String unit,ValueChanged<double> changed){
    final displayed=value==value.roundToDouble()?value.toInt().toString():value.toStringAsFixed(1);
    return Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Expanded(child:Text(title,style:const TextStyle(fontSize:12,fontWeight:FontWeight.w800))),Container(padding:const EdgeInsets.symmetric(horizontal:10,vertical:5),decoration:BoxDecoration(color:Palette.mint,borderRadius:BorderRadius.circular(9)),child:Text('${_document.digits(displayed)} $unit',style:const TextStyle(color:Palette.teal,fontWeight:FontWeight.w900,fontSize:12)))]),Slider(min:min,max:max,value:value.clamp(min,max).toDouble(),onChanged:changed)]);
  }
  Widget _switch(String label,bool value,ValueChanged<bool> changed)=>SwitchListTile.adaptive(contentPadding:EdgeInsets.zero,dense:true,title:Text(label,style:const TextStyle(fontSize:12,fontWeight:FontWeight.w700)),value:value,activeTrackColor:Palette.teal,onChanged:changed);

  Future<void> _showZoomedPage(PaperDocument document,
      List<PaperQuestion> questions, int index, int pageCount,
      int startingNumber) async {
    await Navigator.of(context).push<void>(MaterialPageRoute(
      builder: (_) => Scaffold(
        appBar: AppBar(title: const Text('تكبير صفحة الورقة')),
        body: SafeArea(child: Column(children: [
          const Padding(
            padding: EdgeInsets.all(10),
            child: Text('حرّك الصفحة بإصبعك وكبّرها بإصبعين لمراجعة الخط والأرقام قبل التصدير.',
                textAlign: TextAlign.center, style: TextStyle(fontSize: 12)),
          ),
          Expanded(child: InteractiveViewer(
            constrained: false,
            minScale: .35,
            maxScale: 5,
            boundaryMargin: const EdgeInsets.all(100),
            child: ExamPage(document: document, questions: questions,
                pageIndex: index, pageCount: pageCount,
                startingNumber: startingNumber, answers: _answers),
          )),
        ])),
      ),
    ));
  }

  Widget _preview(){final d=_document;final groups=PaperPages.paginate(d,answers:_answers);
    _pageOverflow.clear();
    final cover=d.documentType=='booklet' && d.includeCover;
    final tocCount=d.documentType=='booklet'?BookletPages.tocPageCount(d):0;
    final frontCount=(cover?1:0)+tocCount;
    _previewKeys=List.generate(groups.length+frontCount,(_)=>GlobalKey());
    final oversized=PaperPages.oversizedQuestions(d,answers:_answers);
    // Conservative early warning before A4 rendering has to scale text down.
    final nearFull = groups.any((group) => group.fold<double>(0,
        (height, q) => height + PaperPages.estimateHeight(q,d,answers:_answers))
        > PaperPages.bodyCapacity(d) * .87);
    var count=1;
    final pages=<Widget>[];
    Widget frontPage(Widget page, int keyIndex) => LayoutBuilder(builder:(context,box){
      final width=d.landscape?PaperPages.a4Height:PaperPages.a4Width;
      final height=d.landscape?PaperPages.a4Width:PaperPages.a4Height;
      final available=math.min(box.maxWidth,700.0);
      return Container(margin:const EdgeInsets.only(bottom:15),
        decoration:BoxDecoration(border:Border.all(color:Palette.line),boxShadow:[BoxShadow(color:Palette.ink.withValues(alpha:.08),blurRadius:14)]),
        child:SizedBox(width:available,height:available*height/width,
          child:FittedBox(fit:BoxFit.contain,
            child:RepaintBoundary(key:_previewKeys[keyIndex],child:page))));
    });
    if(cover) pages.add(frontPage(BookletCoverPage(document:d),0));
    if(tocCount>0){
      final sections=BookletPages.sections(d,groups,frontCount);
      for(var i=0;i<tocCount;i++){
        pages.add(frontPage(BookletTocPage(document:d,
          entries:sections.skip(i*18).take(18).toList(),part:i,totalParts:tocCount),
          (cover?1:0)+i));
      }
    }
    for(var i=0;i<groups.length;i++){
      final start=count;
      count+=groups[i].length;
      final width=d.landscape?PaperPages.a4Height:PaperPages.a4Width;
      final height=d.landscape?PaperPages.a4Width:PaperPages.a4Height;
      pages.add(LayoutBuilder(builder: (context, box) {
        final available = math.min(box.maxWidth, 700.0);
        return GestureDetector(
          onTap: () => _showZoomedPage(d, groups[i], i, groups.length, start),
          child: Container(
            margin: const EdgeInsets.only(bottom: 15),
            decoration: BoxDecoration(
              border: Border.all(color: Palette.line),
              boxShadow: [BoxShadow(color: Palette.ink.withValues(alpha: .10),
                  blurRadius: 20, offset: const Offset(0, 5))],
            ),
            child: SizedBox(
              width: available,
              height: available * height / width,
              child: FittedBox(
                fit: BoxFit.contain,
                child: RepaintBoundary(
                  key: _previewKeys[i+frontCount],
                  child: ExamPage(document: d, questions: groups[i],
                    pageIndex: i, pageCount: groups.length,
                    startingNumber: start, answers: _answers,
                    onPageOverflow:(overflow)=>_pageOverflow[i]=overflow),
                ),
              ),
            ),
          ),
        );
      }));
    }
    return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      _hero('04 / معاينة الطباعة','النتيجة النهائية','نفس شكل الصفحات يُستخدم للطباعة وتصدير PDF، بما فيه القالب النهائي المختار والألوان والأرقام والصور.',Icons.print_outlined,Palette.sand,const Color(0xFFAE803D)),
      _panel('نسخة المعاينة',Icons.visibility_outlined,Column(children:[Row(children:[Expanded(child:_choice('نسخة الطالب',!_answers,()=>setState(()=>_answers=false),icon:Icons.school_outlined)),const SizedBox(width:8),Expanded(child:_choice('مع الإجابات',_answers,()=>setState(()=>_answers=true),icon:Icons.check_circle_outline))]),const SizedBox(height:12),Row(children:[Icon(Icons.description_outlined,color:Palette.teal,size:18),const SizedBox(width:7),Text('عدد الصفحات التقديري: ${d.digits(groups.length+frontCount)}',style:const TextStyle(fontWeight:FontWeight.w700,fontSize:12)),const Spacer(),Text(d.landscape?'A4 أفقي':'A4 عمودي',style:const TextStyle(color:Palette.muted,fontSize:12))])])),
      if(d.compactForOnePage && groups.length>1)Container(
        margin:const EdgeInsets.only(bottom:12),padding:const EdgeInsets.all(12),
        decoration:BoxDecoration(color:const Color(0xFFFFF2D9),borderRadius:BorderRadius.circular(14)),
        child:const Text('وضع تقليل المسافات لم يستطع احتواء جميع الأسئلة في صفحة واحدة؛ سيُحافظ على الصفحات الإضافية لمنع حذف المحتوى.',style:TextStyle(fontSize:12)),
      ),
      if(nearFull && oversized.isEmpty)Container(
        margin:const EdgeInsets.only(bottom:12),
        padding:const EdgeInsets.all(12),
        decoration:BoxDecoration(color:const Color(0xFFFFF2D9),borderRadius:BorderRadius.circular(14)),
        child:const Text('الصفحة قريبة من الامتلاء. إذا لاحظت صِغر الأسئلة، قلّل المسافات أو قسّم الأسئلة بين صفحتين؛ لا تعتمد على حجم المعاينة المصغّرة وحده.',
            style:TextStyle(color:Color(0xFF744B14),fontSize:12)),
      ),
      if(oversized.isNotEmpty)Container(
        margin:const EdgeInsets.only(bottom:12),padding:const EdgeInsets.all(14),
        decoration:BoxDecoration(color:const Color(0xFFFFF0D7),borderRadius:BorderRadius.circular(16)),
        child:Text('تنبيه: السؤال/الأسئلة ${oversized.map(d.digits).join('، ')} أطول من المساحة المتاحة في صفحة A4. قسّم السؤال أو قلّل حجم الخط قبل الطباعة حتى لا يصبح صغيرًا جدًا.',
          style:const TextStyle(color:Color(0xFF754C12),fontWeight:FontWeight.w700,fontSize:12)),
      ),
      _panel('وضوح كتابة الأسئلة',Icons.format_size,Column(children:[
        _range('حجم الخط في الورقة',d.fontSize,11,23,'نقطة',
            (value)=>_edit(()=>d.fontSize=value)),
        const Text('هذه معاينة مصغّرة لورقة A4. اضغط الصفحة لتكبيرها وفحص الأرقام، والحجم المختار ينطبق على PDF.',
            style:TextStyle(color:Palette.muted,fontSize:11.5)),
      ])),
      Container(padding:const EdgeInsets.all(10),margin:const EdgeInsets.only(bottom:13),decoration:BoxDecoration(color:const Color(0xFFDFE6E8),borderRadius:BorderRadius.circular(21)),child:Column(children:pages)),
      _mainButton(_busy?'جارٍ تجهيز الملف...':'طباعة الورقة',Icons.print_rounded,_busy?(){}:()=>_export(false)),
      const SizedBox(height:10),_mainButton('تصدير الورقة: Word أو PDF',Icons.file_download_outlined,_busy?(){}:_chooseExportFormat,dark:true),
      const SizedBox(height:10),const Text('تقسيم صفحات A4 تقديري. عند وجود سؤال طويل جدًا ستظهر رسالة تطلب تقسيمه قبل الطباعة. راجع المعاينة قبل الحفظ.',textAlign:TextAlign.center,style:TextStyle(color:Palette.muted,fontSize:11,height:1.5)),
    ]);
  }

  Future<void> _export(bool share) async {
    if(_busy)return;
    if(!await _validateForExport())return;
    if(!mounted)return;
    final oversized=PaperPages.oversizedQuestions(_document,answers:_answers);
    if(oversized.isNotEmpty){
      _notice('يتجاوز السؤال ${_document.digits(oversized.first)} مساحة A4. قسّم السؤال قبل الطباعة.');
      return;
    }
    setState(()=>_busy=true);
    try{
      await WidgetsBinding.instance.endOfFrame;
      if(_pageOverflow.values.any((overflow)=>overflow)){
        throw StateError('تجاوز محتوى الأسئلة حدود A4. قسّم أحد الأسئلة أو استخدم صفحات إضافية؛ لن أصغّر الخط تلقائياً.');
      }
      if(share){await PrintService.sharePdf(_document,_previewKeys);}else{await PrintService.printPages(_document,_previewKeys);}
    }catch(e){_notice('تعذّر تجهيز الطباعة: $e');}
    if(mounted)setState(()=>_busy=false);
  }
}
