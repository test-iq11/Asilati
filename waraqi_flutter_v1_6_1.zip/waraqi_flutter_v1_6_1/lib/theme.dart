import 'package:flutter/material.dart';

class Palette {
  static const background = Color(0xFFF4F7F8);
  static const ink = Color(0xFF17333D);
  static const muted = Color(0xFF73858B);
  static const line = Color(0xFFE6EDEF);
  static const teal = Color(0xFF168C82);
  static const mint = Color(0xFFE1F5EC);
  static const blue = Color(0xFFDAF0F9);
  static const lilac = Color(0xFFECE7FA);
  static const sand = Color(0xFFFBEDD9);
  static const dark = Color(0xFF173D49);
  static const text = Color(0xFF1B3039);
}

ThemeData appTheme() {
  final base = ThemeData(useMaterial3: true, scaffoldBackgroundColor: Palette.background, colorScheme: ColorScheme.fromSeed(seedColor: Palette.teal, primary: Palette.teal, surface: Colors.white));
  return base.copyWith(
    appBarTheme: const AppBarTheme(backgroundColor: Palette.background, elevation: 0, scrolledUnderElevation: 0, titleTextStyle: TextStyle(color: Palette.ink,fontSize: 21,fontWeight: FontWeight.w800)),
    textTheme: base.textTheme.apply(fontFamily: 'sans', bodyColor: Palette.ink, displayColor: Palette.ink),
    inputDecorationTheme: InputDecorationTheme(filled:true,fillColor:const Color(0xFFF8FAFA),contentPadding:const EdgeInsets.symmetric(horizontal:15,vertical:13),border:OutlineInputBorder(borderRadius:BorderRadius.circular(16),borderSide:const BorderSide(color:Palette.line)),enabledBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(16),borderSide:const BorderSide(color:Palette.line)),focusedBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(16),borderSide:const BorderSide(color:Palette.teal,width:1.5))),
    cardTheme: CardThemeData(color:Colors.white,elevation:0,margin:EdgeInsets.zero,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(24))),
  );
}
