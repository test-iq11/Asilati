import 'package:flutter/material.dart';

/// Interactive table cell editor; compatible with the old pipe-separated
/// textual representation so older documents are not migrated or broken.
class TableEditorDialog extends StatefulWidget {
  const TableEditorDialog({super.key, required this.initialText});
  final String initialText;
  @override
  State<TableEditorDialog> createState() => _TableEditorDialogState();
}

class _TableEditorDialogState extends State<TableEditorDialog> {
  final _cells = <List<TextEditingController>>[];
  @override
  void initState() {
    super.initState();
    final rows = widget.initialText.trim().isEmpty
        ? <List<String>>[['', ''], ['', '']]
        : widget.initialText.split('\n').map((r) => r.split('|')).toList();
    final columns = rows.fold<int>(2, (max, row) => row.length > max ? row.length : max);
    for (final row in rows) {
      _cells.add(List.generate(columns, (c) => TextEditingController(text: c < row.length ? row[c] : '')));
    }
  }
  void _addRow() {
    if (_cells.length >= 20) return;
    setState(() => _cells.add(List.generate(_cells.first.length, (_) => TextEditingController())));
  }
  void _addColumn() {
    if (_cells.first.length >= 8) return;
    setState(() {for (final row in _cells) {row.add(TextEditingController());}});
  }
  void _removeRow() {
    if (_cells.length <= 1) return;
    setState(() {for (final c in _cells.removeLast()) {c.dispose();}});
  }
  void _removeColumn() {
    if (_cells.first.length <= 1) return;
    setState(() {for (final row in _cells) {row.removeLast().dispose();}});
  }
  @override
  void dispose() {
    for (final row in _cells) {for (final c in row) {c.dispose();}}
    super.dispose();
  }
  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('محرر الجدول التفاعلي'),
    content: SizedBox(width: 560, child: SingleChildScrollView(child: Column(
      crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min,
      children: [
        const Text('حرر كل خلية مباشرة. الحد الأقصى 20 صفاً و8 أعمدة.',
          style: TextStyle(fontSize: 12, color: Colors.black54)),
        const SizedBox(height: 12),
        SingleChildScrollView(scrollDirection: Axis.horizontal, child: Column(children: [
          for (var r = 0; r < _cells.length; r++)
            Row(children: [
              for (var c = 0; c < _cells[r].length; c++)
                SizedBox(width: 125, child: Padding(
                  padding: const EdgeInsets.all(3),
                  child: TextField(controller: _cells[r][c], maxLines: 2,
                    decoration: InputDecoration(isDense: true, hintText: 'صف ${r + 1}، عمود ${c + 1}')),
                )),
            ]),
        ])),
        const SizedBox(height: 14),
        Wrap(spacing: 8, runSpacing: 6, children: [
          OutlinedButton.icon(onPressed: _addRow, icon: const Icon(Icons.add), label: const Text('صف')),
          OutlinedButton.icon(onPressed: _addColumn, icon: const Icon(Icons.add), label: const Text('عمود')),
          OutlinedButton.icon(onPressed: _removeRow, icon: const Icon(Icons.remove), label: const Text('حذف صف')),
          OutlinedButton.icon(onPressed: _removeColumn, icon: const Icon(Icons.remove), label: const Text('حذف عمود')),
        ]),
      ],
    ))),
    actions: [
      TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
      FilledButton(onPressed: () {
        final result = _cells.map((row) => row.map((c) => c.text.replaceAll('|', ' ')
          .replaceAll('\n', ' ')).join('|')).join('\n');
        Navigator.pop(context, result);
      }, child: const Text('حفظ الجدول')),
    ],
  );
}
