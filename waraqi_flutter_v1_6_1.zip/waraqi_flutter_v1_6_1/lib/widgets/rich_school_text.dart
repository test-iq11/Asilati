import 'package:flutter/material.dart';

/// Lightweight editable inline markup that does not require a WebView.
/// **bold**, __underline__, ~~strike~~. Arabic diacritics stay untouched.
class RichSchoolText extends StatelessWidget {
  const RichSchoolText(this.source, {super.key, required this.style});
  final String source;
  final TextStyle style;

  static final RegExp tokens = RegExp(r'(\*\*(.*?)\*\*|__(.*?)__|~~(.*?)~~)', dotAll: true);

  static List<InlineSpan> spans(String value, TextStyle style) {
    final result=<InlineSpan>[];
    var last=0;
    for(final match in tokens.allMatches(value)){
      if(match.start>last)result.add(TextSpan(text:value.substring(last,match.start)));
      if(match.group(2)!=null){
        result.add(TextSpan(text:match.group(2),style:style.copyWith(fontWeight:FontWeight.bold)));
      }else if(match.group(3)!=null){
        result.add(TextSpan(text:match.group(3),style:style.copyWith(decoration:TextDecoration.underline)));
      }else if(match.group(4)!=null){
        result.add(TextSpan(text:match.group(4),style:style.copyWith(decoration:TextDecoration.lineThrough)));
      }
      last=match.end;
    }
    if(last<value.length)result.add(TextSpan(text:value.substring(last)));
    return result;
  }

  @override
  Widget build(BuildContext context) => Text.rich(
    TextSpan(style:style,children:spans(source,style)),textDirection:TextDirection.rtl,
  );
}
