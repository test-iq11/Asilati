import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';

/// Offline vector geometry editor. Geometry is stored as small JSON text in a
/// PaperElement, so it survives backups and stays independent of a canvas size.
class GeometryFigure {
  GeometryFigure({required this.type, required this.points, this.label = ''});
  String type;
  String label;
  List<Offset> points;

  factory GeometryFigure.fromText(String text) {
    try {
      final data = jsonDecode(text) as Map<String, dynamic>;
      final raw = data['points'] as List<dynamic>;
      return GeometryFigure(
        type: data['type']?.toString() ?? 'triangle',
        label: data['label']?.toString() ?? '',
        points: raw.map((value) {
          final coordinates = value as List<dynamic>;
          return Offset(
            (coordinates[0] as num).toDouble().clamp(0.0, 1.0).toDouble(),
            (coordinates[1] as num).toDouble().clamp(0.0, 1.0).toDouble(),
          );
        }).toList(),
      );
    } catch (_) {
      return GeometryFigure(type: 'triangle', points: defaults('triangle'));
    }
  }

  String encode() => jsonEncode({
    'type': type, 'label': label,
    'points': points.map((p) => [p.dx, p.dy]).toList(),
  });

  static List<Offset> defaults(String type) => switch (type) {
    'line' => [const Offset(.15, .65), const Offset(.84, .32)],
    'rectangle' => [const Offset(.19, .2), const Offset(.82, .78)],
    'circle' => [const Offset(.5, .5), const Offset(.75, .5)],
    'angle' => [const Offset(.18, .72), const Offset(.46, .72), const Offset(.75, .28)],
    'axes' => [const Offset(.15, .75), const Offset(.85, .75), const Offset(.25, .92), const Offset(.25, .16)],
    'force' => [const Offset(.18, .72), const Offset(.80, .22)],
    'inclined' => [const Offset(.18, .82), const Offset(.83, .82), const Offset(.83, .25)],
    _ => [const Offset(.48, .12), const Offset(.16, .84), const Offset(.86, .84)],
  };
}

class GeometryCanvas extends StatelessWidget {
  const GeometryCanvas({super.key, required this.figure, this.onPointChanged, this.height = 200});
  final GeometryFigure figure;
  final void Function(int, Offset)? onPointChanged;
  final double height;

  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (context, constraints) {
    final width = constraints.maxWidth.isFinite ? constraints.maxWidth : 320.0;
    return SizedBox(
      width: width, height: height,
      child: Stack(children: [
        Positioned.fill(child: CustomPaint(painter: _GeometryPainter(figure))),
        if (onPointChanged != null)
          for (var i = 0; i < figure.points.length; i++)
            Positioned(
              left: figure.points[i].dx * width - 17,
              top: figure.points[i].dy * height - 17,
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onPanUpdate: (details) {
                  final current = figure.points[i];
                  onPointChanged!(i, Offset(
                    (current.dx + details.delta.dx / width).clamp(.02, .98).toDouble(),
                    (current.dy + details.delta.dy / height).clamp(.02, .98).toDouble(),
                  ));
                },
                child: Container(
                  height: 34, width: 34,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle, color: Colors.white,
                    border: Border.all(color: const Color(0xFF178B7F), width: 2),
                  ),
                  child: Center(child: Text('${i + 1}', style: const TextStyle(fontSize: 11))),
                ),
              ),
            ),
      ]),
    );
  });
}

class _GeometryPainter extends CustomPainter {
  _GeometryPainter(this.figure);
  final GeometryFigure figure;
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0xFF17333D)..style = PaintingStyle.stroke..strokeWidth = 2;
    final points = figure.points.map((p) => Offset(p.dx * size.width, p.dy * size.height)).toList();
    if (points.length < 2) return;
    void arrow(Offset from, Offset to) {
      canvas.drawLine(from, to, paint);
      final angle=math.atan2(to.dy-from.dy,to.dx-from.dx);
      const length=15.0;
      canvas.drawLine(to, Offset(to.dx-length*math.cos(angle-.45),to.dy-length*math.sin(angle-.45)),paint);
      canvas.drawLine(to, Offset(to.dx-length*math.cos(angle+.45),to.dy-length*math.sin(angle+.45)),paint);
    }
    switch (figure.type) {
      case 'circle':
        canvas.drawCircle(points[0], (points[1] - points[0]).distance, paint);
      case 'rectangle':
        canvas.drawRect(Rect.fromPoints(points[0], points[1]), paint);
      case 'line':
        canvas.drawLine(points[0], points[1], paint);
      case 'force':
        arrow(points[0], points[1]);
      case 'axes':
        if(points.length>=4){arrow(points[0],points[1]);arrow(points[2],points[3]);}
      case 'angle':
        if(points.length>=3){canvas.drawLine(points[1],points[0],paint);
          canvas.drawLine(points[1],points[2],paint);
          canvas.drawCircle(points[1],7,paint..strokeWidth=1);}
      case 'inclined':
        if(points.length>=3){
          canvas.drawLine(points[0],points[1],paint);
          canvas.drawLine(points[0],points[2],paint);
          canvas.drawLine(points[1],points[2],paint);
        }
      default:
        final path = Path()..moveTo(points[0].dx, points[0].dy);
        for (final point in points.skip(1)) {path.lineTo(point.dx, point.dy);}
        path.close();
        canvas.drawPath(path, paint);
    }
    if (figure.label.isNotEmpty) {
      final painter = TextPainter(
        text: TextSpan(text: figure.label, style: const TextStyle(color: Color(0xFF17333D), fontSize: 15)),
        textDirection: TextDirection.rtl,
      )..layout(maxWidth: size.width - 12);
      painter.paint(canvas, const Offset(6, 6));
    }
  }
  @override
  bool shouldRepaint(covariant _GeometryPainter oldDelegate) => true;
}

Future<String?> showGeometryEditor(BuildContext context, String initial) async {
  final figure = GeometryFigure.fromText(initial);
  final label = TextEditingController(text: figure.label);
  try {
    return await showDialog<String>(context: context, builder: (dialogContext) =>
      StatefulBuilder(builder: (dialogContext, update) => AlertDialog(
        title: const Text('رسم هندسي قابل للتحرير'),
        content: SizedBox(width: 420, child: SingleChildScrollView(child: Column(
          mainAxisSize: MainAxisSize.min, children: [
            Wrap(spacing: 7, runSpacing: 7, children: [
              for (final type in ['triangle', 'rectangle', 'circle', 'line', 'angle', 'axes', 'force', 'inclined'])
                ChoiceChip(
                  label: Text(switch (type) {'triangle' => 'مثلث', 'rectangle' => 'مستطيل', 'circle' => 'دائرة', 'angle' => 'زاوية', 'axes' => 'محاور', 'force' => 'سهم قوة', 'inclined' => 'مستوى مائل', _ => 'مستقيم'}),
                  selected: figure.type == type,
                  onSelected: (_) => update(() {figure.type = type; figure.points = GeometryFigure.defaults(type);}),
                ),
            ]),
            const SizedBox(height: 12),
            Container(
              decoration: BoxDecoration(color: const Color(0xFFF4F8FA), borderRadius: BorderRadius.circular(12)),
              child: Padding(padding: const EdgeInsets.all(18), child: GeometryCanvas(
                figure: figure, height: 190,
                onPointChanged: (index, point) => update(() => figure.points[index] = point),
              )),
            ),
            const SizedBox(height: 8),
            const Text('اسحب نقاط الشكل لتغيير الأبعاد والموقع', style: TextStyle(fontSize: 12)),
            const SizedBox(height: 12),
            TextField(controller: label, decoration: const InputDecoration(labelText: 'تسمية الشكل (اختياري)')),
          ],
        ))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إلغاء')),
          FilledButton(onPressed: () {figure.label = label.text; Navigator.pop(dialogContext, figure.encode());}, child: const Text('إضافة الرسم')),
        ],
      )),
    );
  } finally {label.dispose();}
}
