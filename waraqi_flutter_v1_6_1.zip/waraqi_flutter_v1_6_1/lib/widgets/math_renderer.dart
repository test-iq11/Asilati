import 'package:flutter/material.dart';

/// Lightweight offline formula renderer for common school-level structures.
/// Supports \frac{a}{b}, \sqrt{x}, x^{n}; unsupported TeX is shown literally.
class MathRenderer extends StatelessWidget {
  const MathRenderer(this.source, {super.key, this.fontSize = 17, this.color = Colors.black});
  final String source;
  final double fontSize;
  final Color color;

  static final RegExp _formula = RegExp(
    r'\\frac\{([^{}]+)\}\{([^{}]+)\}|\\sqrt\{([^{}]+)\}|([A-Za-z0-9]+)\^\{([^{}]+)\}',
  );

  @override
  Widget build(BuildContext context) {
    final spans = <InlineSpan>[];
    var cursor = 0;
    final style = TextStyle(fontSize: fontSize, color: color, fontWeight: FontWeight.w600);
    for (final match in _formula.allMatches(source)) {
      if (match.start > cursor) {
        spans.add(TextSpan(text: source.substring(cursor, match.start)));
      }
      if (match.group(1) != null) {
        spans.add(WidgetSpan(
          alignment: PlaceholderAlignment.middle,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(match.group(1)!, style: style.copyWith(fontSize: fontSize * .82)),
            Container(height: 1, width: 38, color: color),
            Text(match.group(2)!, style: style.copyWith(fontSize: fontSize * .82)),
          ]),
        ));
      } else if (match.group(3) != null) {
        spans.add(WidgetSpan(
          alignment: PlaceholderAlignment.middle,
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Text('√', style: style.copyWith(fontSize: fontSize * 1.3)),
            Container(
              padding: const EdgeInsets.only(top: 2, left: 3, right: 3),
              decoration: BoxDecoration(border: Border(top: BorderSide(color: color))),
              child: Text(match.group(3)!, style: style),
            ),
          ]),
        ));
      } else {
        spans.add(WidgetSpan(
          alignment: PlaceholderAlignment.middle,
          child: Row(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(match.group(4)!, style: style),
            Text(match.group(5)!, style: style.copyWith(fontSize: fontSize * .65)),
          ]),
        ));
      }
      cursor = match.end;
    }
    if (cursor < source.length) spans.add(TextSpan(text: source.substring(cursor)));
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Text.rich(TextSpan(style: style, children: spans), textAlign: TextAlign.center),
    );
  }
}
