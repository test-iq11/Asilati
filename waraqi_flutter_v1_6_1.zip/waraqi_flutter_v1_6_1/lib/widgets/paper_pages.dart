import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../models/paper_document.dart';
import 'math_renderer.dart';
import 'rich_school_text.dart';
import 'geometry_editor.dart';

/// One unified digit formatter for every question label, branch, preview and
/// PDF snapshot. Never build a label with a separate digit-style decision.
String _ordinal(PaperDocument document, int number, String mode) {
  if (mode == 'letters') {
    const letters = 'أبجدهوزحطيكلمنسعفصقرشتثخذضظغ';
    final index = number - 1;
    return index >= 0 && index < letters.length ? letters[index] : document.digits(number);
  }
  if (mode == 'roman') {
    const roman = ['I','II','III','IV','V','VI','VII','VIII','IX','X'];
    return number > 0 && number <= roman.length ? roman[number - 1] : document.digits(number);
  }
  return document.digits(number);
}

String questionPrintLabel(PaperDocument document, int number, String text) =>
    'س ${_ordinal(document, number + document.questionSequenceStart - 1, document.questionNumbering)}: ${document.digits(text)}';

String branchPrintLabel(PaperDocument document, int number, String text) =>
    '(${_ordinal(document, number, document.branchNumbering)}) ${document.digits(text)}';

/// A4 in PDF points (72 dpi). The exact same widgets are captured for printing.
class PaperPages {
  static const a4Width = 595.28;
  static const a4Height = 841.89;
  static double mm(double value) => value*72/25.4;
  static double questionFont(PaperDocument doc) => doc.fontSize; // Never silently reduce print font.
  static double questionSpacing(PaperDocument doc) => doc.questionGap * (doc.compactForOnePage ? .60 : 1);

  static List<List<PaperQuestion>> paginate(PaperDocument doc, {required bool answers}) {
    final available=bodyCapacity(doc);
    final pages=<List<PaperQuestion>>[[]];
    var used=0.0;
    for(final q in doc.questions.where((q)=>q.visible)) {
      final score=estimateHeight(q,doc,answers:answers);
      if(pages.last.isNotEmpty && (q.pageBreakBefore || used+score>available)){pages.add([]);used=0;}
      pages.last.add(q);used+=score;
    }
    return pages;
  }

  /// Conservative page-body budget, taking header/footer, margins and notes
  /// into account. Repeated headers on later pages are intentionally reserved.
  static double bodyCapacity(PaperDocument doc) {
    final pageHeight=doc.landscape?a4Width:a4Height;
    const premiumLayouts = {'globalEmerald','royalBlue','sandGold','mintClassic','plumModern'};
    final reserved = premiumLayouts.contains(doc.paperLayout)
        ? (doc.landscape ? 310.0 : 340.0)
        : 245.0;
    final overhead=mm(doc.topMarginMm+doc.bottomMarginMm) + reserved + mm(doc.headerGapMm);
    return math.max(75.0,pageHeight-overhead);
  }

  /// A very long question may require manual splitting. Do not silently crop it.
  static List<int> oversizedQuestions(PaperDocument doc,{required bool answers}) {
    final available=bodyCapacity(doc);
    final result=<int>[];
    for(var i=0;i<doc.questions.length;i++){
      final q=doc.questions[i];
      if(q.visible && estimateHeight(q,doc,answers:answers)>available){
        result.add(i+1);
      }
    }
    return result;
  }

  static double estimateHeight(PaperQuestion q,PaperDocument doc,{required bool answers}) {
    final fs=questionFont(doc);
    final lineWidth=math.max(23,(doc.landscape?100:55) * (15/fs)).round();
    double measure(String s)=>math.max(1,(s.length/lineWidth).ceil())*fs*doc.lineSpacing;
    var height=40+measure(q.text)+questionSpacing(doc);
    if(q.sectionTitle.trim().isNotEmpty)height+=fs*2.3;
    for(var i=0;i<q.branches.length;i++){
      height+=measure(q.branches[i])+4;
      if(i<q.branchSubpoints.length){
        for(final point in q.branchSubpoints[i].where((p)=>p.visible)){
          height+=measure(point.text)+12;
          if(answers && point.answer.isNotEmpty)height+=measure(point.answer)+8;
        }
      }
    }
    if(q.requiredBranches > 0)height+=fs*1.6;
    for(final e in q.elements){
      if(e.imagePath!=null){height+=160*e.imageScale + (e.caption.isEmpty ? 0 : fs*2);}
      else if(e.kind=='geometry'){height+=185;}
      else if(e.kind=='gallery'){height+=math.max(65, (e.galleryImages.length/2).ceil()*160.0);}
      else if(e.kind=='poetry'){height+=math.max(45,e.text.split('\n').length*42.0);}
      else if(e.kind=='table'){height+=math.max(55,e.text.split('\n').length*32.0);}
      else {height+=math.max(35,measure(e.text)+12);}
    }
    if(doc.showRules && q.branches.isEmpty && q.elements.isEmpty)height+=44;
    if(answers && q.answer.isNotEmpty)height+=measure(q.answer)+22;
    // Prefer an extra page over shrinking all of the printed questions.
    return height * 1.12;
  }
}

class ExamPage extends StatelessWidget {
  const ExamPage({super.key,required this.document,required this.questions,required this.pageIndex,required this.pageCount,required this.startingNumber,required this.answers,this.onPageOverflow});
  final PaperDocument document;
  final List<PaperQuestion> questions;
  final int pageIndex,pageCount,startingNumber;
  final bool answers;

  bool get _fancyLayout => const {'globalEmerald','royalBlue','sandGold','mintClassic','plumModern'}.contains(document.paperLayout);

  _ExamVisualStyle get _style {
    switch(document.paperLayout){
      case 'royalBlue':
        return const _ExamVisualStyle(primary:Color(0xFF1F4E8C), secondary:Color(0xFF7BA7DA), soft:Color(0xFFEFF5FC), card:Color(0xFFF7FAFD), ink:Color(0xFF152339));
      case 'sandGold':
        return const _ExamVisualStyle(primary:Color(0xFF8A641E), secondary:Color(0xFFD7B36A), soft:Color(0xFFFBF4E6), card:Color(0xFFFFFCF6), ink:Color(0xFF2B2518));
      case 'mintClassic':
        return const _ExamVisualStyle(primary:Color(0xFF2A6652), secondary:Color(0xFF9BC9B3), soft:Color(0xFFEFF8F3), card:Color(0xFFF9FCFA), ink:Color(0xFF183028));
      case 'plumModern':
        return const _ExamVisualStyle(primary:Color(0xFF6A3F78), secondary:Color(0xFFB99BC6), soft:Color(0xFFF5EDF7), card:Color(0xFFFCFAFD), ink:Color(0xFF241B28));
      case 'globalEmerald':
      default:
        return const _ExamVisualStyle(primary:Color(0xFF0F6A59), secondary:Color(0xFFCFA647), soft:Color(0xFFEEF6F4), card:Color(0xFFFDFDFB), ink:Color(0xFF17201D));
    }
  }

  bool _v(String name)=>document.headerFields.contains(name);
  String _label(String ar,String en)=>document.paperLanguage=='en'?en:ar;

  Widget _fancyTopDecoration(){
    final s=_style;
    return Stack(children:[
      Positioned(top:0,left:0,right:null,child:Container(width:170,height:64,decoration:BoxDecoration(
        gradient:LinearGradient(colors:[s.primary,s.primary.withValues(alpha:.85),s.secondary.withValues(alpha:.85)]),
        borderRadius:const BorderRadius.only(topLeft:Radius.circular(8),bottomRight:Radius.circular(80))))),
      Positioned(bottom:0,right:0,child:Container(width:185,height:52,decoration:BoxDecoration(
        gradient:LinearGradient(colors:[s.secondary.withValues(alpha:.9),s.primary.withValues(alpha:.92)]),
        borderRadius:const BorderRadius.only(topLeft:Radius.circular(90),bottomRight:Radius.circular(8))))),
    ]);
  }

  final ValueChanged<bool>? onPageOverflow;

  @override
  Widget build(BuildContext context) {
    final d = document;
    final isFirst = pageIndex == 0;
    final w = d.landscape ? PaperPages.a4Height : PaperPages.a4Width;
    final h = d.landscape ? PaperPages.a4Width : PaperPages.a4Height;
    const ink = Color(0xFF171B1D);
    final textStyle = TextStyle(
      color: ink,
      fontSize: PaperPages.questionFont(d),
      fontFamily: d.paperFontFamily == 'system' ? null : d.paperFontFamily,
      height: d.lineSpacing,
      fontWeight: FontWeight.w400,
    );

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Container(
        width: w,
        height: h,
        color: Colors.white,
        child: Stack(
          children: [
            if (_fancyLayout) Positioned.fill(child:_fancyTopDecoration()),
            if (d.paperLayout == 'mathFrame')
              Positioned.fill(
                child: Padding(
                  padding: const EdgeInsets.all(15),
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      border: Border.all(color: ink, width: 1.5),
                    ),
                  ),
                ),
              ),
            Padding(
              padding: EdgeInsets.only(
                left: PaperPages.mm(d.sideMarginMm),
                right: PaperPages.mm(d.sideMarginMm),
                top: PaperPages.mm(d.topMarginMm),
                bottom: PaperPages.mm(d.bottomMarginMm),
              ),
              // The height of the header is not fixed: long school names,
              // high font sizes and landscape A4 can wrap it over many lines.
              // Limit the header and footer *before* allocating the body so
              // non-flex children cannot overflow the printed page.
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final contentWidth = constraints.maxWidth;
                  final contentHeight = constraints.maxHeight;
                  final headerLimit = contentHeight * 0.53;
                  final footerLimit = contentHeight * 0.22;

                  final header = isFirst
                      ? Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            _header(),
                            SizedBox(height: PaperPages.mm(d.headerGapMm)),
                            if (d.showHeaderLine)
                              const Divider(
                                color: Colors.black54,
                                height: 1,
                                thickness: .65,
                              ),
                            const SizedBox(height: 9),
                            _studentIdentityFields(),
                            if (d.topNote.isNotEmpty)
                              _sectionBlock(d.digits(d.topNote)),
                            if (d.requiredQuestions > 0)
                              _sectionBlock('أجب عن ${d.digits(d.requiredQuestions)} من ${d.digits(d.questions.where((q)=>q.visible).length)} أسئلة'),
                          ],
                        )
                      : Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: Text(
                            d.digits(d.title),
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: d.fontSize * .9,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        );

                  final footer = Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      if (d.teacherName.trim().isNotEmpty || d.signatures.any((s)=>s.name.trim().isNotEmpty) || d.showSignatureLine ||
                          (d.showFooter && d.footerText.trim().isNotEmpty))
                        _footerBlock(),
                      if (d.showPageNumbers)
                        Padding(
                          padding: const EdgeInsets.only(top: 5),
                          child: Text(
                            'صفحة ${d.digits(pageIndex + 1)} من ${d.digits(pageCount)}',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: d.fontSize * .65,
                              color: Colors.black54,
                            ),
                          ),
                        ),
                    ],
                  );

                  return DefaultTextStyle(
                    style: textStyle,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        _fitPageSection(
                          contentWidth: contentWidth,
                          maxHeight: headerLimit,
                          child: header,
                        ),
                        // The question area always receives a bounded share
                        // of the page. Long questions are checked separately
                        // by oversizedQuestions before export.
                        Expanded(
                          child: _MeasuredQuestionBody(
                            onMeasured: onPageOverflow,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                for (var i = 0; i < questions.length; i++)
                                  _question(questions[i],startingNumber + i,textStyle),
                              ],
                            ),
                          ),
                        ),
                        if (d.teacherName.trim().isNotEmpty || d.signatures.any((s)=>s.name.trim().isNotEmpty) || d.showSignatureLine ||
                            (d.showFooter && d.footerText.trim().isNotEmpty) ||
                            d.showPageNumbers)
                          _fitPageSection(
                            contentWidth: contentWidth,
                            maxHeight: footerLimit,
                            child: footer,
                          ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Let compact, landscape pages scale header/footer content down when
  /// necessary, instead of allowing a RenderFlex overflow to obscure it.
  /// The box stays at the original scale when its contents already fit.
  Widget _fitPageSection({
    required double contentWidth,
    required double maxHeight,
    required Widget child,
  }) {
    return ConstrainedBox(
      constraints: BoxConstraints(maxHeight: maxHeight),
      child: FittedBox(
        fit: BoxFit.scaleDown,
        alignment: Alignment.topCenter,
        child: SizedBox(width: contentWidth, child: child),
      ),
    );
  }

  /// Printable answer rules, not literal dots: a fixed number of dots in a
  /// Row would exceed the A4 body width (especially with larger font/margins).
  /// Each rule receives a finite width and the fields stack when needed.
  Widget _studentIdentityFields() {
    if(!document.showStudentNameField && !document.showSectionField){
      return const SizedBox.shrink();
    }
    if(_fancyLayout){
      final s=_style;
      Widget item(String label)=>Expanded(child:Container(
        padding:const EdgeInsets.symmetric(horizontal:14,vertical:10),
        decoration:BoxDecoration(color:s.soft.withValues(alpha:.9),borderRadius:BorderRadius.circular(16),border:Border.all(color:s.primary.withValues(alpha:.22))),
        child:Row(children:[Text(label,style:TextStyle(fontSize:document.fontSize*.82,fontWeight:FontWeight.w900,color:s.ink)),const SizedBox(width:8),Expanded(child:Container(height:18,decoration:BoxDecoration(border:Border(bottom:BorderSide(color:s.primary.withValues(alpha:.35),width:1)))))]),
      ));
      return Padding(
        padding:const EdgeInsets.only(top:4,bottom:4),
        child:Row(children:[
          if(document.showStudentNameField)item(document.paperLanguage=='en'?'Student name':'اسم الطالب'),
          if(document.showStudentNameField && document.showSectionField) const SizedBox(width:12),
          if(document.showSectionField)item(document.paperLanguage=='en'?'Class/Section':'الشعبة'),
        ]),
      );
    }
    final labelStyle = TextStyle(fontSize: document.fontSize * .68);
    Widget field(String label) => Row(children: [
      Flexible(
        fit: FlexFit.loose,
        child: Text(label, softWrap: true, style: labelStyle),
      ),
      const SizedBox(width: 7),
      Expanded(child: Container(
        height: math.max(13.0, document.fontSize * .9),
        decoration: const BoxDecoration(
          border: Border(bottom: BorderSide(color: Colors.black54, width: .6)),
        ),
      )),
    ]);
    return LayoutBuilder(builder: (context, constraints) {
      final items=<Widget>[];
      if(document.showStudentNameField){items.add(field(document.paperLanguage=='en'?'Student name:':'اسم الطالب:'));}
      if(document.showSectionField){items.add(field(document.paperLanguage=='en'?'Class/Section:':'الصف/الشعبة:'));}
      if (constraints.maxWidth < 400 || items.length == 1) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [for (var i = 0; i < items.length; i++) ...[items[i], if (i != items.length - 1) const SizedBox(height: 8)]],
        );
      }
      return Row(children: [
        if(document.showStudentNameField) Expanded(flex: 3, child: field(document.paperLanguage=='en'?'Student name:':'اسم الطالب:')),
        if(document.showStudentNameField && document.showSectionField) const SizedBox(width: 18),
        if(document.showSectionField) Expanded(flex: 2, child: field(document.paperLanguage=='en'?'Class/Section:':'الصف/الشعبة:')),
      ]);
    });
  }

  Widget _sectionBlock(String text)=>Padding(
    padding:const EdgeInsets.symmetric(vertical:8),
    child:Container(
      padding:const EdgeInsets.symmetric(horizontal:10,vertical:8),
      decoration:BoxDecoration(borderRadius:BorderRadius.circular(10),color:_fancyLayout?_style.soft:const Color(0xFFF8FAFB),border:_fancyLayout?Border.all(color:_style.primary.withValues(alpha:.18)):null),
      child:Text(text,textAlign:TextAlign.center,style:TextStyle(fontSize:document.fontSize*1.02,fontWeight:FontWeight.w800,color:_fancyLayout?_style.ink:null)),
    ),
  );

  Widget _footerBlock(){
    final d=document;
    if(_fancyLayout){
      final s=_style;
      final leading=<Widget>[];
      if(d.teacherName.trim().isNotEmpty){
        leading.add(Container(
          padding:const EdgeInsets.symmetric(horizontal:14,vertical:8),
          decoration:BoxDecoration(color:s.soft,borderRadius:BorderRadius.circular(14),border:Border.all(color:s.secondary.withValues(alpha:.6))),
          child:Text('معلم المادة: ${d.digits(d.teacherName)}${d.teacherRole.trim().isEmpty ? '' : ' — ${d.digits(d.teacherRole)}'}',style:TextStyle(fontWeight:FontWeight.w900,fontSize:d.fontSize*.84,color:s.primary)),
        ));
      }
      final signs=d.signatures.where((sign)=>sign.name.trim().isNotEmpty).toList();
      return Padding(
        padding:const EdgeInsets.only(top:6),
        child:Column(children:[
          if(leading.isNotEmpty) Align(alignment:Alignment.centerRight,child:leading.first),
          if(signs.isNotEmpty) const SizedBox(height:8),
          if(signs.isNotEmpty) Row(children:[for(final sign in signs.take(4)) Expanded(child:Column(children:[
            Text(d.digits(sign.name),textAlign:TextAlign.center,style:TextStyle(fontSize:d.fontSize*.72,fontWeight:FontWeight.bold,color:s.ink)),
            if(sign.role.trim().isNotEmpty) Text(d.digits(sign.role),textAlign:TextAlign.center,style:TextStyle(fontSize:d.fontSize*.62,color:s.primary)),
            if(d.showSignatureLine) Text('_________',style:TextStyle(fontSize:d.fontSize*.6,color:s.primary)),
          ]))]),
          if(d.showFooter && d.footerText.trim().isNotEmpty) const SizedBox(height:8),
          if(d.showFooter && d.footerText.trim().isNotEmpty) Text(d.digits(d.footerText),textAlign:TextAlign.center,style:TextStyle(fontSize:d.fontSize*.82,fontWeight:FontWeight.w800,color:s.primary)),
        ]),
      );
    }
    final lines=<Widget>[];
    if(d.teacherName.trim().isNotEmpty){
      lines.add(Align(alignment:d.signatureSide=='right'?Alignment.centerRight:Alignment.centerLeft,child:Text('معلم المادة: ${d.digits(d.teacherName)}${d.teacherRole.trim().isEmpty ? '' : ' — ${d.digits(d.teacherRole)}'}',textAlign:d.signatureSide=='right'?TextAlign.right:TextAlign.left,style:TextStyle(fontSize:d.fontSize*1.02,fontWeight:FontWeight.w800))));
      if(d.showSignatureLine) lines.add(Align(alignment:d.signatureSide=='right'?Alignment.centerRight:Alignment.centerLeft,child:Text('التوقيع: __________________',style:TextStyle(fontSize:d.fontSize*.82))));
    }
    final signs=d.signatures.where((sign)=>sign.name.trim().isNotEmpty).toList();
    for(var start=0;start<signs.length;start+=4){
      final row=signs.skip(start).take(4).toList();
      lines.add(Padding(padding:const EdgeInsets.only(top:6),child:Row(
        crossAxisAlignment:CrossAxisAlignment.start,children:[
          for(final sign in row) Expanded(child:Column(children:[
            Text(d.digits(sign.name),textAlign:TextAlign.center,
              style:TextStyle(fontSize:d.fontSize*.76,fontWeight:FontWeight.bold)),
            if(sign.role.trim().isNotEmpty)Text(d.digits(sign.role),textAlign:TextAlign.center,
              style:TextStyle(fontSize:d.fontSize*.66)),
            if(d.showSignatureLine)Text('_________',style:TextStyle(fontSize:d.fontSize*.62)),
          ])),
        ])));
    }
    if(d.showFooter && d.footerText.trim().isNotEmpty){
      lines.add(Text(d.digits(d.footerText),textAlign:TextAlign.center,style:TextStyle(fontSize:d.fontSize*1.02,fontWeight:FontWeight.w800)));
    }
    return Padding(
      padding:const EdgeInsets.only(top:4),
      child:Container(
        padding:const EdgeInsets.symmetric(horizontal:10,vertical:8),
        decoration:BoxDecoration(borderRadius:BorderRadius.circular(10),color:const Color(0xFFF8FAFB)),
        child:Column(mainAxisSize:MainAxisSize.min,children:[for(var i=0;i<lines.length;i++) ...[lines[i], if(i!=lines.length-1) const SizedBox(height:4)]]),
      ),
    );
  }

  Widget _header(){
    final d=document;
    if(_fancyLayout){
      final s=_style;
      Widget sidePanel(List<Widget> children,{CrossAxisAlignment align=CrossAxisAlignment.end})=>Container(
        padding:const EdgeInsets.symmetric(horizontal:14,vertical:12),
        decoration:BoxDecoration(color:s.card,borderRadius:BorderRadius.circular(18),border:Border.all(color:s.secondary.withValues(alpha:.55))),
        child:Column(crossAxisAlignment:align,children:children),
      );
      Widget infoLine(String key,String text,{TextAlign align=TextAlign.right})=>_v(key)?Padding(padding:const EdgeInsets.symmetric(vertical:2),child:Text(d.digits(text),textAlign:align,style:TextStyle(fontSize:d.fontSize*.82,fontWeight:FontWeight.w800,color:s.ink))):const SizedBox.shrink();
      return Column(children:[
        Row(children:[
          Expanded(child:sidePanel([
            infoLine('subject','${_label('المادة','Subject')}: ${d.subject}',align:TextAlign.left),
            infoLine('grade','${_label('الصف','Class')}: ${d.grade}',align:TextAlign.left),
            infoLine('duration','${_label('الوقت','Time')}: ${d.duration}',align:TextAlign.left),
          ],align:CrossAxisAlignment.start)),
          const SizedBox(width:12),
          Expanded(flex:2,child:Column(children:[
            Text(d.digits(d.bismillah),style:TextStyle(fontSize:d.fontSize*.9,fontWeight:FontWeight.w900,color:s.primary)),
            const SizedBox(height:7),
            Container(
              padding:const EdgeInsets.symmetric(horizontal:16,vertical:12),
              decoration:BoxDecoration(
                gradient:LinearGradient(colors:[s.primary,s.primary.withValues(alpha:.92)]),
                borderRadius:BorderRadius.circular(22),
                border:Border.all(color:s.secondary,width:2)),
              child:Column(children:[
                if(_v('title')) Text(d.digits(d.title),textAlign:TextAlign.center,style:TextStyle(color:Colors.white,fontSize:d.fontSize*1.22,fontWeight:FontWeight.w900)),
                if(_v('academicYear')) const SizedBox(height:6),
                if(_v('academicYear')) Container(
                  padding:const EdgeInsets.symmetric(horizontal:16,vertical:5),
                  decoration:BoxDecoration(color:Colors.white.withValues(alpha:.92),borderRadius:BorderRadius.circular(20)),
                  child:Text('${_label('للعام الدراسي','Academic year')} ${d.digits(d.academicYear)}',textAlign:TextAlign.center,style:TextStyle(color:s.ink,fontSize:d.fontSize*.78,fontWeight:FontWeight.w800)),
                ),
              ]),
            ),
          ])),
          const SizedBox(width:12),
          Expanded(child:sidePanel([
            infoLine('country',d.country),
            infoLine('school','${_label('اسم المدرسة','School')}: ${d.school}'),
            infoLine('directorate','${_label('المرحلة','Stage')}: ${d.directorate}'),
          ])),
        ]),
        const SizedBox(height:10),
        Row(children:[
          if(_v('date')) Expanded(child:Container(padding:const EdgeInsets.symmetric(horizontal:12,vertical:8),decoration:BoxDecoration(color:s.card,borderRadius:BorderRadius.circular(14),border:Border.all(color:s.secondary.withValues(alpha:.55))),child:Text('${_label('التاريخ','Date')}: ${d.date.isEmpty? ' / / ${d.digits(DateTime.now().year)}' : d.digits(d.date)}',textAlign:TextAlign.center,style:TextStyle(fontSize:d.fontSize*.78,fontWeight:FontWeight.w800,color:s.primary)))),
          if(_v('date')) const SizedBox(width:8),
          if(_v('total')) Expanded(child:Container(padding:const EdgeInsets.symmetric(horizontal:12,vertical:8),decoration:BoxDecoration(color:s.card,borderRadius:BorderRadius.circular(14),border:Border.all(color:s.secondary.withValues(alpha:.55))),child:Text('${_label('الدرجة الكلية','Total marks')}: (${d.digits(d.total.toStringAsFixed(d.total==d.total.roundToDouble()?0:1))})',textAlign:TextAlign.center,style:TextStyle(fontSize:d.fontSize*.78,fontWeight:FontWeight.w800,color:s.primary)))),
          if(_v('total')) const SizedBox(width:8),
          Expanded(child:Container(padding:const EdgeInsets.symmetric(horizontal:12,vertical:8),decoration:BoxDecoration(color:s.card,borderRadius:BorderRadius.circular(14),border:Border.all(color:s.secondary.withValues(alpha:.55))),child:Text('${_label('المعلم','Teacher')}: ${d.teacherName.trim().isEmpty ? '........................' : d.digits(d.teacherName)}',textAlign:TextAlign.center,style:TextStyle(fontSize:d.fontSize*.78,fontWeight:FontWeight.w800,color:s.primary)))),
        ]),
      ]);
    }
    bool visible(String name)=>d.headerFields.contains(name);
    Widget line(String key,String text)=>visible(key) ? Text(d.digits(text),style:TextStyle(fontSize:d.fontSize*1.02,fontWeight:FontWeight.w700),textAlign:TextAlign.right) : const SizedBox.shrink();
    return Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        line('country',d.country),line('ministry',d.ministry),line('directorate',d.directorate),line('school',d.school),
      ])),
      Expanded(child:Column(children:[
        if(d.showLogo && d.logoPath!=null && File(d.logoPath!).existsSync()) Image.file(File(d.logoPath!),height:38,fit:BoxFit.contain),
        Text(d.digits(d.bismillah),style:TextStyle(fontSize:d.fontSize*1.02,fontWeight:FontWeight.w700),textAlign:TextAlign.center),
        if(visible('title')) Text(d.digits(d.title),style:TextStyle(fontSize:d.fontSize*1.1,fontWeight:FontWeight.w900),textAlign:TextAlign.center),
        if(visible('academicYear')) Text('${d.paperLanguage=='en'?'Academic year':'للعام الدراسي'} ${d.digits(d.academicYear)}',style:TextStyle(fontSize:d.fontSize*.86,fontWeight:FontWeight.w700),textAlign:TextAlign.center),
      ])),
      Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.end,children:[
        line('subject','${d.paperLanguage=='en'?'Subject':'المادة'}: ${d.subject}'),line('grade','${d.paperLanguage=='en'?'Class':'الصف'}: ${d.grade}'),
        line('total','${d.paperLanguage=='en'?'Marks':'الدرجة الكلية'}: ${d.total.toStringAsFixed(d.total==d.total.roundToDouble()?0:1)}'),
        line('duration','${d.paperLanguage=='en'?'Time':'الوقت'}: ${d.duration}'),line('date','${d.paperLanguage=='en'?'Date':'التاريخ'}: ${d.date}'),
      ])),
    ]);
  }

  Widget _question(PaperQuestion q,int index,TextStyle textStyle){
    final d=document;
    if(_fancyLayout){
      final s=_style;
      final questionTitle=q.customNumber.trim().isNotEmpty ? '${d.digits(q.customNumber)}: ${d.digits(q.text)}' : q.type=='essay' ? questionPrintLabel(d,index,q.text) : '${q.type=='explanation'?'شرح':q.type=='example'?'مثال':'تمرين'} ${d.digits(index)}: ${d.digits(q.text)}';
      return Padding(
        padding:EdgeInsets.only(bottom:PaperPages.questionSpacing(d)),
        child:Container(
          padding:const EdgeInsets.fromLTRB(10,10,10,12),
          decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(16),border:Border.all(color:s.secondary.withValues(alpha:.45))),
          child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
            Row(children:[
              if(d.showGrades) Container(
                padding:const EdgeInsets.symmetric(horizontal:10,vertical:5),
                decoration:BoxDecoration(color:s.soft,borderRadius:BorderRadius.circular(12)),
                child:Text('(${d.digits(q.effectivePoints.toStringAsFixed(q.effectivePoints==q.effectivePoints.roundToDouble()?0:1))} درجة)',style:TextStyle(fontSize:d.fontSize*.72,fontWeight:FontWeight.w900,color:s.primary))),
              const SizedBox(width:8),
              Expanded(child:Container(
                padding:const EdgeInsets.symmetric(horizontal:16,vertical:7),
                decoration:BoxDecoration(color:s.soft,borderRadius:BorderRadius.circular(12)),
                child:Text(d.digits(q.sectionTitle.trim().isNotEmpty?q.sectionTitle:q.text),textAlign:TextAlign.center,style:TextStyle(fontSize:d.fontSize*.9,fontWeight:FontWeight.w900,color:s.ink)),
              )),
              const SizedBox(width:8),
              Container(
                padding:const EdgeInsets.symmetric(horizontal:16,vertical:8),
                decoration:BoxDecoration(gradient:LinearGradient(colors:[s.secondary,s.primary]),borderRadius:BorderRadius.circular(14)),
                child:Text(q.customNumber.trim().isNotEmpty ? d.digits(q.customNumber) : 'السؤال ${d.digits(index)}',style:TextStyle(color:Colors.white,fontSize:d.fontSize*.86,fontWeight:FontWeight.w900)),
              ),
            ]),
            const SizedBox(height:12),
            Text(questionTitle,key:ValueKey('exam-question-$index'),style:textStyle.copyWith(fontWeight:FontWeight.w800,color:s.ink)),
            if(q.requiredBranches>0) Padding(padding:const EdgeInsets.only(top:5),child:Text('أجب عن ${d.digits(q.requiredBranches)} من ${d.digits(q.branches.length)} فروع',style:textStyle.copyWith(fontWeight:FontWeight.w800,fontSize:PaperPages.questionFont(d)*.8,color:s.primary))),
            for(var i=0;i<q.branches.length;i++) ...[
              Padding(padding:const EdgeInsets.only(top:7,right:10),child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
                Expanded(child:Text(branchPrintLabel(d,i+1,q.branches[i]),key:ValueKey('exam-branch-$index-${i+1}'),style:textStyle)),
                if(q.useBranchPoints)Text('(${d.digits(q.effectiveBranchPoints(i))})',style:textStyle.copyWith(fontSize:PaperPages.questionFont(d)*.75,color:s.primary)),
              ])),
              if(i<q.branchSubpoints.length)
                for(var k=0;k<q.branchSubpoints[i].length;k++)
                  if(q.branchSubpoints[i][k].visible) Padding(
                    padding:const EdgeInsets.only(right:26,top:5),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
                      Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
                        Expanded(child:Text('${q.branchSubpoints[i][k].customNumber.trim().isEmpty ? d.digits(k+1) : d.digits(q.branchSubpoints[i][k].customNumber)}- ${d.digits(q.branchSubpoints[i][k].text)}',style:textStyle)),
                        if(d.showGrades)Text('(${d.digits(q.branchSubpoints[i][k].points)})',style:textStyle.copyWith(fontSize:PaperPages.questionFont(d)*.75,color:s.primary)),
                      ]),
                      if(answers && q.branchSubpoints[i][k].answer.trim().isNotEmpty) Text('الإجابة: ${d.digits(q.branchSubpoints[i][k].answer)}',style:textStyle.copyWith(color:s.primary)),
                    ])),
            ],
            for(final e in q.elements) _element(e,textStyle),
            if(d.showRules && q.type=='essay' && q.branches.isEmpty && q.elements.isEmpty) ...List.generate(2,(_)=>Container(margin:const EdgeInsets.only(top:18),decoration:BoxDecoration(border:Border(bottom:BorderSide(color:s.primary.withValues(alpha:.28),width:.7))))),
            if(answers && q.answer.trim().isNotEmpty) Container(margin:const EdgeInsets.only(top:9),padding:const EdgeInsets.all(8),decoration:BoxDecoration(color:s.soft,borderRadius:BorderRadius.circular(10)),child:Text('الإجابة: ${d.digits(q.answer)}',style:textStyle.copyWith(fontSize:d.fontSize*.84,color:s.primary))),
          ]),
        ),
      );
    }
    return Padding(padding:EdgeInsets.only(bottom:PaperPages.questionSpacing(d)),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      if(q.sectionTitle.trim().isNotEmpty) Padding(
        padding:const EdgeInsets.only(bottom:8),
        child:Text(d.digits(q.sectionTitle),textAlign:TextAlign.right,
          style:textStyle.copyWith(color:Color(d.headingColor),fontWeight:FontWeight.w900,decoration:TextDecoration.underline,fontSize:d.fontSize*1.05)),
      ),
      Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Expanded(child:Text(q.customNumber.trim().isNotEmpty ? '${d.digits(q.customNumber)}: ${d.digits(q.text)}' : q.type=='essay' ? questionPrintLabel(d,index,q.text) : '${q.type=='explanation'?'شرح':q.type=='example'?'مثال':'تمرين'} ${d.digits(index)}: ${d.digits(q.text)}',key:ValueKey('exam-question-$index'),style:textStyle.copyWith(fontWeight:FontWeight.w700,color:Color(d.headingColor)))),
        if(d.showGrades) Padding(
          padding:const EdgeInsets.only(right:10,top:2),
          child:Text('(${d.digits(q.effectivePoints.toStringAsFixed(q.effectivePoints==q.effectivePoints.roundToDouble()?0:1))} درجات)',
            style:TextStyle(fontSize:d.fontSize*.76,fontWeight:FontWeight.w700)),
        ),
      ]),
      if(q.requiredBranches>0) Padding(padding:const EdgeInsets.only(bottom:5),child:Text('أجب عن ${d.digits(q.requiredBranches)} من ${d.digits(q.branches.length)} فروع',style:textStyle.copyWith(fontWeight:FontWeight.w800,fontSize:PaperPages.questionFont(d)*.8))),
      for(var i=0;i<q.branches.length;i++) ...[
        Padding(padding:const EdgeInsets.only(top:4,right:12),child:Row(children:[
          Expanded(child:Text(branchPrintLabel(d,i+1,q.branches[i]),
            key:ValueKey('exam-branch-$index-${i+1}'),style:textStyle)),
          if(q.useBranchPoints)Text('(${d.digits(q.effectiveBranchPoints(i))})',
            style:textStyle.copyWith(fontSize:PaperPages.questionFont(d)*.75)),
        ])),
        if(i<q.branchSubpoints.length)
          for(var k=0;k<q.branchSubpoints[i].length;k++)
            if(q.branchSubpoints[i][k].visible) Padding(
              padding:const EdgeInsets.only(right:30,top:5),child:Column(
                crossAxisAlignment:CrossAxisAlignment.stretch,children:[
                  Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
                    Expanded(child:Text('${q.branchSubpoints[i][k].customNumber.trim().isEmpty ? d.digits(k+1) : d.digits(q.branchSubpoints[i][k].customNumber)}- ${d.digits(q.branchSubpoints[i][k].text)}',
                      style:textStyle)),
                    if(d.showGrades)Text('(${d.digits(q.branchSubpoints[i][k].points)})',
                      style:textStyle.copyWith(fontSize:PaperPages.questionFont(d)*.75)),
                  ]),
                  if(answers && q.branchSubpoints[i][k].answer.trim().isNotEmpty)
                    Text('الإجابة: ${d.digits(q.branchSubpoints[i][k].answer)}',
                      style:textStyle.copyWith(color:const Color(0xFF266A50))),
                ])),
      ],
      for(final e in q.elements) _element(e,textStyle),
      if(d.showRules && q.type=='essay' && q.branches.isEmpty && q.elements.isEmpty) ...List.generate(2,(_)=>Container(margin:const EdgeInsets.only(top:20),decoration:const BoxDecoration(border:Border(bottom:BorderSide(color:Color(0xFFB9BEC1),width:.5))))),
      if(answers && q.answer.trim().isNotEmpty) Container(margin:const EdgeInsets.only(top:9),padding:const EdgeInsets.all(8),color:const Color(0xFFF1F7F4),child:Text('الإجابة: ${d.digits(q.answer)}',style:textStyle.copyWith(fontSize:d.fontSize*.84))),
      if(d.questionSeparator == 'line') Padding(padding:const EdgeInsets.only(top:9),child:Divider(color:Color(d.printAccentColor),thickness:.7,height:1)),
      if(d.questionSeparator == 'dots') Padding(padding:const EdgeInsets.only(top:9),child:Text(List.filled(44, '· ').join(),textAlign:TextAlign.center,style:textStyle.copyWith(fontSize:8,color:Color(d.printAccentColor)))),
    ]));
  }

  Widget _element(PaperElement e,TextStyle style){
    final d=document;
    if(e.imagePath!=null && File(e.imagePath!).existsSync()){
      return Padding(padding:const EdgeInsets.symmetric(vertical:7),child:Column(children:[RotatedBox(quarterTurns:e.rotation,child:Image.file(File(e.imagePath!),height:140*e.imageScale,fit:BoxFit.contain,alignment:Alignment.center)),if(e.caption.trim().isNotEmpty) Text(d.digits(e.caption),style:style.copyWith(fontSize:PaperPages.questionFont(d)*.76))]));
    }
    switch(e.kind){
      case 'text':
        return Padding(padding:const EdgeInsets.symmetric(vertical:5),
          child:RichSchoolText(d.digits(e.text),style:style));
      case 'gallery':
        final images=e.galleryImages.where((item)=>File(item.path).existsSync()).toList();
        if(images.isEmpty)return const Text('الصور المرفقة غير موجودة');
        return LayoutBuilder(builder:(context,constraints){
          final cell=(constraints.maxWidth-12)/2;
          return Wrap(spacing:12,runSpacing:12,children:[
            for(final item in images) SizedBox(width:cell,child:Column(children:[
              Image.file(File(item.path),height:115,width:cell,fit:BoxFit.contain),
              if(item.caption.trim().isNotEmpty)Text(d.digits(item.caption),
                textAlign:TextAlign.center,style:style.copyWith(fontSize:PaperPages.questionFont(d)*.8)),
            ])),
          ]);
        });
      case 'poetry':
        return Column(children:[for(final line in e.text.split('\n'))
          if(line.trim().isNotEmpty)Padding(padding:const EdgeInsets.symmetric(vertical:6),
            child:Row(children:[
              Expanded(child:Text(d.digits(line.split('|').first.trim()),textAlign:TextAlign.center,
                style:style.copyWith(fontWeight:FontWeight.bold))),
              const SizedBox(width:12),
              Expanded(child:Text(d.digits(line.contains('|')?line.substring(line.indexOf('|')+1).trim():''),
                textAlign:TextAlign.center,style:style.copyWith(fontWeight:FontWeight.bold))),
            ]))]);
      case 'verse':
        final parts=e.text.split('|');
        return Padding(padding:const EdgeInsets.symmetric(vertical:8),child:Column(children:[
          Text(d.digits(parts.first.trim()),textAlign:TextAlign.center,
            style:style.copyWith(fontWeight:FontWeight.w700)),
          if(parts.length>1)Text(parts.skip(1).join(' — ').trim(),
            textAlign:TextAlign.center,style:style.copyWith(fontSize:PaperPages.questionFont(d)*.8)),
        ]));
      case 'matching':
        final rows=e.text.split('\n').where((line)=>line.trim().isNotEmpty)
          .map((line)=>line.split('|')).toList();
        return Table(border:TableBorder.all(color:Colors.black45,width:.6),children:[
          for(final row in rows)TableRow(children:[
            Padding(padding:const EdgeInsets.all(6),child:Text(d.digits(row.first.trim()),style:style)),
            Padding(padding:const EdgeInsets.all(6),child:Text(d.digits(row.length>1?row[1].trim():''),style:style)),
            if(answers)Padding(padding:const EdgeInsets.all(6),child:
              Text(d.digits(row.length>2?row.skip(2).join(' | ').trim():'—'),style:style)),
          ]),
        ]);
      case 'space':
        final count=int.tryParse(e.text)??3;
        return Column(children:List.generate(count.clamp(1,9).toInt(),(_)=>Container(height:25,decoration:const BoxDecoration(border:Border(bottom:BorderSide(color:Colors.black26))))));
      case 'options':
        return Column(crossAxisAlignment:CrossAxisAlignment.start,children:e.text.split('\n').where((x)=>x.isNotEmpty).map((t)=>Text('□ ${d.digits(t)}',style:style)).toList());
      case 'tf':
        return Text('□ صح    □ خطأ     ${d.digits(e.text)}',style:style);
      case 'table':
        final rows=e.text.split('\n').where((x)=>x.isNotEmpty).map((line)=>line.split('|')).toList();
        if(rows.isEmpty)return const SizedBox.shrink();
        return Table(border:TableBorder.all(color:Colors.black54,width:.5),children:rows.map((row)=>TableRow(children:row.map((cell)=>Padding(padding:const EdgeInsets.all(5),child:Text(d.digits(cell),style:style.copyWith(fontSize:d.fontSize*.8)))).toList())).toList());
      case 'math':case 'chem':
        return Padding(padding:const EdgeInsets.symmetric(vertical:5),child:MathRenderer(d.digits(e.text),fontSize:PaperPages.questionFont(d),color:Color(d.headingColor)));
      case 'geometry':
        return Padding(padding:const EdgeInsets.symmetric(vertical:7),child:GeometryCanvas(figure:GeometryFigure.fromText(e.text),height:160));
      default:return Padding(padding:const EdgeInsets.symmetric(vertical:5),child:Text(d.digits(e.text),style:style));
    }
  }
}



class _ExamVisualStyle {
  const _ExamVisualStyle({required this.primary,required this.secondary,required this.soft,required this.card,required this.ink});
  final Color primary;
  final Color secondary;
  final Color soft;
  final Color card;
  final Color ink;
}

/// Body text always renders at the chosen font size. If it exceeds its allotted
/// height, the page signals an error to the PDF exporter rather than shrinking
/// or silently discarding part of the question.
class _MeasuredQuestionBody extends StatefulWidget {
  const _MeasuredQuestionBody({required this.child,this.onMeasured});
  final Widget child;
  final ValueChanged<bool>? onMeasured;
  @override
  State<_MeasuredQuestionBody> createState()=>_MeasuredQuestionBodyState();
}

class _MeasuredQuestionBodyState extends State<_MeasuredQuestionBody> {
  final _contentKey=GlobalKey();
  @override
  Widget build(BuildContext context)=>LayoutBuilder(builder:(context,bounds){
    WidgetsBinding.instance.addPostFrameCallback((_){
      if(!mounted)return;
      final height=_contentKey.currentContext?.size?.height;
      if(height!=null){widget.onMeasured?.call(height>bounds.maxHeight+.5);}
    });
    return SingleChildScrollView(
      physics:const NeverScrollableScrollPhysics(),
      primary:false,
      child:KeyedSubtree(key:_contentKey,child:widget.child),
    );
  });
}
