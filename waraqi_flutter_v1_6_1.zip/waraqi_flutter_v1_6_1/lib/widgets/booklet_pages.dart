import 'package:flutter/material.dart';
import '../models/paper_document.dart';
import 'paper_pages.dart';

class BookletSectionEntry {
  const BookletSectionEntry(this.title, this.pageNumber);
  final String title;
  final int pageNumber;
}

class BookletPages {
  /// Twenty original combinations: four palettes x five geometric motifs.
  /// No asset from the analyzed third-party applications is copied.
  static (Color, Color) coverPalette(int value) {
    final index=value.clamp(0,19);
    final hue=<double>[174,218,28,276][index~/5];
    final saturation=.43 + (index%5)*.025;
    final accent=HSLColor.fromAHSL(1,hue,saturation,.34).toColor();
    final background=HSLColor.fromAHSL(1,hue,.35,.94).toColor();
    return (accent,background);
  }

  static List<BookletSectionEntry> sections(
    PaperDocument document, List<List<PaperQuestion>> pages, int frontPages,
  ) {
    final seen = <String>{};
    final entries = <BookletSectionEntry>[];
    for (var i = 0; i < pages.length; i++) {
      for (final question in pages[i]) {
        final name = question.sectionTitle.trim();
        if (name.isNotEmpty && seen.add(name)) {
          entries.add(BookletSectionEntry(name, i + frontPages + 1));
        }
      }
    }
    return entries;
  }

  static int tocPageCount(PaperDocument doc) {
    if (!doc.includeToc) return 0;
    final sections = doc.questions.where((q) => q.visible && q.sectionTitle.trim().isNotEmpty)
        .map((q) => q.sectionTitle.trim()).toSet().length;
    return (sections / 18).ceil().clamp(1, 100).toInt();
  }
}

class BookletCoverPage extends StatelessWidget {
  const BookletCoverPage({super.key, required this.document});
  final PaperDocument document;
  @override
  Widget build(BuildContext context) {
    final w=document.landscape?PaperPages.a4Height:PaperPages.a4Width;
    final h=document.landscape?PaperPages.a4Width:PaperPages.a4Height;
    final (accent,background)=BookletPages.coverPalette(document.coverDesign);
    final design=document.coverDesign%5;
    final secondary=accent.withValues(alpha:.10);
    return Container(width:w,height:h,color:background,child:Stack(children:[
      if(design==0) ...[
        Positioned(top:0,right:0,left:0,height:40,child:ColoredBox(color:accent)),
        Positioned(bottom:0,right:0,left:0,height:22,child:ColoredBox(color:accent)),
      ],
      if(design==1) ...[
        Positioned(top:-100,left:-90,width:310,height:310,child:DecoratedBox(
          decoration:BoxDecoration(shape:BoxShape.circle,color:secondary))),
        Positioned(bottom:-80,right:-80,width:240,height:240,child:DecoratedBox(
          decoration:BoxDecoration(shape:BoxShape.circle,color:secondary))),
      ],
      if(design==2) ...[
        Positioned(top:0,right:0,width:28,bottom:0,child:ColoredBox(color:accent)),
        Positioned(top:45,left:45,width:85,height:85,child:DecoratedBox(
          decoration:BoxDecoration(border:Border.all(color:accent,width:5)))),
      ],
      if(design==3) ...[
        Positioned(top:35,left:35,right:35,bottom:35,child:DecoratedBox(
          decoration:BoxDecoration(border:Border.all(color:accent.withValues(alpha:.35),width:2)))),
        Positioned(top:50,left:50,right:50,bottom:50,child:DecoratedBox(
          decoration:BoxDecoration(border:Border.all(color:accent.withValues(alpha:.2),width:1)))),
      ],
      if(design==4) ...[
        Positioned(top:0,right:0,left:0,height:155,child:ColoredBox(color:accent)),
        Positioned(bottom:0,right:0,left:0,height:15,child:ColoredBox(color:accent)),
      ],
      Padding(padding:EdgeInsets.all(document.landscape?40:55),child:Column(children:[
        const SizedBox(height:30),
        Text(document.school,textAlign:TextAlign.center,
          style:TextStyle(fontSize:18,fontWeight:FontWeight.w700,
            color:design==4?Colors.white:accent)),
        const Spacer(),
        Container(width:95,height:8,decoration:BoxDecoration(color:accent,
          borderRadius:BorderRadius.circular(99))),
        const SizedBox(height:25),
        Text(document.title,textAlign:TextAlign.center,
          style:TextStyle(fontSize:36,color:accent,fontWeight:FontWeight.w900)),
        const SizedBox(height:14),
        Text(document.coverSubtitle.isEmpty?document.subject:document.coverSubtitle,
          textAlign:TextAlign.center,style:TextStyle(fontSize:20,color:accent)),
        if(document.bookletIntroduction.trim().isNotEmpty) ...[
          const SizedBox(height:18),
          Text(document.bookletIntroduction,maxLines:8,overflow:TextOverflow.ellipsis,
            textAlign:TextAlign.center,style:const TextStyle(fontSize:15)),
        ],
        const Spacer(),
        Text('إعداد: ${document.teacherName.isEmpty?document.school:document.teacherName}',
          textAlign:TextAlign.center,style:TextStyle(fontSize:17,color:accent,fontWeight:FontWeight.bold)),
        const SizedBox(height:13),
        Text(document.digits(document.academicYear),
          style:TextStyle(fontSize:15,color:accent)),
        const SizedBox(height:16),
      ])),
    ]));
  }
}

class BookletTocPage extends StatelessWidget {
  const BookletTocPage({super.key, required this.document, required this.entries, required this.part, required this.totalParts});
  final PaperDocument document;
  final List<BookletSectionEntry> entries;
  final int part;
  final int totalParts;
  @override
  Widget build(BuildContext context) {
    final w = document.landscape ? PaperPages.a4Height : PaperPages.a4Width;
    final h = document.landscape ? PaperPages.a4Width : PaperPages.a4Height;
    return Container(
      width: w, height: h, color: Colors.white,
      padding: const EdgeInsets.all(55),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text(totalParts > 1 ? 'الفهرس — ${part + 1}' : 'الفهرس', textAlign: TextAlign.center,
          style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Color(document.headingColor))),
        const SizedBox(height: 30),
        for (final entry in entries) Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Row(children: [
            Expanded(child: Text(entry.title, style: const TextStyle(fontSize: 16))),
            Expanded(child: Container(margin: const EdgeInsets.symmetric(horizontal: 9),
              decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: Colors.black26, style: BorderStyle.solid))))),
            Text(document.digits(entry.pageNumber), style: const TextStyle(fontWeight: FontWeight.w800)),
          ]),
        ),
      ]),
    );
  }
}
