import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' show Offset;

import 'package:image/image.dart' as img;

/// Normalized coordinates refer to the original oriented photograph.
/// Points are ordered: top-left, top-right, bottom-right, bottom-left.
/// Keeping the model separate from the UI prevents zooming from changing
/// the actual crop, and makes edge/corner constraints independently testable.
class CropQuad {
  CropQuad._(List<Offset> points) : points = List<Offset>.unmodifiable(points);

  final List<Offset> points;

  factory CropQuad.inset([double margin = .07]) => CropQuad._(<Offset>[
    Offset(margin, margin),
    Offset(1 - margin, margin),
    Offset(1 - margin, 1 - margin),
    Offset(margin, 1 - margin),
  ]);

  factory CropQuad.fromPoints(List<Offset> points) {
    if (points.length != 4) throw ArgumentError('Crop requires four corners');
    final result = CropQuad._(points);
    if (!result.isValid) throw ArgumentError('Crop corners cross or leave photo');
    return result;
  }

  bool get isValid {
    if (points.length != 4) return false;
    for (final point in points) {
      if (!point.dx.isFinite || !point.dy.isFinite ||
          point.dx < 0 || point.dx > 1 || point.dy < 0 || point.dy > 1) {
        return false;
      }
    }
    for (var index = 0; index < 4; index++) {
      final a = points[index];
      final b = points[(index + 1) % 4];
      final c = points[(index + 2) % 4];
      if ((b - a).distance < .035) return false;
      final ab = b - a;
      final bc = c - b;
      final cross = ab.dx * bc.dy - ab.dy * bc.dx;
      if (cross <= .0005) return false;
    }
    return true;
  }

  /// Reject an invalid move; never drag the other three corners with it.
  CropQuad moveCorner(int index, Offset proposed) {
    if (index < 0 || index >= 4) return this;
    final updated = List<Offset>.of(points);
    updated[index] = Offset(proposed.dx.clamp(0, 1).toDouble(),
        proposed.dy.clamp(0, 1).toDouble());
    final next = CropQuad._(updated);
    return next.isValid ? next : this;
  }

  /// Drag just one side, not the whole box; indexes: top/right/bottom/left.
  CropQuad moveEdge(int index, Offset delta) {
    if (index < 0 || index >= 4) return this;
    final updated = List<Offset>.of(points);
    final a = index;
    final b = (index + 1) % 4;
    updated[a] += delta;
    updated[b] += delta;
    final next = CropQuad._(updated);
    return next.isValid ? next : this;
  }

  CropQuad translate(Offset requested) {
    final minX = points.map((p) => p.dx).reduce(math.min);
    final maxX = points.map((p) => p.dx).reduce(math.max);
    final minY = points.map((p) => p.dy).reduce(math.min);
    final maxY = points.map((p) => p.dy).reduce(math.max);
    final dx = requested.dx.clamp(-minX, 1 - maxX).toDouble();
    final dy = requested.dy.clamp(-minY, 1 - maxY).toDouble();
    return CropQuad._(points.map((p) => p + Offset(dx, dy)).toList());
  }

  Offset get center => Offset(
      points.map((p) => p.dx).reduce((a, b) => a + b) / 4,
      points.map((p) => p.dy).reduce((a, b) => a + b) / 4);

  bool get isStraight {
    final p = points;
    return (p[0].dy - p[1].dy).abs() < .0005 &&
        (p[2].dy - p[3].dy).abs() < .0005 &&
        (p[0].dx - p[3].dx).abs() < .0005 &&
        (p[1].dx - p[2].dx).abs() < .0005;
  }
}

class OcrCropService {
  /// Legacy axis-aligned cropping remains compatible with old tests and uses.
  static img.Image crop(
    img.Image source, {
    required double centerX,
    required double centerY,
    required double widthFraction,
    required double heightFraction,
  }) {
    final width = math.max(1, (source.width * widthFraction.clamp(0.01, 1.0)).round());
    final height = math.max(1, (source.height * heightFraction.clamp(0.01, 1.0)).round());
    final centerPixelX = (centerX.clamp(0.0, 1.0) * source.width).round();
    final centerPixelY = (centerY.clamp(0.0, 1.0) * source.height).round();
    final left = (centerPixelX - width ~/ 2).clamp(0, source.width - width).toInt();
    final top = (centerPixelY - height ~/ 2).clamp(0, source.height - height).toInt();
    return img.copyCrop(source, x: left, y: top, width: width, height: height);
  }

  /// Fast exact rectangle or four-corner rectification using the full original
  /// pixels. The output is dimension-limited for mobile memory and OCR speed.
  static img.Image cropQuadrilateral(img.Image source, CropQuad quad,
      {int maxDimension = 2400}) {
    if (!quad.isValid) throw ArgumentError('Invalid crop selection');
    final p = quad.points;
    final width = source.width.toDouble();
    final height = source.height.toDouble();
    double length(Offset a, Offset b) =>
        math.sqrt(math.pow((a.dx - b.dx) * width, 2) +
                  math.pow((a.dy - b.dy) * height, 2));
    final targetWidth = math.max(2, ((length(p[0], p[1]) + length(p[3], p[2])) / 2).round());
    final targetHeight = math.max(2, ((length(p[0], p[3]) + length(p[1], p[2])) / 2).round());
    final factor = math.min(1.0, maxDimension / math.max(targetWidth, targetHeight));
    final outputWidth = math.max(2, (targetWidth * factor).round());
    final outputHeight = math.max(2, (targetHeight * factor).round());

    if (quad.isStraight) {
      final x = (p[0].dx * source.width).round().clamp(0, source.width - 1).toInt();
      final y = (p[0].dy * source.height).round().clamp(0, source.height - 1).toInt();
      final right = (p[2].dx * source.width).round().clamp(x + 1, source.width).toInt();
      final bottom = (p[2].dy * source.height).round().clamp(y + 1, source.height).toInt();
      final exact = img.copyCrop(source, x: x, y: y,
          width: right - x, height: bottom - y);
      return exact.width > maxDimension || exact.height > maxDimension
          ? img.copyResize(exact, width: outputWidth, height: outputHeight,
              interpolation: img.Interpolation.linear)
          : exact;
    }

    img.Point pixel(Offset point) => img.Point(
        point.dx * (source.width - 1), point.dy * (source.height - 1));
    return img.copyRectify(
      source,
      topLeft: pixel(p[0]),
      topRight: pixel(p[1]),
      bottomRight: pixel(p[2]),
      bottomLeft: pixel(p[3]),
      interpolation: img.Interpolation.linear,
      toImage: img.Image(width: outputWidth, height: outputHeight),
    );
  }

  /// Creates the smaller interactive preview outside the UI isolate. The
  /// original bytes are retained untouched for the eventual OCR crop.
  static Map<String, Object> previewEncoded(Uint8List bytes) {
    final decoded = img.decodeImage(bytes);
    if (decoded == null) throw StateError('Could not decode photograph');
    final oriented = img.bakeOrientation(decoded);
    final longest = math.max(oriented.width, oriented.height);
    final factor = math.min(1.0, 1400 / longest);
    final preview = factor < 1
        ? img.copyResize(oriented,
            width: math.max(1, (oriented.width * factor).round()),
            height: math.max(1, (oriented.height * factor).round()))
        : oriented;
    return <String, Object>{
      'width': oriented.width,
      'height': oriented.height,
      'jpeg': Uint8List.fromList(img.encodeJpg(preview, quality: 88)),
    };
  }

  /// Sent to a background isolate via compute() so the crop operation cannot
  /// freeze the controls while a large photograph is processed.
  static Uint8List cropEncoded(Map<String, Object> message) {
    final bytes = message['bytes']! as Uint8List;
    final values = message['points']! as List<double>;
    final decoded = img.decodeImage(bytes);
    if (decoded == null) throw StateError('Could not decode original photograph');
    final oriented = img.bakeOrientation(decoded);
    final quad = CropQuad.fromPoints(List<Offset>.generate(4,
        (i) => Offset(values[i * 2], values[i * 2 + 1])));
    final cropped = cropQuadrilateral(oriented, quad);
    return Uint8List.fromList(img.encodeJpg(cropped, quality: 92));
  }

  static Uint8List rotateEncoded(Uint8List bytes) {
    final decoded = img.decodeImage(bytes);
    if (decoded == null) throw StateError('Could not decode photograph');
    final rotated = img.copyRotate(img.bakeOrientation(decoded), angle: 90);
    return Uint8List.fromList(img.encodeJpg(rotated, quality: 94));
  }
}
