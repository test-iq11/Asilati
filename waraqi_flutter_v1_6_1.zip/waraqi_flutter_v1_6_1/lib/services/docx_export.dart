import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:archive/archive.dart';
import 'package:image/image.dart' as img;
import '../models/paper_document.dart';
import '../widgets/geometry_editor.dart';
import '../widgets/paper_pages.dart';
import '../widgets/booklet_pages.dart';

/// Creates an editable OOXML .docx document, not renamed HTML.
/// It deliberately uses a small supported WordprocessingML subset.
class DocxExport {
  static const _ns = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
  static const _rels = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
  static const _dml = 'http://schemas.openxmlformats.org/drawingml/2006/main';
  static const _wp = 'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing';
  static const _pic = 'http://schemas.openxmlformats.org/drawingml/2006/picture';
  static const _pkgRel = 'http://schemas.openxmlformats.org/package/2006/relationships';
  static const _ct = 'http://schemas.openxmlformats.org/package/2006/content-types';

  static Future<Uint8List> generate(PaperDocument document, {required bool answers}) async {
    final d = document;
    final baseSize=(PaperPages.questionFont(d)*2).round().clamp(20,46).toInt();
    final files = <String, Uint8List>{};
    final content = StringBuffer();
    final relationships = <String>[];
    var mediaIndex = 0;
    final pages = PaperPages.paginate(d, answers: answers);
    final frontCount = (d.documentType == 'booklet' && d.includeCover ? 1 : 0)
        + (d.documentType == 'booklet' ? BookletPages.tocPageCount(d) : 0);

    if (d.documentType == 'booklet' && d.includeCover) {
      final coverAccent=BookletPages.coverPalette(d.coverDesign).$1.toARGB32();
      content.write(_paragraph(d.school, size: 24, align: 'center'));
      content.write(_paragraph(d.title, size: 44, bold: true, align: 'center', color: _hex(coverAccent)));
      content.write(_paragraph(d.coverSubtitle.isEmpty ? d.subject : d.coverSubtitle, size: 27, align: 'center'));
      if (d.bookletIntroduction.trim().isNotEmpty) {
        content.write(_paragraph(d.bookletIntroduction, size: 23, align: 'center'));
      }
      content.write(_paragraph('إعداد: ${d.teacherName}\n${d.academicYear}', size: 23, align: 'center'));
      content.write(_pageBreak());
    }
    if (d.documentType == 'booklet' && d.includeToc) {
      final sections = BookletPages.sections(d, pages, frontCount);
      final tocPages = math.max(1, (sections.length / 18).ceil());
      for (var i = 0; i < tocPages; i++) {
        content.write(_paragraph('فهرس الملزمة', size: 33, bold: true, align: 'center', color: _hex(d.headingColor)));
        for (final entry in sections.skip(i * 18).take(18)) {
          content.write(_paragraph('${entry.title}  ................................  ${d.digits(entry.pageNumber)}', size: 23));
        }
        content.write(_pageBreak());
      }
    }

    content.write(_paragraph(d.bismillah, size: 22, align: 'center'));
    content.write(_paragraph(d.country, size: 21));
    content.write(_paragraph(d.ministry, size: 21));
    content.write(_paragraph(d.directorate, size: 21));
    content.write(_paragraph(d.school, size: 21));
    content.write(_paragraph(d.title, size: 30, bold: true, align: 'center', color: _hex(d.headingColor)));
    content.write(_paragraph('${d.paperLanguage=='en'?'Subject':'المادة'}: ${d.subject} — ${d.paperLanguage=='en'?'Class':'الصف'}: ${d.grade} — ${d.academicYear}', size: 21, align: 'center'));
    if (d.showStudentNameField) content.write(_paragraph(d.paperLanguage=='en'?'Student name: _________________________':'اسم الطالب: _________________________', size: 19));
    if (d.showSectionField) content.write(_paragraph(d.paperLanguage=='en'?'Class/Section: _________________________':'الصف/الشعبة: _________________________', size: 19));
    if (d.topNote.trim().isNotEmpty) content.write(_paragraph(d.topNote, size: 24, align: 'center', bold: true));
    if (d.requiredQuestions > 0) content.write(_paragraph('أجب عن ${d.digits(d.requiredQuestions)} من ${d.digits(d.questions.where((q)=>q.visible).length)} أسئلة',size:24,align:'center',bold:true));

    var printed = 0;
    for (final q in d.questions.where((element) => element.visible)) {
      printed++;
      if (q.pageBreakBefore && printed > 1) content.write(_pageBreak());
      if (q.sectionTitle.trim().isNotEmpty) {
        content.write(_paragraph(q.sectionTitle, size: 27, bold: true, color: _hex(d.headingColor)));
      }
      final label = q.customNumber.trim().isEmpty
          ? questionPrintLabel(d, printed, q.text)
          : '${q.customNumber}: ${q.text}';
      content.write(_paragraph('$label${d.showGrades ? '  (${d.digits(q.effectivePoints)} درجات)' : ''}', size: baseSize, bold: true,
        color: _hex(d.headingColor), keepNext: true));
      if (q.requiredBranches > 0) {
        content.write(_paragraph('أجب عن ${d.digits(q.requiredBranches)} من ${d.digits(q.branches.length)} فروع', size: 20, bold: true));
      }
      for (var i = 0; i < q.branches.length; i++) {
        final grade = q.useBranchPoints ? ' (${d.digits(q.effectiveBranchPoints(i))} درجة)' : '';
        content.write(_paragraph('${branchPrintLabel(d, i + 1, q.branches[i])}$grade', size: baseSize));
        if (i < q.branchSubpoints.length) {
          var pointNumber = 0;
          for (final point in q.branchSubpoints[i].where((p) => p.visible)) {
            pointNumber++;
            final number = point.customNumber.trim().isNotEmpty
                ? point.customNumber : d.digits(pointNumber);
            content.write(_paragraph('$number- ${point.text}${d.showGrades ? ' (${d.digits(point.points)} درجة)' : ''}', size: baseSize));
            if (answers && point.answer.trim().isNotEmpty) {
              content.write(_paragraph('الإجابة: ${point.answer}', size: 20, color: '255D43'));
            }
          }
        }
      }
      for (final e in q.elements) {
        if (e.kind == 'gallery' && e.galleryImages.isNotEmpty) {
          content.write('<w:tbl><w:tblPr><w:tblBorders><w:insideV w:val="nil"/><w:insideH w:val="nil"/></w:tblBorders></w:tblPr>');
          for (var start = 0; start < e.galleryImages.length; start += 2) {
            content.write('<w:tr>');
            for (final image in e.galleryImages.skip(start).take(2)) {
              content.write('<w:tc>');
              if (await File(image.path).exists()) {
                final raw = await File(image.path).readAsBytes();
                final rotated = await _rasterImage(raw, 0);
                final relId = 'rId${10 + mediaIndex}';
                mediaIndex++;
                files['word/media/image$mediaIndex.png'] = rotated;
                relationships.add('<Relationship Id="$relId" Type="$_rels/image" Target="media/image$mediaIndex.png"/>');
                content.write(_image(relId, mediaIndex, rotated, .48));
              } else {
                content.write(_paragraph('صورة غير متاحة', size: 18));
              }
              if (image.caption.trim().isNotEmpty) content.write(_paragraph(image.caption, size: 17, align: 'center'));
              content.write('</w:tc>');
            }
            if (e.galleryImages.length - start == 1) content.write('<w:tc><w:p/></w:tc>');
            content.write('</w:tr>');
          }
          content.write('</w:tbl>');
          continue;
        }
        if (e.imagePath != null && File(e.imagePath!).existsSync()) {
          final raw = await File(e.imagePath!).readAsBytes();
          final rotated = await _rasterImage(raw, e.rotation);
          final relId = 'rId${10 + mediaIndex}';
          mediaIndex++;
          final path = 'word/media/image$mediaIndex.png';
          files[path] = rotated;
          relationships.add('<Relationship Id="$relId" Type="$_rels/image" Target="media/image$mediaIndex.png"/>');
          content.write(_image(relId, mediaIndex, rotated, e.imageScale));
          if (e.caption.trim().isNotEmpty) content.write(_paragraph(e.caption, size: 19, align: 'center'));
          continue;
        }
        if (e.kind == 'geometry') {
          final drawing = _renderGeometry(GeometryFigure.fromText(e.text));
          final relId = 'rId${10 + mediaIndex}';
          mediaIndex++;
          files['word/media/image$mediaIndex.png'] = drawing;
          relationships.add('<Relationship Id="$relId" Type="$_rels/image" Target="media/image$mediaIndex.png"/>');
          content.write(_image(relId, mediaIndex, drawing, .8));
          continue;
        }
        if (e.kind == 'table') {
          final rows = e.text.split('\n').where((s) => s.trim().isNotEmpty).map((s) => s.split('|')).toList();
          if (rows.isNotEmpty) content.write(_table(rows));
        } else if (e.kind == 'space') {
          final count = (int.tryParse(e.text) ?? 3).clamp(1, 9);
          for (var i = 0; i < count; i++) {content.write(_paragraph('________________________________________________', size: 18));}
        } else if (e.kind == 'math' || e.kind == 'chem') {
          content.write(_mathParagraph(e.text));
        } else if (e.kind == 'text') {
          content.write(_richParagraph(e.text, size: baseSize));
        } else if (e.kind == 'poetry') {
          for (final line in e.text.split('\n')) {
            if (line.trim().isEmpty) continue;
            final halves=line.split('|');
            final left=halves.first.trim();
            final right=halves.length>1?halves.skip(1).join(' | ').trim():'';
            content.write(_table([[left,right]]));
          }
        } else if (e.kind == 'verse') {
          final parts=e.text.split('|');
          content.write(_paragraph(parts.first.trim(),size:baseSize,bold:true,align:'center'));
          if(parts.length>1)content.write(_paragraph(parts.skip(1).join(' — ').trim(),size:20,align:'center'));
        } else if (e.kind == 'matching') {
          final rows=e.text.split('\n').where((line)=>line.trim().isNotEmpty)
            .map((line)=>line.split('|')).map((cells)=>[
              cells.first.trim(),cells.length>1?cells[1].trim():'',
              if(answers)cells.length>2?cells.skip(2).join(' | ').trim():'—',
            ]).toList();
          if(rows.isNotEmpty)content.write(_table(rows));
        } else if (e.kind == 'options') {
          for (final option in e.text.split('\n')) {
            if (option.trim().isNotEmpty) content.write(_paragraph('□ $option', size: 22));
          }
        } else {
          content.write(_paragraph(e.kind == 'tf' ? '□ صح   □ خطأ   ${e.text}' : e.text, size: 22));
        }
      }
      if (answers && q.answer.trim().isNotEmpty) {
        content.write(_paragraph('الإجابة: ${q.answer}', size: 21, color: '255D43'));
      }
      if (d.questionSeparator == 'line') content.write(_paragraph('__________________________________________', size: 16, color: _hex(d.printAccentColor)));
      if (d.questionSeparator == 'dots') content.write(_paragraph(List.filled(35, '· ').join(), size: 15, color: _hex(d.printAccentColor)));
    }
    if (d.teacherName.trim().isNotEmpty) {
      content.write(_paragraph('معلم المادة: ${d.teacherName}${d.teacherRole.isEmpty ? '' : ' — ${d.teacherRole}'}', size: 24, bold: true,
        align: d.signatureSide == 'right' ? 'right' : 'left'));
    }
    if (d.showSignatureLine) content.write(_paragraph('التوقيع: __________________________', size: 23,
      align: d.signatureSide == 'right' ? 'right' : 'left'));
    final signatures=d.signatures.where((sign)=>sign.name.trim().isNotEmpty).toList();
    for(var start=0;start<signatures.length;start+=4){
      final row=signatures.skip(start).take(4).map((sign){
        final description=sign.role.trim().isEmpty?sign.name:'${sign.name} — ${sign.role}';
        return d.showSignatureLine?'$description\nالتوقيع: _________':description;
      }).toList();
      content.write(_table(row.isEmpty?[]:[row]));
    }
    if (d.showFooter && d.footerText.trim().isNotEmpty) content.write(_paragraph(d.footerText, size: 23, align: 'center'));

    final w = d.landscape ? 16838 : 11906;
    final h = d.landscape ? 11906 : 16838;
    int margin(double mm) => (mm * 56.69).round().clamp(0, 2551).toInt();
    final xml = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="$_ns" xmlns:r="$_rels" xmlns:wp="$_wp" xmlns:a="$_dml" xmlns:pic="$_pic" xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math">
<w:body>$content<w:sectPr><w:pgSz w:w="$w" w:h="$h"${d.landscape ? ' w:orient="landscape"' : ''}/>
<w:pgMar w:top="${margin(d.topMarginMm)}" w:bottom="${margin(d.bottomMarginMm)}" w:left="${margin(d.sideMarginMm)}" w:right="${margin(d.sideMarginMm)}" w:header="500" w:footer="500" w:gutter="0"/></w:sectPr></w:body></w:document>''';
    final archive = Archive();
    void add(String name, String xml) {
      final bytes = Uint8List.fromList(utf8.encode(xml));
      archive.addFile(ArchiveFile(name, bytes.length, bytes));
    }
    add('[Content_Types].xml', '''<?xml version="1.0" encoding="UTF-8"?>
<Types xmlns="$_ct"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Default Extension="png" ContentType="image/png"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>''');
    add('_rels/.rels', '''<?xml version="1.0" encoding="UTF-8"?>
<Relationships xmlns="$_pkgRel"><Relationship Id="rId1" Type="$_rels/officeDocument" Target="word/document.xml"/></Relationships>''');
    add('word/_rels/document.xml.rels', '''<?xml version="1.0" encoding="UTF-8"?>
<Relationships xmlns="$_pkgRel"><Relationship Id="rId1" Type="$_rels/styles" Target="styles.xml"/>${relationships.join()}</Relationships>''');
    final wordFont=d.paperFontFamily=='serif'?'Times New Roman':'Arial';
    add('word/styles.xml', '''<?xml version="1.0" encoding="UTF-8"?>
<w:styles xmlns:w="$_ns"><w:style w:type="paragraph" w:styleId="Normal" w:default="1"><w:name w:val="Normal"/>
<w:rPr><w:rFonts w:ascii="$wordFont" w:hAnsi="$wordFont" w:cs="$wordFont"/></w:rPr></w:style></w:styles>''');
    add('word/document.xml', xml);
    for (final entry in files.entries) {
      archive.addFile(ArchiveFile(entry.key, entry.value.length, entry.value));
    }
    return Uint8List.fromList(ZipEncoder().encode(archive));
  }

  static String _escape(String value) => value.replaceAll('&', '&amp;').replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&apos;');
  static String _hex(int value) => (value & 0xFFFFFF).toRadixString(16).padLeft(6, '0').toUpperCase();
  static String _paragraph(String raw, {int size = 22, bool bold = false, String color = '171717',
    String align = 'right', bool keepNext = false}) {
    final parts = raw.split('\n').map((line) => '<w:t xml:space="preserve">${_escape(line)}</w:t>').join('<w:br/>');
    return '<w:p><w:pPr><w:bidi w:val="1"/><w:jc w:val="$align"/><w:spacing w:after="130"/>'
      '${keepNext ? '<w:keepNext/>' : ''}</w:pPr><w:r><w:rPr>${bold ? '<w:b/>' : ''}'
      '<w:color w:val="$color"/><w:sz w:val="$size"/><w:szCs w:val="$size"/>'
      '<w:rtl w:val="1"/></w:rPr>$parts</w:r></w:p>';
  }
  static String _richParagraph(String source,{int size=22}) {
    final token=RegExp(r'(\*\*(.*?)\*\*|__(.*?)__|~~(.*?)~~)',dotAll:true);
    final parts=StringBuffer();
    var start=0;
    void run(String value,{bool bold=false,bool underline=false,bool strike=false}){
      if(value.isEmpty)return;
      parts.write('<w:r><w:rPr><w:sz w:val="$size"/><w:szCs w:val="$size"/>'
        '${bold?'<w:b/>':''}${underline?'<w:u w:val="single"/>':''}'
        '${strike?'<w:strike/>':''}<w:rtl/></w:rPr>'
        '<w:t xml:space="preserve">${_escape(value)}</w:t></w:r>');
    }
    for(final item in token.allMatches(source)){
      if(item.start>start)run(source.substring(start,item.start));
      if(item.group(2)!=null)run(item.group(2)!,bold:true);
      else if(item.group(3)!=null)run(item.group(3)!,underline:true);
      else if(item.group(4)!=null)run(item.group(4)!,strike:true);
      start=item.end;
    }
    if(start<source.length)run(source.substring(start));
    return '<w:p><w:pPr><w:bidi w:val="1"/><w:jc w:val="right"/></w:pPr>$parts</w:p>';
  }

  static String _pageBreak() => '<w:p><w:r><w:br w:type="page"/></w:r></w:p>';
  static String _table(List<List<String>> rows) {
    final out = StringBuffer('<w:tbl><w:tblPr><w:tblBorders>');
    for (final side in ['top', 'left', 'bottom', 'right', 'insideH', 'insideV']) {
      out.write('<w:$side w:val="single" w:sz="6"/>');
    }
    out.write('</w:tblBorders></w:tblPr>');
    for (final row in rows) {
      out.write('<w:tr>');
      for (final cell in row) {
        out.write('<w:tc><w:tcPr><w:tcW w:w="1800" w:type="dxa"/></w:tcPr>');
        out.write(_paragraph(cell, size: 21, align: 'center'));
        out.write('</w:tc>');
      }
      out.write('</w:tr>');
    }
    out.write('</w:tbl>');
    return out.toString();
  }
  static String _image(String relation, int id, Uint8List bytes, double scale) {
    final info = img.decodeImage(bytes);
    final width = info?.width ?? 500;
    final height = info?.height ?? 250;
    final cx = (4300000 * scale).round();
    final cy = (cx * height / width).round().clamp(120000, 4800000);
    return '''<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:drawing>
<wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="$cx" cy="$cy"/>
<wp:docPr id="$id" name="Picture $id"/>
<a:graphic xmlns:a="$_dml"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
<pic:pic xmlns:pic="$_pic"><pic:nvPicPr><pic:cNvPr id="$id" name="Picture $id"/><pic:cNvPicPr/></pic:nvPicPr>
<pic:blipFill><a:blip r:embed="$relation"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>
<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="$cx" cy="$cy"/></a:xfrm>
<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic>
</a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>''';
  }
  static Future<Uint8List> _rasterImage(Uint8List bytes, int rotation) async {
    final source = img.decodeImage(bytes);
    if (source == null) return bytes;
    final rotated = rotation == 0 ? source : img.copyRotate(source, angle: (rotation % 4) * 90);
    return Uint8List.fromList(img.encodePng(rotated));
  }
  static Uint8List _renderGeometry(GeometryFigure figure) {
    final image = img.Image(width: 480, height: 260);
    img.fill(image, color: img.ColorRgb8(255, 255, 255));
    final coords = figure.points.map((p) => (x: (p.dx*480).round(), y: (p.dy*260).round())).toList();
    final pen = img.ColorRgb8(23, 51, 61);
    void line(int a, int b) {
      img.drawLine(image, x1: coords[a].x, y1: coords[a].y,
        x2: coords[b].x, y2: coords[b].y, color: pen, thickness: 3);
    }
    if(coords.length >= 2) {
      if(figure.type == 'circle') {
        final dx=coords[1].x-coords[0].x;
        final dy=coords[1].y-coords[0].y;
        img.drawCircle(image,x:coords[0].x,y:coords[0].y,
          radius:math.sqrt(dx*dx+dy*dy).round(),color:pen);
      } else if(figure.type == 'rectangle') {
        img.drawRect(image,x1:coords[0].x,y1:coords[0].y,
          x2:coords[1].x,y2:coords[1].y,color:pen,thickness:3);
      } else {
        line(0,1);
        if(figure.type == 'triangle' && coords.length > 2){line(1,2);line(2,0);}
        if(figure.type == 'angle' && coords.length > 2){line(1,2);}
        if(figure.type == 'axes' && coords.length > 3){line(2,3);}
        if(figure.type == 'inclined' && coords.length > 2){line(1,2);line(2,0);}
        if(figure.type == 'force'){
          final dx=(coords[1].x-coords[0].x).toDouble();
          final dy=(coords[1].y-coords[0].y).toDouble();
          final angle=math.atan2(dy,dx);
          for(final sign in [-1.0,1.0]){
            final x=coords[1].x-(17*math.cos(angle+sign*.5)).round();
            final y=coords[1].y-(17*math.sin(angle+sign*.5)).round();
            img.drawLine(image,x1:coords[1].x,y1:coords[1].y,x2:x,y2:y,
              color:pen,thickness:3);
          }
        }
      }
    }
    return Uint8List.fromList(img.encodePng(image));
  }
  /// OMML nodes keep common fractions, roots and exponents as editable Word equations.
  static String _mathParagraph(String source) {
    final pattern = RegExp(r'\\frac\{([^{}]+)\}\{([^{}]+)\}|\\sqrt\{([^{}]+)\}|([A-Za-z0-9]+)\^\{([^{}]+)\}');
    if (!pattern.hasMatch(source)) return _paragraph(_mathFallback(source), size: 25, align: 'center', bold: true);
    final result = StringBuffer('<w:p><w:pPr><w:jc w:val="center"/></w:pPr><m:oMathPara><m:oMath>');
    String run(String text) => '<m:r><m:t xml:space="preserve">${_escape(text)}</m:t></m:r>';
    var start = 0;
    for (final match in pattern.allMatches(source)) {
      if (match.start > start) result.write(run(source.substring(start, match.start)));
      if (match.group(1) != null) {
        result.write('<m:f><m:fPr><m:type m:val="bar"/></m:fPr><m:num>${run(match.group(1)!)}</m:num><m:den>${run(match.group(2)!)}</m:den></m:f>');
      } else if (match.group(3) != null) {
        result.write('<m:rad><m:radPr><m:degHide m:val="1"/></m:radPr><m:deg/><m:e>${run(match.group(3)!)}</m:e></m:rad>');
      } else {
        result.write('<m:sSup><m:e>${run(match.group(4)!)}</m:e><m:sup>${run(match.group(5)!)}</m:sup></m:sSup>');
      }
      start = match.end;
    }
    if (start < source.length) result.write(run(source.substring(start)));
    result.write('</m:oMath></m:oMathPara></w:p>');
    return result.toString();
  }
  static String _mathFallback(String text) => text
    .replaceAllMapped(RegExp(r'\\frac\{([^{}]+)\}\{([^{}]+)\}'), (m) => '(${m[1]}) / (${m[2]})')
    .replaceAllMapped(RegExp(r'\\sqrt\{([^{}]+)\}'), (m) => '√(${m[1]})')
    .replaceAllMapped(RegExp(r'\^\{([^{}]+)\}'), (m) => '^${m[1]}');
}

