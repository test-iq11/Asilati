import 'dart:async';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/paper_document.dart';

class PaperStorage {
  static const key = 'waraqi_flutter_document_v1';
  Timer? _timer;
  Future<PaperDocument> load() async {
    final prefs = await SharedPreferences.getInstance();
    final source = prefs.getString(key);
    if (source == null) return PaperDocument();
    try { return PaperDocument.decode(source); } catch (_) { return PaperDocument(); }
  }
  void queueSave(PaperDocument doc) {
    _timer?.cancel();
    final serialized = doc.encode();
    _timer = Timer(const Duration(milliseconds: 500), () async {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(key, serialized);
    });
  }
  Future<void> saveNow(PaperDocument doc) async {
    _timer?.cancel();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(key, doc.encode());
  }
  Future<String> saveImage(List<int> bytes) async {
    final base = await getApplicationDocumentsDirectory();
    final dir = Directory('${base.path}/paper_images');
    if (!await dir.exists()) await dir.create(recursive: true);
    final file = File('${dir.path}/${newId()}.jpg');
    await file.writeAsBytes(bytes, flush: true);
    return file.path;
  }
  void dispose() { _timer?.cancel(); }
}
