import 'dart:typed_data';
import 'dart:math' as math;

import 'package:image/image.dart' as img;

/// Image preparation and conservative text clean-up. This does not reconstruct
/// numbers or reorder words based on guesses: OCR is always user-reviewed.
class OcrTextTools {
  static Uint8List prepareForOcr(List<int> cropped) {
    final decoded = img.decodeImage(Uint8List.fromList(cropped));
    if (decoded == null) throw StateError('تعذّر قراءة الصورة المقصوصة');
    // Tesseract works best with reasonably sized dark text on a light background.
    // Avoid hard thresholding; it can erase thin Arabic dots and Eastern digits.
    // A low-resolution crop should not be inflated to 1500 pixels at any
    // cost: extreme enlargement magnifies JPEG block artifacts into glyphs.
    final scale = math.min(2.5, math.max(1.0, 1500.0 / decoded.width));
    final targetWidth = (decoded.width * scale).round();
    final resized = targetWidth > decoded.width
        ? img.copyResize(decoded, width: targetWidth)
        : decoded;
    final gray = img.grayscale(resized);
    final enhanced = img.adjustColor(gray, contrast: 1.12);
    return Uint8List.fromList(img.encodePng(enhanced));
  }

  static String clean(String raw, {required bool arabicOnly}) {
    var cleaned = raw.replaceAll('\r\n', '\n').replaceAll('\r', '\n');
    cleaned = cleaned.replaceAll(RegExp(r'[\u200e\u200f\uFEFF]'), '');
    // In Arabic-only mode remove English *words* that commonly arise from
    // bilingual OCR hallucinations. Keep single Latin maths symbols (x, y),
    // ASCII digits, and all Arabic/Persian/Western digit forms unchanged.
    if (arabicOnly) {
      cleaned = cleaned.replaceAll(RegExp(r'[A-Za-z]{2,}'), '');
    }
    final lines = cleaned.split('\n').map((line) =>
      line.replaceAll(RegExp(r'[ \t]{2,}'), ' ').trim());
    return lines.join('\n').replaceAll(RegExp(r'\n{3,}'), '\n\n').trim();
  }

  static bool hasLatinWords(String raw) =>
      RegExp(r'[A-Za-z]{2,}').hasMatch(raw);

  static bool hasDigits(String raw) =>
      RegExp(r'[0-9٠-٩۰-۹]').hasMatch(raw);
}
