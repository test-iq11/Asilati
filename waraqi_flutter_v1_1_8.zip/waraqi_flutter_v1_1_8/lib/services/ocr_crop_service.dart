import 'dart:math' as math;
import 'package:image/image.dart' as img;

/// Crop in original image coordinates (not camera-preview coordinates).
/// The selection is normalized to the full captured photograph, so portrait
/// framing, letterboxing and image orientations cannot shift the OCR region.
class OcrCropService {
  static img.Image crop(
    img.Image source, {
    required double centerX,
    required double centerY,
    required double widthFraction,
    required double heightFraction,
  }) {
    final width = math.max(1, (source.width * widthFraction.clamp(0.01, 1.0)).round());
    final height = math.max(1, (source.height * heightFraction.clamp(0.01, 1.0)).round());
    final centerPixelX = (centerX.clamp(0.0, 1.0) * source.width).round();
    final centerPixelY = (centerY.clamp(0.0, 1.0) * source.height).round();
    final left = (centerPixelX - width ~/ 2).clamp(0, source.width - width).toInt();
    final top = (centerPixelY - height ~/ 2).clamp(0, source.height - height).toInt();
    return img.copyCrop(source, x: left, y: top, width: width, height: height);
  }
}
