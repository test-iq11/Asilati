import 'dart:convert';

/// Single source of truth for Arabic and Latin digits in editor, preview and print.
enum DigitStyle { arabic, english }

String formatDigits(Object? value, DigitStyle style) {
  final raw = '$value';
  const western = '0123456789';
  const eastern = '٠١٢٣٤٥٦٧٨٩';
  const persian = '۰۱۲۳۴۵۶۷۸۹';
  final target = style == DigitStyle.arabic ? eastern : western;
  return raw.split('').map((character) {
    var index = western.indexOf(character);
    if (index < 0) index = eastern.indexOf(character);
    if (index < 0) index = persian.indexOf(character);
    return index < 0 ? character : target[index];
  }).join();
}

/// Accept numeric input from both Arabic and English phone keyboards.
/// Discard non-finite numbers; they cannot be serialized safely as JSON.
double? parseLocalizedNumber(Object? value) {
  if(value==null) return null;
  final text = formatDigits(value, DigitStyle.english)
      .replaceAll('٫', '.')
      .replaceAll('٬', '')
      .trim();
  final result = double.tryParse(text);
  return result != null && result.isFinite ? result : null;
}

String newId() => DateTime.now().microsecondsSinceEpoch.toString();

class PaperElement {
  PaperElement({required this.id, required this.kind, this.text = '', this.imagePath});
  final String id;
  String kind;
  String text;
  String? imagePath;
  Map<String, dynamic> toJson() => {'id': id, 'kind': kind, 'text': text, 'imagePath': imagePath};
  factory PaperElement.fromJson(Map<String, dynamic> map) => PaperElement(
        id: map['id']?.toString() ?? newId(),
        kind: map['kind']?.toString() ?? 'text',
        text: map['text']?.toString() ?? '',
        imagePath: map['imagePath']?.toString(),
      );
}

class PaperQuestion {
  PaperQuestion({required this.id, this.text = '', this.points = 5, this.answer = '', this.visible = true, this.type = 'essay', this.sectionTitle = '', List<String>? branches, List<PaperElement>? elements})
      : branches = branches ?? [],
        elements = elements ?? [];
  final String id;
  String text;
  double points;
  String answer;
  bool visible;
  String type;
  String sectionTitle;
  final List<String> branches;
  final List<PaperElement> elements;

  /// OCR contributes editable text only; the photographed image is NOT added
  /// as an element. An empty recognition result never clears existing text.
  bool insertExtractedText(String recognized, {required bool append}) {
    final clean = recognized.replaceAll('\r\n', '\n').trim();
    if (clean.isEmpty) return false;
    text = append && text.trim().isNotEmpty ? '${text.trim()}\n$clean' : clean;
    return true;
  }

  Map<String, dynamic> toJson() => {
        'id': id, 'text': text, 'points': points, 'answer': answer, 'visible': visible,
        'type': type, 'sectionTitle': sectionTitle, 'branches': branches, 'elements': elements.map((e) => e.toJson()).toList(),
      };
  factory PaperQuestion.fromJson(Map<String, dynamic> map) => PaperQuestion(
        id: map['id']?.toString() ?? newId(),
        text: map['text']?.toString() ?? '',
        points: (parseLocalizedNumber(map['points']) ?? 5).clamp(0,1000000).toDouble(),
        answer: map['answer']?.toString() ?? '',
        visible: map['visible'] != false,
        type: map['type']?.toString() ?? 'essay',
        sectionTitle: map['sectionTitle']?.toString() ?? '',
        branches: (map['branches'] as List<dynamic>? ?? []).map((e) => '$e').toList(),
        elements: (map['elements'] as List<dynamic>? ?? [])
            .whereType<Map>()
            .map((e) => PaperElement.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
      );
}

class PaperDocument {
  // Explicit unnamed constructor: the named fromJson factory suppresses Dart's
  // implicit default constructor. All new/load/decode paths rely on this.
  PaperDocument();

  String title = 'اختبار الرياضيات';
  String documentType = 'exam';
  String subject = 'الرياضيات';
  String grade = 'السادس الابتدائي';
  String country = 'جمهورية العراق';
  String ministry = 'وزارة التربية';
  String directorate = 'المديرية العامة للتربية';
  String school = 'مدرستي الابتدائية';
  String academicYear = '2026 - 2027';
  String date = '';
  String duration = '45 دقيقة';
  String term = 'الفصل الأول';
  String examLabel = 'امتحان يومي';
  String bismillah = 'بسم الله الرحمن الرحيم';
  String topNote = 'أجب عن جميع الأسئلة';
  String footerText = 'مع تمنياتنا لكم بالنجاح والتوفيق';
  String teacherName = '';
  String? logoPath;
  DigitStyle digitStyle = DigitStyle.arabic;
  double total = 100;
  double topMarginMm = 8;
  double bottomMarginMm = 8;
  double sideMarginMm = 14;
  double headerGapMm = 6;
  double fontSize = 15;
  double lineSpacing = 1.45;
  double questionGap = 14;
  bool showRules = true;
  bool showGrades = true;
  bool showFooter = true;
  bool showPageNumbers = true;
  bool showHeaderLine = true;
  bool landscape = false;
  bool showLogo = true;
  bool showStudentNameField = true;
  bool showSectionField = true;
  String theme = 'teal';
  /// 'mathFrame' has an A4 border, 'arabicLines' emphasizes section headings.
  String paperLayout = 'mathFrame';
  Set<String> headerFields = {'country','ministry','directorate','school','title','academicYear','subject','grade','total','date','duration'};
  List<PaperQuestion> questions = [PaperQuestion(id: 'sample-1', text: 'جد ناتج ما يأتي:', points: 10, branches: ['٤٥٫٦٧ × ١٠٠ =', '١٠٠ ÷ ٦٫٥ ='])];

  String digits(Object? value) => formatDigits(value, digitStyle);
  double get usedPoints => questions.fold(0, (sum, question) => sum + question.points);

  Map<String, dynamic> toJson() => {
        'title':title,'documentType':documentType,'subject':subject,'grade':grade,
        'country':country,'ministry':ministry,'directorate':directorate,'school':school,
        'academicYear':academicYear,'date':date,'duration':duration,'term':term,
        'examLabel':examLabel,'bismillah':bismillah,'topNote':topNote,
        'footerText':footerText,'teacherName':teacherName,'logoPath':logoPath,'digitStyle':digitStyle.name,
        'total':total,'topMarginMm':topMarginMm,'bottomMarginMm':bottomMarginMm,
        'sideMarginMm':sideMarginMm,'headerGapMm':headerGapMm,'fontSize':fontSize,
        'lineSpacing':lineSpacing,'questionGap':questionGap,
        'showRules':showRules,'showGrades':showGrades,'showFooter':showFooter,
        'showPageNumbers':showPageNumbers,'showHeaderLine':showHeaderLine,
        'showLogo':showLogo,'showStudentNameField':showStudentNameField,'showSectionField':showSectionField,'landscape':landscape,'theme':theme,'paperLayout':paperLayout,
        'headerFields':headerFields.toList(), 'questions':questions.map((q)=>q.toJson()).toList(),
      };

  factory PaperDocument.fromJson(Map<String, dynamic> map) {
    final d = PaperDocument();
    final defaults = d.toJson();
    final merged = {...defaults, ...map};
    String s(String k) => merged[k]?.toString() ?? '';
    double n(String k) => parseLocalizedNumber(merged[k]) ?? 0;
    bool b(String k) => merged[k] == true;
    d.title=s('title'); d.documentType=s('documentType'); d.subject=s('subject');
    d.grade=s('grade'); d.country=s('country'); d.ministry=s('ministry');
    d.directorate=s('directorate'); d.school=s('school'); d.academicYear=s('academicYear');
    d.date=s('date'); d.duration=s('duration'); d.term=s('term'); d.examLabel=s('examLabel');
    d.bismillah=s('bismillah'); d.topNote=s('topNote'); d.footerText=s('footerText');
    d.teacherName=s('teacherName');
    d.logoPath=merged['logoPath']?.toString(); d.theme=s('theme');
    d.paperLayout = s('paperLayout') == 'arabicLines' ? 'arabicLines' : 'mathFrame';
    d.digitStyle=s('digitStyle') == 'english' ? DigitStyle.english : DigitStyle.arabic;
    d.total=n('total'); d.topMarginMm=n('topMarginMm'); d.bottomMarginMm=n('bottomMarginMm');
    d.sideMarginMm=n('sideMarginMm'); d.headerGapMm=n('headerGapMm');
    d.fontSize=n('fontSize'); d.lineSpacing=n('lineSpacing'); d.questionGap=n('questionGap');
    d.showRules=b('showRules'); d.showGrades=b('showGrades'); d.showFooter=b('showFooter');
    d.showPageNumbers=b('showPageNumbers'); d.showHeaderLine=b('showHeaderLine');
    d.showLogo=b('showLogo'); d.showStudentNameField = merged.containsKey('showStudentNameField') ? b('showStudentNameField') : d.showStudentNameField; d.showSectionField = merged.containsKey('showSectionField') ? b('showSectionField') : d.showSectionField; d.landscape=b('landscape');
    d.headerFields=(merged['headerFields'] as List<dynamic>? ?? []).map((e)=>'$e').toSet();
    d.questions=(merged['questions'] as List<dynamic>? ?? []).whereType<Map>().map((q)=>PaperQuestion.fromJson(Map<String,dynamic>.from(q))).toList();
    return d;
  }
  String encode() => jsonEncode(toJson());
  static PaperDocument decode(String source) => PaperDocument.fromJson(Map<String,dynamic>.from(jsonDecode(source) as Map));
}
