import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

/// Voice draft is never inserted until the user presses Add. One recognizer per
/// sheet, and each listening session replaces only its own provisional words.
class VoiceDictationSheet extends StatefulWidget {
  const VoiceDictationSheet({super.key, this.preferEnglish = false});

  final bool preferEnglish;

  @override
  State<VoiceDictationSheet> createState() => _VoiceDictationSheetState();
}

class _VoiceDictationSheetState extends State<VoiceDictationSheet> {
  final stt.SpeechToText _speech = stt.SpeechToText();
  final TextEditingController _text = TextEditingController();
  bool _initializing = false;
  bool _ready = false;
  bool _listening = false;
  String? _message;
  String _sessionPrefix = '';
  String? _locale;

  @override
  void dispose() {
    _speech.cancel();
    _text.dispose();
    super.dispose();
  }

  Future<void> _toggle() async {
    if (_initializing) return;
    if (_listening) {
      await _speech.stop();
      if (mounted) setState(() => _listening = false);
      return;
    }
    setState(() {
      _initializing = true;
      _message = null;
    });
    try {
      if (!_ready) {
        final available = await _speech.initialize(
          onStatus: (status) {
            if (!mounted) return;
            if (status == 'done' || status == 'notListening') {
              setState(() => _listening = false);
            }
          },
          onError: (error) {
            if (mounted) setState(() {
              _listening = false;
              _message = 'تعذّر التعرف على الصوت: ${error.errorMsg}';
            });
          },
        );
        if (!available) {
          if (mounted) setState(() => _message =
              'التعرف الصوتي غير متوفر. تحقق من إذن الميكروفون وخدمة التعرف الصوتي في الهاتف.');
          return;
        }
        _ready = true;
        final locales = await _speech.locales();
        final preferred = widget.preferEnglish ? 'en' : 'ar';
        for (final locale in locales) {
          if (locale.localeId.toLowerCase().startsWith(preferred)) {
            _locale = locale.localeId;
            break;
          }
        }
      }
      _sessionPrefix = _text.text.trimRight();
      if (!mounted) return;
      await _speech.listen(
        localeId: _locale,
        onResult: (result) {
          if (!mounted) return;
          final words = result.recognizedWords.trim();
          final next = [
            if (_sessionPrefix.isNotEmpty) _sessionPrefix,
            if (words.isNotEmpty) words,
          ].join(' ');
          _text.value = TextEditingValue(
            text: next,
            selection: TextSelection.collapsed(offset: next.length),
          );
          if (result.finalResult) setState(() => _listening = false);
        },
      );
      if (mounted) setState(() => _listening = _speech.isListening);
    } catch (error) {
      if (mounted) setState(() => _message = 'فشل تشغيل الميكروفون: $error');
    } finally {
      if (mounted) setState(() => _initializing = false);
    }
  }

  Future<void> _confirm() async {
    final result = _text.text.trim();
    if (result.isEmpty) return;
    if (_speech.isListening) await _speech.stop();
    if (mounted) Navigator.of(context).pop(result);
  }

  @override
  Widget build(BuildContext context) => SafeArea(
    child: Padding(
      padding: EdgeInsets.fromLTRB(20, 10, 20,
          20 + MediaQuery.viewInsetsOf(context).bottom),
      child: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('الكتابة بالصوت',
              style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
          const SizedBox(height:8),
          const Text('اضغط الميكروفون وتحدث، ثم راجع النص قبل إضافته. يمكن تعديل الكلمات والأرقام يدوياً.',
              style: TextStyle(fontSize: 12, height: 1.55)),
          const SizedBox(height: 14),
          Center(child: FilledButton.icon(
            onPressed: _initializing ? null : _toggle,
            icon: Icon(_listening ? Icons.stop_circle_outlined : Icons.mic),
            label: Text(_initializing ? 'جارٍ التهيئة...' :
                _listening ? 'إيقاف التسجيل' : 'ابدأ الإملاء'),
          )),
          if (_listening) const Padding(
            padding: EdgeInsets.only(top: 8),
            child: Text('الميكروفون يعمل الآن', textAlign: TextAlign.center),
          ),
          if (_message != null) Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Text(_message!, style: const TextStyle(color: Colors.redAccent)),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: _text,
            minLines: 4,
            maxLines: 8,
            textDirection: TextDirection.rtl,
            decoration: const InputDecoration(labelText: 'النص المُملى',
                hintText: 'النص الذي تتحدث به يظهر هنا ويمكن تصحيحه'),
          ),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(child: OutlinedButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('إلغاء'),
            )),
            const SizedBox(width: 10),
            Expanded(child: FilledButton.icon(
              onPressed: _confirm,
              icon: const Icon(Icons.check),
              label: const Text('إضافة النص'),
            )),
          ]),
        ]),
      ),
    ),
  );
}
