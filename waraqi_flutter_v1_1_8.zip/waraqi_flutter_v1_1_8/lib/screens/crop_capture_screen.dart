import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';

import '../services/ocr_crop_service.dart';
import '../theme.dart';

/// Two-step OCR workflow:
///   1) Capture the WHOLE photograph without a crop frame.
///   2) Display that photograph, then let the user move/resize the selection.
/// Gallery imports go straight to step 2. Only the final crop is returned.
class CropCaptureScreen extends StatefulWidget {
  const CropCaptureScreen({super.key, required this.fromCamera});

  final bool fromCamera;

  @override
  State<CropCaptureScreen> createState() => _CropCaptureScreenState();
}

class _CropCaptureScreenState extends State<CropCaptureScreen> {
  CameraController? _controller;
  img.Image? _originalImage;
  Uint8List? _displayJpeg;
  String? _error;
  bool _loading = true;
  bool _processing = false;

  // Coordinates are fractions of the entire acquired image, not of the view.
  double _frameWidth = .86;
  double _frameHeight = .34;
  double _centerX = .5;
  double _centerY = .5;

  bool get _cropping => _originalImage != null && _displayJpeg != null;

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    try {
      if (widget.fromCamera) {
        final cameras = await availableCameras();
        if (cameras.isEmpty) throw StateError('لا توجد كاميرا متاحة');
        final back = cameras.where(
          (camera) => camera.lensDirection == CameraLensDirection.back,
        );
        final device = back.isNotEmpty ? back.first : cameras.first;
        final controller = CameraController(
          device,
          ResolutionPreset.high,
          enableAudio: false,
          imageFormatGroup: ImageFormatGroup.jpeg,
        );
        await controller.initialize();
        if (!mounted) {
          await controller.dispose();
          return;
        }
        _controller = controller;
      } else {
        final picked = await ImagePicker().pickImage(
          source: ImageSource.gallery,
          imageQuality: 100,
        );
        if (picked == null) {
          if (mounted) Navigator.of(context).pop();
          return;
        }
        await _loadPhoto(File(picked.path));
      }
    } catch (e) {
      _error = 'تعذّر فتح ${widget.fromCamera ? 'الكاميرا' : 'الصورة'}: $e';
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  /// Decode once and apply EXIF orientation before choosing the crop.
  /// The on-screen image is a smaller copy to keep panning responsive.
  Future<void> _loadPhoto(File file) async {
    final bytes = await file.readAsBytes();
    final decoded = img.decodeImage(bytes);
    if (decoded == null) throw StateError('صيغة الصورة غير مدعومة');
    final oriented = img.bakeOrientation(decoded);
    final display = oriented.width > 1500
        ? img.copyResize(oriented, width: 1500)
        : oriented;
    final jpeg = Uint8List.fromList(img.encodeJpg(display, quality: 86));
    if (!mounted) return;
    setState(() {
      _originalImage = oriented;
      _displayJpeg = jpeg;
      _frameWidth = .86;
      _frameHeight = .34;
      _centerX = .5;
      _centerY = .5;
      _error = null;
    });
  }

  Future<void> _takeFullPhoto() async {
    final controller = _controller;
    if (_processing || controller == null || !controller.value.isInitialized) return;
    setState(() => _processing = true);
    try {
      // This captures the FULL frame. No crop is applied before the shutter.
      final taken = await controller.takePicture();
      final tempPhoto = File(taken.path);
      try {
        await _loadPhoto(tempPhoto);
      } finally {
        // Camera plugin writes a temporary photo. The app keeps only in-memory
        // content until the user approves the final text crop.
        if (await tempPhoto.exists()) await tempPhoto.delete();
      }
    } catch (e) {
      _reportError('تعذّر تصوير الورقة: $e');
    } finally {
      if (mounted) setState(() => _processing = false);
    }
  }

  void _retake() {
    if (_processing) return;
    setState(() {
      _originalImage = null;
      _displayJpeg = null;
    });
  }

  Future<void> _confirmCrop() async {
    final image = _originalImage;
    if (_processing || image == null) return;
    setState(() => _processing = true);
    try {
      final cropped = OcrCropService.crop(
        image,
        centerX: _centerX,
        centerY: _centerY,
        widthFraction: _frameWidth,
        heightFraction: _frameHeight,
      );
      final result = cropped.width > 1900
          ? img.copyResize(cropped, width: 1900)
          : cropped;
      final encoded = img.encodeJpg(result, quality: 90);
      if (mounted) Navigator.of(context).pop(encoded);
    } catch (e) {
      _reportError('تعذّر قص الصورة: $e');
    } finally {
      if (mounted) setState(() => _processing = false);
    }
  }

  void _reportError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF101C24),
      appBar: AppBar(
        backgroundColor: const Color(0xFF101C24),
        foregroundColor: Colors.white,
        title: Text(_cropping ? 'قصّ الجزء المراد استخراجه' : 'تصوير الورقة كاملة'),
        actions: [
          IconButton(
            tooltip: 'إغلاق',
            onPressed: () => Navigator.of(context).pop(),
            icon: const Icon(Icons.close_rounded),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 9, 18, 12),
              child: Text(
                _cropping
                    ? 'الآن اسحب إطار التحديد فوق النص المطلوب، وعدّل عرضه وارتفاعه، ثم اختر قص واستخراج النص.'
                    : 'صوّر الورقة كاملة أولًا. ستظهر الصورة بعد الالتقاط مباشرة لتختار منها النص الذي تريده.',
                style: const TextStyle(color: Colors.white70, fontSize: 13, height: 1.5),
                textAlign: TextAlign.center,
              ),
            ),
            Expanded(
              child: LayoutBuilder(
                builder: (context, constraints) {
                  if (_loading) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  if (_error != null) {
                    return Center(
                      child: Padding(
                        padding: const EdgeInsets.all(20),
                        child: Text(
                          _error!,
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.white),
                        ),
                      ),
                    );
                  }
                  if (_cropping) {
                    return _photoWithCrop(Size(
                      constraints.maxWidth,
                      constraints.maxHeight,
                    ));
                  }
                  if (_controller == null || !_controller!.value.isInitialized) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  return _cameraPreview();
                },
              ),
            ),
            _bottomPanel(),
          ],
        ),
      ),
    );
  }

  Widget _cameraPreview() {
    final controller = _controller!;
    return ClipRect(
      child: LayoutBuilder(
        builder: (context, box) {
          final size = controller.value.previewSize!;
          final portrait = Size(size.height, size.width);
          return Center(
            child: FittedBox(
              fit: BoxFit.contain,
              child: SizedBox(
                width: portrait.width,
                height: portrait.height,
                child: CameraPreview(controller),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _photoWithCrop(Size viewport) {
    final image = _originalImage!;
    final jpeg = _displayJpeg!;
    // BoxFit.contain: the ENTIRE source photo stays on screen. The crop overlay
    // is placed on the fitted image itself, not on its letterbox margins.
    final scale = math.min(viewport.width / image.width, viewport.height / image.height);
    final displayWidth = image.width * scale;
    final displayHeight = image.height * scale;
    final offsetX = (viewport.width - displayWidth) / 2;
    final offsetY = (viewport.height - displayHeight) / 2;
    final frame = Rect.fromCenter(
      center: Offset(_centerX * displayWidth, _centerY * displayHeight),
      width: _frameWidth * displayWidth,
      height: _frameHeight * displayHeight,
    );
    return Stack(
      children: [
        Positioned(
          left: offsetX,
          top: offsetY,
          width: displayWidth,
          height: displayHeight,
          child: Stack(
            fit: StackFit.expand,
            children: [
              Image.memory(jpeg, fit: BoxFit.fill, gaplessPlayback: true),
              IgnorePointer(child: CustomPaint(painter: _CropShade(frame: frame))),
              Positioned(
                left: frame.left,
                top: frame.top,
                width: frame.width,
                height: frame.height,
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onPanUpdate: (details) => setState(() {
                    _centerX = (_centerX + details.delta.dx / displayWidth)
                        .clamp(_frameWidth / 2, 1 - _frameWidth / 2).toDouble();
                    _centerY = (_centerY + details.delta.dy / displayHeight)
                        .clamp(_frameHeight / 2, 1 - _frameHeight / 2).toDouble();
                  }),
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: const Color(0xFFB9EBD0), width: 3),
                      borderRadius: BorderRadius.circular(11),
                    ),
                    child: const Stack(
                      children: [
                        Positioned(right: 4, top: 4,
                          child: Icon(Icons.open_with_rounded, color: Colors.white, size: 21)),
                        Positioned(bottom: 5, left: 5,
                          child: Text('اسحب لتحديد النص',
                            style: TextStyle(color: Colors.white, fontSize: 11,
                              shadows: [Shadow(color: Colors.black, blurRadius: 5)]))),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _bottomPanel() {
    return Container(
      color: const Color(0xFF182832),
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
      child: _cropping
          ? Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _fractionSlider(
                  icon: Icons.width_normal_rounded,
                  title: 'عرض التحديد',
                  value: _frameWidth,
                  min: .15,
                  onChanged: (value) => setState(() {
                    _frameWidth = value;
                    _centerX = _centerX.clamp(value / 2, 1 - value / 2).toDouble();
                  }),
                ),
                _fractionSlider(
                  icon: Icons.height_rounded,
                  title: 'ارتفاع التحديد',
                  value: _frameHeight,
                  min: .12,
                  onChanged: (value) => setState(() {
                    _frameHeight = value;
                    _centerY = _centerY.clamp(value / 2, 1 - value / 2).toDouble();
                  }),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    if (widget.fromCamera) ...[
                      OutlinedButton.icon(
                        onPressed: _processing ? null : _retake,
                        icon: const Icon(Icons.refresh_rounded),
                        label: const Text('إعادة التصوير'),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.white,
                          side: const BorderSide(color: Colors.white54),
                        ),
                      ),
                      const SizedBox(width: 10),
                    ],
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: _processing ? null : _confirmCrop,
                        icon: const Icon(Icons.crop_rounded),
                        label: Text(_processing ? 'جارٍ القص...' : 'قص واستخراج النص'),
                        style: FilledButton.styleFrom(
                          backgroundColor: const Color(0xFFB9EBD0),
                          foregroundColor: Palette.ink,
                          padding: const EdgeInsets.symmetric(vertical: 13),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            )
          : SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: _processing || _loading || _error != null ? null : _takeFullPhoto,
                icon: const Icon(Icons.camera_alt_rounded),
                label: Text(_processing ? 'جارٍ التقاط الصورة...' : 'تصوير الورقة كاملة'),
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFFB9EBD0),
                  foregroundColor: Palette.ink,
                  padding: const EdgeInsets.symmetric(vertical: 15),
                ),
              ),
            ),
    );
  }

  Widget _fractionSlider({
    required IconData icon,
    required String title,
    required double value,
    required double min,
    required ValueChanged<double> onChanged,
  }) {
    return Row(
      children: [
        Icon(icon, color: Colors.white70, size: 20),
        const SizedBox(width: 8),
        Text(title, style: const TextStyle(color: Colors.white, fontSize: 12)),
        Expanded(
          child: Slider(
            value: value,
            min: min,
            max: 1.0,
            activeColor: const Color(0xFFB9EBD0),
            onChanged: onChanged,
          ),
        ),
      ],
    );
  }
}

class _CropShade extends CustomPainter {
  const _CropShade({required this.frame});
  final Rect frame;

  @override
  void paint(Canvas canvas, Size size) {
    final outside = Path()
      ..addRect(Offset.zero & size)
      ..addRRect(RRect.fromRectAndRadius(frame, const Radius.circular(11)));
    outside.fillType = PathFillType.evenOdd;
    canvas.drawPath(
      outside,
      Paint()..color = Colors.black.withValues(alpha: .55),
    );
    final grid = Paint()
      ..color = Colors.white.withValues(alpha: .48)
      ..strokeWidth = 1;
    for (var i = 1; i < 3; i++) {
      canvas.drawLine(
        Offset(frame.left + frame.width * i / 3, frame.top),
        Offset(frame.left + frame.width * i / 3, frame.bottom),
        grid,
      );
      canvas.drawLine(
        Offset(frame.left, frame.top + frame.height * i / 3),
        Offset(frame.right, frame.top + frame.height * i / 3),
        grid,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _CropShade oldDelegate) => oldDelegate.frame != frame;
}
