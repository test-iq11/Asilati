package com.waraqi.studio

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
