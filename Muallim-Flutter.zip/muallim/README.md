# مساعد المعلم — 4.0.0 (مصدر Flutter)

المرجع: `reference/Muallim-Audited-Inline-Preview.html` هو الملف الأخير الذي اعتمده المستخدم. يحتوي مجلد reference على المعاينة والتدقيقين الأصليين للمقارنة فقط؛ لا يستخدم التطبيق WebView ولا يقوم بتشغيل HTML.

## بناء Android
ارفع `Muallim-Flutter.zip` في جذر المستودع، وضع `build-muallim.yml` خارج ZIP في `.github/workflows/`. يهيئ ملف البناء Android والخطوط، ويشغّل `flutter analyze` و`flutter test` قبل `flutter build apk --release`. يحتفظ بالتقارير عند الفشل. لا تتجاوز الاختبارات.

## نطاق هذه النسخة
انظر `IMPLEMENTATION-STATUS.md` لمعرفة ما تمت كتابته وما لم يثبت عمله بعد. هذه نسخة مصدر غير مبنية محلياً، وليست شهادة مطابقة 100% أو APK مختبر.
