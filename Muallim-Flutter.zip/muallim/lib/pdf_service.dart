import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'data.dart';

Future<pw.Font> arabicFont() async => pw.Font.ttf(await rootBundle.load('assets/fonts/NotoNaskhArabic-Regular.ttf'));
PdfPageFormat examFormat(Item e){var f=switch(str(e,'size')){'A3'=>PdfPageFormat.a3,'A5'=>PdfPageFormat.a5,_=>PdfPageFormat.a4};return str(e,'orientation')=='أفقي'?f.landscape:f;}
double examFontSize(Item e)=>switch(str(e,'font')){'صغير'=>10.0,'كبير'=>16.0,_=>12.0};
double examMargin(Item e)=>switch(str(e,'margin')){'ضيقة'=>24.0,'واسعة'=>48.0,_=>32.0};
String schoolHeading(Item e)=>str(e,'school').trim().isEmpty?'إدارة مدرسة':'إدارة مدرسة\n${str(e,'school')}';
String examHeading(Item e,{bool answers=false})=>[if(e['basmala']!=false)'بسم الله الرحمن الرحيم',str(e,'title'),str(e,'schoolYear'),if(answers)'نموذج الإجابة'].where((s)=>s.isNotEmpty).join('\n');
String examDetails(Item e)=>['الصف - ${str(e,'grade').replaceAll(' الابتدائي','')}','المادة - ${str(e,'subject')}',if(str(e,'duration').isNotEmpty)'الوقت - ${str(e,'duration')}'].join('\n');
String signature(Item e)=>[str(e,'teacherTitle','معلم المادة'),str(e,'teacherName')].where((s)=>s.trim().isNotEmpty).join('\n');
String markLabel(Item e,Item q)=>e['showMarks']==false||items(q['children']).isNotEmpty||questionMark(q)==0?'':'(${arabicNumber(questionMark(q).toString().replaceFirst(RegExp(r'\.0$'),''))} درجة)';
Future<Uint8List> examPdf(Item e,{bool answers=false}) async {
 final font=await arabicFont(); final doc=pw.Document();final format=examFormat(e),size=examFontSize(e),margin=examMargin(e);
 final ink=e['color']==true?PdfColor.fromInt(0xff354c94):PdfColors.black;
 final style=pw.TextStyle(font:font,fontSize:size,color:PdfColors.black,fontFallback:[pw.Font.helvetica()]);
 pw.Widget text(String s,{double? fs,pw.TextAlign align=pw.TextAlign.right})=>pw.Text(s,style:style.copyWith(fontSize:fs??size),textAlign:align,textDirection:pw.TextDirection.rtl);
 pw.Widget physicalRow(List<pw.Widget> children)=>pw.Directionality(textDirection:pw.TextDirection.ltr,child:pw.Row(crossAxisAlignment:pw.CrossAxisAlignment.start,children:children));
 pw.Widget element(Item b){
   if(b['type']=='table'){final rows=(b['rows'] as List).map((r)=>(r as List).map((v)=>v.toString()).toList()).toList();return pw.Table(border:pw.TableBorder.all(color:PdfColors.grey600),children:rows.map((r)=>pw.TableRow(children:r.reversed.map((v)=>pw.Padding(padding:const pw.EdgeInsets.all(3),child:text(v,fs:size-1,align:pw.TextAlign.center))).toList())).toList());}
   if(str(b,'image').isNotEmpty){try{return pw.Center(child:pw.Image(pw.MemoryImage(base64Decode(str(b,'image'))),width:format.width-margin*2,height:b['type']=='formula'?48:120,fit:pw.BoxFit.contain));}catch(_){}}
   return text(str(b,'text'));
 }
 List<pw.Widget> nodes(List<Item> qs,int depth){final out=<pw.Widget>[];for(int i=0;i<qs.length;i++){final q=qs[i];final children=items(q['children']);final mark=markLabel(e,q);out.add(pw.Padding(padding:pw.EdgeInsets.only(right:depth*10.0,top:3,bottom:2),child:physicalRow([if(mark.isNotEmpty)pw.SizedBox(width:65,child:text(mark,fs:size-1,align:pw.TextAlign.left)),pw.Expanded(child:text('${questionLabel(q,i,depth,str(e,'numbering','س'))} ${str(q,'text')}'))])));for(final b in items(q['elements'])){if(b['type']=='pageBreak'){out.add(pw.NewPage());}else{out.add(pw.Padding(padding:const pw.EdgeInsets.symmetric(vertical:3),child:element(b)));}}if(children.isNotEmpty)out.addAll(nodes(children,depth+1));if(answers&&str(q,'answer').isNotEmpty)out.add(text(str(q,'answer')));else if(!answers&&children.isEmpty)for(var line=0;line<(e['answerLines'] as int? ?? 0);line++)out.add(pw.Padding(padding:const pw.EdgeInsets.only(top:10),child:pw.Divider(color:PdfColors.grey500)));if(depth==0&&e['separator']!=false)out.add(pw.Divider(color:ink,thickness:.7));}return out;}
 final pageTheme=pw.PageTheme(pageFormat:format,margin:pw.EdgeInsets.all(margin+4),textDirection:pw.TextDirection.rtl,theme:pw.ThemeData.withFont(base:font),buildBackground:e['frame']==true?(_)=>pw.FullPage(ignoreMargins:true,child:pw.Padding(padding:pw.EdgeInsets.all(margin-6),child:pw.Container(width:double.infinity,height:double.infinity,decoration:pw.BoxDecoration(border:pw.Border.all(color:ink,width:1.2))))):null);
 doc.addPage(pw.MultiPage(pageTheme:pageTheme,maxPages:200,
 header:(ctx)=>ctx.pageNumber!=1?pw.SizedBox():pw.Column(children:[physicalRow([pw.Expanded(child:text(examDetails(e),fs:11,align:pw.TextAlign.center)),pw.Expanded(flex:2,child:text(examHeading(e,answers:answers),fs:12,align:pw.TextAlign.center)),pw.Expanded(child:text(schoolHeading(e),fs:11,align:pw.TextAlign.center))]),pw.Divider(color:ink,thickness:1)]),
 footer:(ctx)=>pw.Column(children:[if(ctx.pageNumber==ctx.pagesCount)...[if(str(e,'footer').isNotEmpty)pw.Center(child:text(str(e,'footer'))),pw.Align(alignment:pw.Alignment.centerLeft,child:pw.Padding(padding:const pw.EdgeInsets.only(left:26,top:8,bottom:4),child:text(signature(e),fs:11,align:pw.TextAlign.center)))],if(e['pageNumbers']==true)pw.Center(child:text('${ctx.pageNumber} / ${ctx.pagesCount}',fs:9))]),
 build:(_)=>[if(str(e,'notes').isNotEmpty)pw.Padding(padding:const pw.EdgeInsets.only(bottom:5),child:text(str(e,'notes'),fs:size+1)),...nodes(items(e['questions']),0)]));
 return doc.save();
}
Future<Uint8List> tablePdf(String title,List<String> headers,List<List<String>> rows) async {final font=await arabicFont();final doc=pw.Document();doc.addPage(pw.MultiPage(pageFormat:PdfPageFormat.a4.landscape,textDirection:pw.TextDirection.rtl,theme:pw.ThemeData.withFont(base:font),build:(_)=>[pw.Center(child:pw.Text(title,style:const pw.TextStyle(fontSize:20))),pw.SizedBox(height:16),pw.Table(border:pw.TableBorder.all(),children:[pw.TableRow(decoration:const pw.BoxDecoration(color:PdfColors.grey200),children:headers.map((x)=>pw.Padding(padding:const pw.EdgeInsets.all(6),child:pw.Text(x))).toList()),...rows.map((r)=>pw.TableRow(children:r.map((x)=>pw.Padding(padding:const pw.EdgeInsets.all(6),child:pw.Text(x))).toList()))])]));return doc.save();}
