import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'data.dart';
Future<pw.Font> arabicFont() async {try{return pw.Font.ttf(await rootBundle.load('assets/fonts/NotoNaskhArabic-Regular.ttf'));}catch(_){return PdfGoogleFonts.notoNaskhArabicRegular();}}
Future<Uint8List> examPdf(Item e,{bool answers=false}) async {
 final font=await arabicFont(); final doc=pw.Document();
 var format= switch(str(e,'size')){'A3'=>PdfPageFormat.a3,'A5'=>PdfPageFormat.a5,_=>PdfPageFormat.a4};
 if(str(e,'orientation')=='أفقي')format=format.landscape;
 final size=switch(str(e,'font')){'صغير'=>11.0,'كبير'=>17.0,_=>14.0};
 final margin=switch(str(e,'margin')){'ضيقة'=>20.0,'واسعة'=>48.0,_=>32.0};
 final ink=e['color']==true?PdfColor.fromInt(0xff126b55):PdfColors.black;
 final style=pw.TextStyle(font:font,fontSize:size,color:PdfColors.black,fontFallback:[pw.Font.helvetica()]);
 pw.Widget text(String s,{double? fs,pw.TextAlign? align})=>pw.Text(s,style:style.copyWith(fontSize:fs??size),textAlign:align);
 pw.Widget element(Item b){
   if(b['type']=='table'){ final rows=(b['rows'] as List).map((r)=>(r as List).map((v)=>v.toString()).toList()).toList();return pw.Table(border:pw.TableBorder.all(color:PdfColors.grey600),children:rows.map((r)=>pw.TableRow(children:r.map((v)=>pw.Padding(padding:const pw.EdgeInsets.all(4),child:text(v,fs:size-2,align:pw.TextAlign.center))).toList())).toList()); }
   if(str(b,'image').isNotEmpty){try{return pw.Center(child:pw.Image(pw.MemoryImage(base64Decode(str(b,'image'))),width:format.availableWidth-margin*2,height:b['type']=='formula'?65:160,fit:pw.BoxFit.contain));}catch(_){}}
   return text(str(b,'text'));
 }
 final qs=items(e['questions']);
 doc.addPage(pw.MultiPage(pageFormat:format,margin:pw.EdgeInsets.all(margin),textDirection:pw.TextDirection.rtl,theme:pw.ThemeData.withFont(base:font),maxPages:200,
 header:(_)=>pw.Column(children:[pw.Row(crossAxisAlignment:pw.CrossAxisAlignment.start,children:[pw.Expanded(child:text('وزارة التربية\n${str(e,'school')}',fs:11,align:pw.TextAlign.center)),pw.Expanded(child:text('بسم الله الرحمن الرحيم\n${str(e,'title')}${answers?' — نموذج الإجابة':''}',align:pw.TextAlign.center)),pw.Expanded(child:text('المادة: ${str(e,'subject')}\nالصف: ${str(e,'grade')}\nالوقت: ${str(e,'duration')}',fs:11))]),pw.Divider(color:ink)]),
 footer:(c)=>pw.Center(child:text('${c.pageNumber} / ${c.pagesCount}',fs:10)),
 build:(_)=>[pw.Center(child:text(answers?'نموذج الإجابة':'الأسئلة',fs:size+2)),pw.SizedBox(height:10),for(var i=0;i<qs.length;i++)...[
 pw.Row(crossAxisAlignment:pw.CrossAxisAlignment.start,children:[pw.Expanded(child:text('${str(e,'numbering','س')}${i+1}/ ${str(qs[i],'text')}')),text('(${qs[i]['mark']??0} درجات)',fs:11)]),
 for(final b in items(qs[i]['elements']))pw.Padding(padding:const pw.EdgeInsets.symmetric(vertical:4),child:element(b)),
 if(answers)text(str(qs[i],'answer')) else for(var line=0;line<(e['answerLines'] as int? ?? 1);line++)pw.Padding(padding:const pw.EdgeInsets.only(top:16),child:pw.Divider(color:PdfColors.grey400)),pw.SizedBox(height:12)],
 pw.SizedBox(height:18),pw.Center(child:text('مع تمنياتنا لكم بالنجاح والتوفيق')),text(str(e,'footer')),text('مجموع الدرجات: ${qs.fold<num>(0,(a,q)=>a+(q['mark'] as num? ?? 0))}') ]));
 return doc.save();
}
Future<Uint8List> tablePdf(String title,List<String> headers,List<List<String>> rows) async {final font=await arabicFont();final doc=pw.Document();doc.addPage(pw.MultiPage(pageFormat:PdfPageFormat.a4.landscape,textDirection:pw.TextDirection.rtl,theme:pw.ThemeData.withFont(base:font),build:(_)=>[pw.Center(child:pw.Text(title,style:const pw.TextStyle(fontSize:20))),pw.SizedBox(height:16),pw.Table(border:pw.TableBorder.all(),children:[pw.TableRow(decoration:const pw.BoxDecoration(color:PdfColors.grey200),children:headers.map((x)=>pw.Padding(padding:const pw.EdgeInsets.all(6),child:pw.Text(x))).toList()),...rows.map((r)=>pw.TableRow(children:r.map((x)=>pw.Padding(padding:const pw.EdgeInsets.all(6),child:pw.Text(x))).toList()))])]));return doc.save();}
