import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

typedef Item = Map<String, dynamic>;
const subjects = ['الرياضيات','اللغة العربية','اللغة الإنجليزية','العلوم','التربية الإسلامية','الفيزياء','الكيمياء','الأحياء','الاجتماعيات','الحاسوب','الفنية','الرياضة'];
const grades = ['الأول الابتدائي','الثاني الابتدائي','الثالث الابتدائي','الرابع الابتدائي','الخامس الابتدائي','السادس الابتدائي','الأول المتوسط','الثاني المتوسط','الثالث المتوسط','الرابع الإعدادي','الخامس الإعدادي','السادس الإعدادي'];
const days = ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس'];
int _sequence=0;
String uid() => "${DateTime.now().microsecondsSinceEpoch}-${_sequence++}";
String str(Item m,String k,[String fallback='']) => m[k]?.toString() ?? fallback;
List<Item> items(dynamic x) => (x is List ? x : const []).whereType<Map>().map((m)=>Map<String,dynamic>.from(m)).toList();
Item copy(Item x)=>Map<String,dynamic>.from(jsonDecode(jsonEncode(x)) as Map);
Item question()=>{'id':uid(),'text':'','mark':10,'answer':'','elements':<Item>[]};
Item exam([String subject='الرياضيات',String title='امتحان الشهر الأول',String grade='السادس الابتدائي'])=>{'id':uid(),'title':title,'subject':subject,'grade':grade,'school':'','duration':'ساعة واحدة','footer':'','questions':[question()],'size':'A4','orientation':'عمودي','font':'متوسط','margin':'عادية','color':false,'numbering':'س','answerLines':1};
double average(num a,num b)=>(a+b)/2;
String normalizeDigits(String text) => text.replaceAllMapped(RegExp('[٠-٩۰-۹]'), (m) { final n=m[0]!.codeUnitAt(0); return (n >= 0x06f0 ? n-0x06f0 : n-0x0660).toString(); });
int score(String text)=> (int.tryParse(normalizeDigits(text).trim())??0).clamp(0,100).toInt();
class Store {
  Store(this.file);
  final File file;
  Item data=empty();
  Future<void> _pending=Future.value();
  static Item empty()=>{'version':1,'dark':false,'exams':[],'bank':[],'books':[],'plans':[],'schedule':[],'audio':[],'elements':[]};
  static Future<Store> open() async {
    final dir=await getApplicationDocumentsDirectory();
    final s=Store(File('${dir.path}/muallim.json'));
    if(await s.file.exists()) { try {s.data=validate(jsonDecode(await s.file.readAsString()));} catch (_) { final corrupt=File('${s.file.path}.corrupt-${uid()}'); await s.file.copy(corrupt.path); throw FormatException('تعذر قراءة البيانات. تم الاحتفاظ بالأصل ونسخة في ${corrupt.path}'); } }
    return s;
  }
  static Item validate(dynamic x) {
    if(x is! Map || x['version']!=1) throw const FormatException('نسخة غير متوافقة');
    final result=empty();
    for(final k in ['exams','bank','books','plans','schedule','audio','elements']) { if(x[k] is! List || (x[k] as List).any((v)=>v is! Map)) throw FormatException('حقل غير صالح: $k'); result[k]=items(x[k]); }
    void require(bool valid, String path) { if(!valid) throw FormatException('بيانات غير صالحة: $path'); }
    void records(dynamic list, String path, void Function(Item) check) {
      require(list is List, path);
      final ids=<String>{};
      for(final raw in list as List) {
        require(raw is Map, path);
        final row=Map<String,dynamic>.from(raw as Map);
        require(row['id'] is String && (row['id'] as String).isNotEmpty && (path=='question.elements' || ids.add(row['id'] as String)), '$path.id');
        check(row);
      }
    }
    void element(Item b) {
      require(['formula','draw','image','table'].contains(b['type']), 'elements.type');
      if(b['type']=='table') {
        final rows=b['rows'];
        require(rows is List && rows.isNotEmpty && rows.length<=12, 'table.rows');
        final list=rows as List;
        require(list.first is List && (list.first as List).isNotEmpty && (list.first as List).length<=8, 'table.columns');
        require(list.every((r)=>r is List && r.length==(list.first as List).length && r.every((c)=>c is String)), 'table.cells');
      } else {
        require(b['image'] is String && (b['image'] as String).isNotEmpty, 'elements.image');
      }
    }
    void questionFields(Item q) { records(q['elements'], 'question.elements', element); }
    records(result['exams'], 'exams', (e) {
      records(e['questions'], 'questions', (q) {
        require(q['mark'] is num && (q['mark'] as num).isFinite && (q['mark'] as num)>=0 && (q['mark'] as num)<=1000, 'question.mark');
        questionFields(q);
      });
      require(e['answerLines'] is int && (e['answerLines'] as int)>=0 && (e['answerLines'] as int)<=5, 'exam.answerLines');
    });
    records(result['bank'], 'bank', questionFields);
    records(result['books'], 'books', (b) => records(b['students'], 'students', (student) {
      for(final k in ['first','second']) { final v=student[k]; require(v is num && v.isFinite && v>=0 && v<=100, 'student.$k'); }
    }));
    records(result['plans'], 'plans', (_) {});
    records(result['schedule'], 'schedule', (p) { final d=p['day'], n=p['period']; require(d is int && d>=0 && d<days.length && n is int && n>=1 && n<=7, 'schedule.period'); });
    records(result['audio'], 'audio', (a) => require(a['bytes'] is String, 'audio.bytes'));
    records(result['elements'], 'elements', element);
    result['dark']=x['dark']==true;
    return result;
  }
  List<Item> list(String key)=>items(data[key]);
  Future<void> save(){final snapshot=jsonEncode(data); final next=_pending.catchError((Object _){}).then((_)async{final temp=File('${file.path}.tmp');await temp.writeAsString(snapshot,flush:true);await temp.rename(file.path);});_pending=next;return next;}
  Future<void> put(String key,Item value) {final l=list(key); final i=l.indexWhere((v)=>v['id']==value['id']); if(i<0){l.insert(0,copy(value));}else{l[i]=copy(value);}data[key]=l;return save();}
  Future<void> remove(String key,String id){data[key]=list(key)..removeWhere((v)=>v['id']==id);return save();}
}
