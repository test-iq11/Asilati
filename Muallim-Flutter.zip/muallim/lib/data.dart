import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

typedef Item = Map<String, dynamic>;
const subjects = ['الرياضيات','اللغة العربية','اللغة الإنجليزية','العلوم','التربية الإسلامية','الفيزياء','الكيمياء','الأحياء','الاجتماعيات','الحاسوب','الفنية','الرياضة'];
const grades = ['الأول الابتدائي','الثاني الابتدائي','الثالث الابتدائي','الرابع الابتدائي','الخامس الابتدائي','السادس الابتدائي','الأول المتوسط','الثاني المتوسط','الثالث المتوسط','الرابع الإعدادي','الخامس الإعدادي','السادس الإعدادي'];
const days = ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس'];
int _sequence=0;
String uid() => "${DateTime.now().microsecondsSinceEpoch}-${_sequence++}";
String str(Item m,String k,[String fallback='']) => m[k]?.toString() ?? fallback;
List<Item> items(dynamic x) => (x is List ? x : const []).whereType<Map>().map((m)=>Map<String,dynamic>.from(m)).toList();
Item copy(Item x)=>Map<String,dynamic>.from(jsonDecode(jsonEncode(x)) as Map);
Item question()=>{'id':uid(),'text':'','mark':10,'answer':'','elements':<Item>[], 'children':<Item>[], 'number':'','required':0,'language':'عربي','visible':true,'newPage':false,'answerStyle':'بلا','layout':'كل نقطة بسطر'};
Item exam([String subject='الرياضيات',String title='امتحان الشهر الأول',String grade='السادس الابتدائي'])=>{'id':uid(),'title':title,'subject':subject,'grade':grade,'school':'','duration':'ساعة واحدة','footer':'','questions':[question()],'size':'A4','orientation':'عمودي','font':'متوسط','margin':'عادية','color':false,'numbering':'س','answerLines':0,'teacherName':'','teacherTitle':'معلم المادة','schoolYear':'','notes':'','frame':false,'separator':true,'showMarks':true,'basmala':true,'pageNumbers':false,'fontSize':12.0,'gap':3.0,'lineHeight':1.35,'marksMode':'الدرجات بجانب الفروع والأسئلة','signaturePosition':'اليسار','repeatHeader':false};
double average(num a,num b)=>(a+b)/2;
String normalizeDigits(String text) => text.replaceAllMapped(RegExp('[٠-٩۰-۹]'), (m) { final n=m[0]!.codeUnitAt(0); return (n >= 0x06f0 ? n-0x06f0 : n-0x0660).toString(); });
int score(String text)=> (int.tryParse(normalizeDigits(text).trim())??0).clamp(0,100).toInt();
class Store {
  Store(this.file);
  final File file;
  Item data=empty();
  Future<void> _pending=Future.value();
  static Item empty()=>{'version':1,'dark':false,'exams':[],'bank':[],'books':[],'plans':[],'schedule':[],'audio':[],'elements':[]};
  static Future<Store> open() async {
    final dir=await getApplicationDocumentsDirectory();
    final s=Store(File('${dir.path}/muallim.json'));
    if(await s.file.exists()) { try {s.data=validate(jsonDecode(await s.file.readAsString()));} catch (_) { final corrupt=File('${s.file.path}.corrupt-${uid()}'); await s.file.copy(corrupt.path); throw FormatException('تعذر قراءة البيانات. تم الاحتفاظ بالأصل ونسخة في ${corrupt.path}'); } }
    return s;
  }
  static Item validate(dynamic x) {
    if(x is! Map || x['version']!=1) throw const FormatException('نسخة غير متوافقة');
    final result=empty();
    for(final k in ['exams','bank','books','plans','schedule','audio','elements']) { if(x[k] is! List || (x[k] as List).any((v)=>v is! Map)) throw FormatException('حقل غير صالح: $k'); result[k]=items(x[k]); }
    void require(bool valid, String path) { if(!valid) throw FormatException('بيانات غير صالحة: $path'); }
    void records(dynamic list, String path, void Function(Item) check) {
      require(list is List, path);
      final ids=<String>{};
      for(final raw in list as List) {
        require(raw is Map, path);
        final row=Map<String,dynamic>.from(raw as Map);
        require(row['id'] is String && (row['id'] as String).isNotEmpty && (path=='question.elements' || ids.add(row['id'] as String)), '$path.id');
        check(row);
      }
    }
    void element(Item b) {
      require(['formula','draw','image','table','text','pageBreak','imageGrid'].contains(b['type']), 'elements.type');
      if(b['type']=='table') {
        final rows=b['rows'];
        require(rows is List && rows.isNotEmpty && rows.length<=12, 'table.rows');
        final list=rows as List;
        require(list.first is List && (list.first as List).isNotEmpty && (list.first as List).length<=8, 'table.columns');
        require(list.every((r)=>r is List && r.length==(list.first as List).length && r.every((c)=>c is String)), 'table.cells');
      } else if(b['type']=='imageGrid'){require(b['images'] is List && (b['images'] as List).isNotEmpty && (b['images'] as List).every((v)=>v is String && v.isNotEmpty),'elements.images');} else if (b['type']!='text' && b['type']!='pageBreak') {
        require(b['image'] is String && (b['image'] as String).isNotEmpty, 'elements.image');
      }
    }
    void questionFields(Item q) { records(q['elements'], 'question.elements', element); if(q['answerElements']!=null)records(q['answerElements'],'answerElements',element); records(q['children']??[], 'questions.children', (child) { require(child['mark'] is num && (child['mark'] as num).isFinite && (child['mark'] as num)>=0 && (child['mark'] as num)<=1000, 'child.mark'); questionFields(child); }); }
    records(result['exams'], 'exams', (e) {
      records(e['questions'], 'questions', (q) {
        require(q['mark'] is num && (q['mark'] as num).isFinite && (q['mark'] as num)>=0 && (q['mark'] as num)<=1000, 'question.mark');
        questionFields(q);
      });
      require(e['answerLines'] is int && (e['answerLines'] as int)>=0 && (e['answerLines'] as int)<=5, 'exam.answerLines');
    });
    records(result['bank'], 'bank', questionFields);
    records(result['books'], 'books', (b) => records(b['students'], 'students', (student) {
      for(final k in ['first','second','mid','third','fourth','final']) { final v=student[k]; require(v==null || (v is num && v.isFinite && v>=0 && v<=100), 'student.$k'); }
    }));
    records(result['plans'], 'plans', (_) {});
    records(result['schedule'], 'schedule', (p) { final d=p['day'], n=p['period']; require(d is int && d>=0 && d<days.length && n is int && n>=1 && n<=7, 'schedule.period'); });
    records(result['audio'], 'audio', (a) => require(a['bytes'] is String, 'audio.bytes'));
    records(result['elements'], 'elements', element);
    result['dark']=x['dark']==true;
    return result;
  }
  List<Item> list(String key)=>items(data[key]);
  Future<void> save(){final snapshot=jsonEncode(data); final next=_pending.catchError((Object _){}).then((_)async{final temp=File('${file.path}.tmp');await temp.writeAsString(snapshot,flush:true);await temp.rename(file.path);});_pending=next;return next;}
  Future<void> put(String key,Item value) {final l=list(key); final i=l.indexWhere((v)=>v['id']==value['id']); if(i<0){l.insert(0,copy(value));}else{l[i]=copy(value);}data[key]=l;return save();}
  Future<void> remove(String key,String id){data[key]=list(key)..removeWhere((v)=>v['id']==id);return save();}
}

num questionMark(Item q) {final children=items(q['children']); return children.isEmpty?(q['mark'] as num? ?? 0):requiredItems(q,children).fold<num>(0,(sum,x)=>sum+questionMark(x));}
String arabicNumber(Object n)=>n.toString().replaceAllMapped(RegExp('[0-9]'),(m)=>'٠١٢٣٤٥٦٧٨٩'[int.parse(m[0]!)]);
String questionLabel(Item q,int index,int depth,String prefix){final custom=str(q,'number');if(custom.isNotEmpty)return custom;if(depth==0)return '$prefix${arabicNumber(index+1)} /';if(depth==1&&index<10)return '${'أبجدهوزحطي'[index]} /';return '${arabicNumber(index+1)} -';}

const gradeFields=['first','second','mid','third','fourth','final'];
const gradeLabels=['الشهر الأول','الشهر الثاني','نصف السنة','الشهر الثالث','الشهر الرابع','نهاية السنة'];
double? studentMean(Item s){final vals=gradeFields.map((k)=>s[k]).whereType<num>().toList();return vals.isEmpty?null:vals.fold<num>(0,(a,b)=>a+b)/vals.length;}
List<Item> distributeTopics(String text,int start,int end,int weeks){final months=<int>[];int m=start.clamp(1,12).toInt();for(int i=0;i<12;i++){months.add(m);if(m==end.clamp(1,12))break;m=m%12+1;}final slots=<Item>[for(final month in months)for(int w=1;w<=weeks.clamp(1,5);w++){'month':month,'week':w,'topic':'مراجعة','status':'مراجعة'}];final topics=text.split('\n').map((x)=>x.trim()).where((x)=>x.isNotEmpty).toList();for(int i=0;i<topics.length;i++){final pos=i*slots.length~/topics.length;final row=slots[pos];row['topic']=row['status']=='مراجعة'?topics[i]:'${row['topic']}، ${topics[i]}';row['status']='اعتيادي';}return slots;}

String elementText(Item b,{bool answers=false}){final k=str(b,'kind'),t=str(b,'text'),o=str(b,'options'),s=str(b,'second');final opts=o.split('\n').where((x)=>x.isNotEmpty).toList(),other=s.split('\n');if(k=='نموذج الإجابة'&&!answers)return '';if(k=='مساحة إجابة'){final n=(b['lines'] as int? ?? 3).clamp(1,12).toInt();final ch=switch(str(b,'style')){'منقط'=>'...............................','مربعات'=>'□  □  □  □  □  □  □  □','فراغ'=>' ','إطار'=>'┌────────────────────┐',_=>'________________________________'};return List.filled(n,ch).join('\n');}if(k=='خيارات متعددة'){final a=[for(int i=0;i<opts.length;i++)'${arabicNumber(i+1)}) ${opts[i]}'];return [t,a.join(str(b,'layout')=='أفقي مع التفاف'?'    ':'\n'),if(answers&&str(b,'correct').isNotEmpty)'الإجابة: ${str(b,'correct')}'].where((v)=>v.isNotEmpty).join('\n');}if(k=='مطابقة'||k=='شعر'){return [t,for(int i=0;i<opts.length;i++)'${opts[i]}       ${i<other.length?other[i]:''}'].where((v)=>v.isNotEmpty).join('\n');}if(k=='فقرات بأعمدة')return [t,opts.join('     ')].join('\n');if(k=='صح أو خطأ')return '$t (${answers?str(b,'answer'):'     '})';if(k=='تعريف')return '${str(b,'term')}: $t';if(k=='مثال محلول')return '$t\n${str(b,'solution')}';if(k=='آية أو حديث')return '$t\n${str(b,'caption')}';return t;}
String outputDigits(Item e,String s,{bool text=false}){final mode=str(e,text?'textDigits':'digitStyle');if(mode.contains('123'))return normalizeDigits(s);if(mode.contains('١٢٣'))return arabicNumber(s);return s;}
String outputLabel(Item e,Item q,int i,int depth){final custom=str(q,'number');if(custom.isNotEmpty)return custom;final n=outputDigits(e,arabicNumber(i+1));if(depth==0)return '${str(e,'numbering','س')}$n /';final mode=str(e,depth==1?'partNumber':'pointNumber',depth==1?'أ، ب، ج':'١، ٢، ٣');if(mode.startsWith('A')&&i<26)return '${String.fromCharCode(65+i)} /';if(mode.startsWith('أ')&&i<10)return '${'أبجدهوزحطي'[i]} /';if(mode.startsWith('1'))return '${i+1} /';return '$n /';}

List<Item> requiredItems(Item parent,List<Item> nodes){final count=parent['required'];return count is num&&count>0?nodes.take(count.toInt()).toList():nodes;}
num examMark(Item e,List<Item> nodes)=>requiredItems(e,nodes).fold<num>(0,(sum,q)=>sum+questionMark(q));
