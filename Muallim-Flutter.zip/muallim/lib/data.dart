import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

typedef Item = Map<String, dynamic>;
const subjects = ['الرياضيات','اللغة العربية','اللغة الإنجليزية','العلوم','التربية الإسلامية','الفيزياء','الكيمياء','الأحياء','الاجتماعيات','الحاسوب','الفنية','الرياضة'];
const grades = ['الأول الابتدائي','الثاني الابتدائي','الثالث الابتدائي','الرابع الابتدائي','الخامس الابتدائي','السادس الابتدائي','الأول المتوسط','الثاني المتوسط','الثالث المتوسط','الرابع الإعدادي','الخامس الإعدادي','السادس الإعدادي'];
const days = ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس'];
int _sequence=0;
String uid() => "${DateTime.now().microsecondsSinceEpoch}-${_sequence++}";
String str(Item m,String k,[String fallback='']) => m[k]?.toString() ?? fallback;
List<Item> items(dynamic x) => (x is List ? x : const []).whereType<Map>().map((m)=>Map<String,dynamic>.from(m)).toList();
Item copy(Item x)=>Map<String,dynamic>.from(jsonDecode(jsonEncode(x)) as Map);
Item question()=>{'id':uid(),'text':'','mark':10,'answer':'','elements':<Item>[]};
Item exam([String subject='الرياضيات',String title='امتحان الشهر الأول',String grade='السادس الابتدائي'])=>{'id':uid(),'title':title,'subject':subject,'grade':grade,'school':'','duration':'ساعة واحدة','footer':'','questions':[question()],'size':'A4','orientation':'عمودي','font':'متوسط','margin':'عادية','color':false,'numbering':'س','answerLines':1};
double average(num a,num b)=>(a+b)/2;
int score(String text)=> (int.tryParse(text)??0).clamp(0,100).toInt();
class Store {
  Store(this.file);
  final File file;
  Item data=empty();
  Future<void> _pending=Future.value();
  static Item empty()=>{'version':1,'dark':false,'exams':[],'bank':[],'books':[],'plans':[],'schedule':[],'audio':[],'elements':[]};
  static Future<Store> open() async {
    final dir=await getApplicationDocumentsDirectory();
    final s=Store(File('${dir.path}/muallim.json'));
    if(await s.file.exists()) { try {s.data=validate(jsonDecode(await s.file.readAsString()));} catch (_) { final corrupt=File('${s.file.path}.corrupt-${uid()}'); await s.file.copy(corrupt.path); } }
    return s;
  }
  static Item validate(dynamic x) {
    if(x is! Map || x['version']!=1) throw const FormatException('نسخة غير متوافقة');
    final result=empty();
    for(final k in ['exams','bank','books','plans','schedule','audio','elements']) { if(x[k] is! List || (x[k] as List).any((v)=>v is! Map)) throw FormatException('حقل غير صالح: $k'); result[k]=items(x[k]); }
    result['dark']=x['dark']==true;
    return result;
  }
  List<Item> list(String key)=>items(data[key]);
  Future<void> save(){final snapshot=jsonEncode(data); final next=_pending.catchError((Object _){}).then((_)async{final temp=File('${file.path}.tmp');await temp.writeAsString(snapshot,flush:true);await temp.rename(file.path);});_pending=next;return next;}
  Future<void> put(String key,Item value) {final l=list(key); final i=l.indexWhere((v)=>v['id']==value['id']); if(i<0){l.insert(0,copy(value));}else{l[i]=copy(value);}data[key]=l;return save();}
  Future<void> remove(String key,String id){data[key]=list(key)..removeWhere((v)=>v['id']==id);return save();}
}
