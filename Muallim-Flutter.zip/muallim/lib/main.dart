import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:path_provider/path_provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'data.dart';
import 'ui.dart';
import 'tools.dart';
import 'exams.dart';
import 'records.dart';
Future<void> main()async{WidgetsFlutterBinding.ensureInitialized();try{final store=await Store.open();runApp(Muallim(store));}catch(e){runApp(MaterialApp(home:Scaffold(body:Center(child:Text('تعذر فتح مخزن البيانات: $e')))));}}
class Muallim extends StatefulWidget{const Muallim(this.store,{super.key});final Store store;@override State<Muallim> createState()=>_MuallimState();}
class _MuallimState extends State<Muallim>{Future<void> toggle()async{setState(()=>widget.store.data['dark']=widget.store.data['dark']!=true);await widget.store.save();}@override Widget build(BuildContext c)=>MaterialApp(title:'مساعد المعلم',debugShowCheckedModeBanner:false,locale:const Locale('ar'),supportedLocales:const [Locale('ar'),Locale('en')],localizationsDelegates:GlobalMaterialLocalizations.delegates,theme:appTheme(false),darkTheme:appTheme(true),themeMode:widget.store.data['dark']==true?ThemeMode.dark:ThemeMode.light,home:Home(widget.store,toggle));}
class Home extends StatefulWidget{const Home(this.store,this.toggle,{super.key});final Store store;final Future<void> Function() toggle;@override State<Home> createState()=>_HomeState();}
class _HomeState extends State<Home>{int tab=0;Store get s=>widget.store;
 Future<void> route(Widget w)async{await open(context,w);if(mounted)setState((){});}
 Future<void> tool(Widget w)async{final x=await open<Item>(context,w);if(x!=null){await s.put('elements',x);if(mounted){toast(context,'حُفظ العنصر في ملفاتي');setState((){});}}}
 Future<void> go(String key)async{switch(key){case 'exams':await route(ExamList(s));break;case 'bank':await route(BankPage(s));break;case 'formula':await tool(const FormulaPage());break;case 'draw':await tool(const DrawingPage());break;case 'table':await tool(const TablePage());break;case 'grades':await route(BooksPage(s));break;case 'plans':await route(PlansPage(s));break;case 'schedule':await route(SchedulePage(s));break;case 'audio':await route(AudioPage(s));break;case 'templates':await route(TemplatesPage(s));break;}}
 Widget hero(BuildContext c)=>Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xff0c5145),Color(0xff147b60)],begin:Alignment.topRight,end:Alignment.bottomLeft),borderRadius:BorderRadius.circular(27),boxShadow:const [BoxShadow(color:Color(0x25126b55),blurRadius:24,offset:Offset(0,9))]),child:Stack(children:[Positioned(left:-95,top:-60,child:Container(width:180,height:180,decoration:BoxDecoration(shape:BoxShape.circle,border:Border.all(color:Colors.white24)))),Positioned(left:-70,top:-85,child:Container(width:210,height:210,decoration:BoxDecoration(shape:BoxShape.circle,border:Border.all(color:Colors.white24)))),Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Container(width:46,height:46,decoration:BoxDecoration(color:Colors.white24,borderRadius:BorderRadius.circular(15)),child:const Icon(Icons.school_outlined,color:Colors.white,size:28)),const SizedBox(width:10),const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('مساعد المعلم',style:TextStyle(color:Colors.white,fontWeight:FontWeight.bold)),Text('مساحتك التعليمية المتكاملة',style:TextStyle(color:Color(0xffcae9df),fontSize:11))])),IconButton(tooltip:'حصص اليوم',style:IconButton.styleFrom(backgroundColor:Colors.white12,foregroundColor:Colors.white),onPressed:()=>route(TodayPage(s)),icon:const Icon(Icons.notifications_none)),IconButton(tooltip:'تبديل المظهر',style:IconButton.styleFrom(backgroundColor:Colors.white12,foregroundColor:Colors.white),onPressed:widget.toggle,icon:Icon(s.data['dark']==true?Icons.light_mode_outlined:Icons.dark_mode_outlined))]),const SizedBox(height:20),const Text('أدواتك، في مكان واحد.',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold,color:Colors.white)),const SizedBox(height:4),const Text('صمّم امتحاناتك ونظّم دروسك بكل سهولة.',style:TextStyle(color:Color(0xffd1eee4),fontSize:13)),const SizedBox(height:15),SizedBox(width:double.infinity,child:FilledButton.icon(style:FilledButton.styleFrom(backgroundColor:Colors.white,foregroundColor:green),onPressed:()=>route(ExamEditor(s,exam())),icon:const Icon(Icons.add_circle_outline),label:const Text('إنشاء ورقة امتحانية',style:TextStyle(fontWeight:FontWeight.bold))))])]));
 Widget stat(BuildContext c,String n,String label)=>Expanded(child:panel(c,Column(children:[Text(n,style:TextStyle(fontWeight:FontWeight.bold,fontSize:22,color:accent(c))),Text(label,style:const TextStyle(fontSize:11))]),padding:const EdgeInsets.symmetric(horizontal:4,vertical:10)));
 List<Widget> home(BuildContext c)=>[hero(c),const SizedBox(height:12),Row(children:[stat(c,'${s.list('exams').length}','أوراق امتحانية'),const SizedBox(width:7),stat(c,'${s.list('bank').length}','أسئلة محفوظة'),const SizedBox(width:7),stat(c,'${s.list('plans').length}','خطط دراسية')]),heading('أدواتي التعليمية'),LayoutBuilder(builder: (ctx, box) {
   final columns = box.maxWidth > 650 ? 3 : (box.maxWidth < 240 ? 1 : 2);
   Widget card(Module m) => Material(
     key: ValueKey('home-tool-${m.key}'),
     color: Theme.of(c).cardColor,
     borderRadius: BorderRadius.circular(20),
     child: InkWell(
       borderRadius: BorderRadius.circular(20),
       onTap: () => go(m.key),
       child: Container(
         constraints: const BoxConstraints(minHeight: 148),
         padding: const EdgeInsets.all(13),
         decoration: BoxDecoration(
           border: Border.all(color: Theme.of(c).dividerColor),
           borderRadius: BorderRadius.circular(20),
         ),
         child: Column(
           crossAxisAlignment: CrossAxisAlignment.start,
           mainAxisAlignment: MainAxisAlignment.spaceBetween,
           children: [
             Column(
               mainAxisSize: MainAxisSize.min,
               crossAxisAlignment: CrossAxisAlignment.start,
               children: [
                 bubble(c, m),
                 const SizedBox(height: 7),
                 Text(m.title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                 const SizedBox(height: 2),
                 Text(m.desc, style: Theme.of(c).textTheme.bodySmall?.copyWith(fontSize: 11)),
               ],
             ),
             Padding(
               padding: const EdgeInsets.only(top: 6),
               child: Align(alignment: Alignment.centerLeft, child: Icon(Icons.chevron_left, size: 16, color: Theme.of(c).colorScheme.outline)),
             ),
           ],
         ),
       ),
     ),
   );
   // Equal heights within each row, determined by its tallest content.
   // No fixed maximum height, clipping, or nested scrolling grid.
   return Column(
     key: const ValueKey('home-tools-grid'),
     mainAxisSize: MainAxisSize.min,
     children: [
       for (int i = 0; i < modules.length; i += columns) ...[
         if (i > 0) const SizedBox(height: 10),
         IntrinsicHeight(
           child: Row(
             crossAxisAlignment: CrossAxisAlignment.stretch,
             children: [
               for (int j = 0; j < columns; j++) ...[
                 if (j > 0) const SizedBox(width: 10),
                 Expanded(child: i + j < modules.length ? card(modules[i + j]) : const SizedBox.shrink()),
               ],
             ],
           ),
         ),
       ],
     ],
   );
 }),heading('آخر الأوراق',action:'عرض الكل',onTap:()=>setState(()=>tab=1)),if(s.list('exams').isEmpty)empty(c,'لم تنشئ ورقة امتحانية بعد'),for(final e in s.list('exams').take(2))rowCard(c,modules[0],str(e,'title'),'${e['subject']} • ${e['grade']}',()=>route(ExamEditor(s,e)))];
 Future<void> backup()async{try{final dir=await getTemporaryDirectory();final f=File('${dir.path}/muallim-backup-${uid()}.json');await f.writeAsString(jsonEncode(s.data));await Share.shareXFiles([XFile(f.path)],text:'نسخة احتياطية من مساعد المعلم');}catch(e){if(mounted)toast(context,'تعذر التصدير: $e');}}
 Future<void> restore()async{try{final r=await FilePicker.platform.pickFiles(type:FileType.custom,allowedExtensions:['json'],withData:true);if(r==null)return;final f=r.files.single;final raw=f.bytes??await File(f.path!).readAsBytes();final data=Store.validate(jsonDecode(utf8.decode(raw)));if(!mounted)return;if(!await confirm(context,'استبدال جميع البيانات الحالية بالنسخة الاحتياطية؟'))return;final darkChanged=data['dark']!=s.data['dark'];final oldDark=s.data['dark'];s.data=data;if(darkChanged){s.data['dark']=oldDark;await widget.toggle();}else{await s.save();}if(mounted){setState((){});toast(context,'تم استرجاع البيانات');}}catch(e){if(mounted)toast(context,'تعذر الاستيراد: $e');}}
 List<Widget> files(BuildContext c)=>[banner(c,'ملفاتك منظمة','الوصول إلى جميع أعمالك من مكان واحد'),rowCard(c,modules[0],'أوراق الامتحانات','${s.list('exams').length} ورقة',()=>setState(()=>tab=1)),rowCard(c,modules[5],'الخطط المحفوظة','${s.list('plans').length} خطة',()=>go('plans')),rowCard(c,modules[4],'سجلات الدرجات','${s.list('books').length} سجل',()=>go('grades')),rowCard(c,modules[7],'التسجيلات الصوتية','${s.list('audio').length} تسجيل',()=>go('audio')),rowCard(c,modules[2],'العناصر المحفوظة','${s.list('elements').length} عنصر',()=>route(ElementLibrary(s))),heading('النسخ الاحتياطي'),action('تصدير نسخة احتياطية',Icons.backup_outlined,backup),const SizedBox(height:9),action('استرجاع نسخة احتياطية',Icons.restore,restore)];
 List<Widget> settings(BuildContext c)=>[heading('المظهر'),panel(c,SwitchListTile(contentPadding:EdgeInsets.zero,secondary:const Icon(Icons.dark_mode_outlined),title:const Text('الوضع الليلي'),value:s.data['dark']==true,onChanged:(_)=>widget.toggle())),panel(c,const ListTile(contentPadding:EdgeInsets.zero,leading:Icon(Icons.language),title:Text('اللغة'),trailing:Text('العربية'))),heading('البيانات'),rowCard(c,modules[0],'النسخ الاحتياطي','تصدير البيانات واسترجاعها',()=>setState(()=>tab=2)),panel(c,const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('حول التطبيق',style:TextStyle(fontWeight:FontWeight.bold)),SizedBox(height:8),Text('مساعد المعلم • الإصدار 1.0.4\nتطبيق تعليمي موحد يعمل محلياً. تعتمد خدمة الإملاء على إمكانات الهاتف.')]))];
 @override Widget build(BuildContext c){final nav=NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),destinations:const [NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'الرئيسية'),NavigationDestination(icon:Icon(Icons.description_outlined),selectedIcon:Icon(Icons.description),label:'أوراقي'),NavigationDestination(icon:Icon(Icons.folder_outlined),selectedIcon:Icon(Icons.folder),label:'ملفاتي'),NavigationDestination(icon:Icon(Icons.settings_outlined),selectedIcon:Icon(Icons.settings),label:'الإعدادات')]);if(tab==1)return Scaffold(body:SafeArea(child:ExamList(s)),bottomNavigationBar:nav);return Scaffold(appBar:tab==0?null:AppBar(title:Text(tab==2?'ملفاتي':'الإعدادات',style:const TextStyle(fontWeight:FontWeight.bold))),bottomNavigationBar:nav,body:SafeArea(child:Align(alignment:Alignment.topCenter,child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:760),child:ListView(key:ValueKey('home-tab-$tab'),padding:const EdgeInsets.fromLTRB(16,14,16,28),children:tab==0?home(c):tab==2?files(c):settings(c))))));}}
class TodayPage extends StatelessWidget{const TodayPage(this.store,{super.key});final Store store;@override Widget build(BuildContext c){final d=DateTime.now().weekday%7;final list=store.list('schedule').where((x)=>x['day']==d).toList()..sort((a,b)=>(a['period'] as int).compareTo(b['period'] as int));return Frame(title:'حصص اليوم',subtitle:d<days.length?days[d]:'عطلة نهاية الأسبوع',children:[if(list.isEmpty)empty(c,'لا توجد حصص مسجلة لهذا اليوم'),for(final x in list)rowCard(c,modules[6],'الحصة ${x['period']} • ${x['subject']}','${x['grade']} ${x['section']} • ${x['time']}',()=>open(c,SchedulePage(store)))]);}}
