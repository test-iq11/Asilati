import 'dart:convert';
import 'dart:typed_data';
import 'data.dart';
import 'pdf_service.dart';

// OOXML package, with editable Unicode text and tables and embedded image elements.
String xml(String s)=>s.replaceAll(RegExp(r'[\x00-\x08\x0B\x0C\x0E-\x1F]'),'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&apos;');
const _w='http://schemas.openxmlformats.org/wordprocessingml/2006/main';
const _r='http://schemas.openxmlformats.org/officeDocument/2006/relationships';
const _rels='http://schemas.openxmlformats.org/package/2006/relationships';
const _decl='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
int _crc(List<int> bytes){var c=0xffffffff;for(final b in bytes){c^=b;for(int j=0;j<8;j++){c=(c&1)!=0?(c>>1)^0xedb88320:c>>1;}}return (c^0xffffffff)&0xffffffff;}
void _short(BytesBuilder b,int n){b.add([n&255,(n>>8)&255]);}
void _long(BytesBuilder b,int n){b.add([n&255,(n>>8)&255,(n>>16)&255,(n>>24)&255]);}
Uint8List zipPackage(Map<String,List<int>> files){final out=BytesBuilder(),central=BytesBuilder();for(final f in files.entries){final name=utf8.encode(f.key),data=f.value,crc=_crc(data),offset=out.length;
 _long(out,0x04034b50);for(final n in [20,0x800,0,0,33]){_short(out,n);}for(final n in [crc,data.length,data.length]){_long(out,n);}_short(out,name.length);_short(out,0);out.add(name);out.add(data);
 _long(central,0x02014b50);for(final n in [20,20,0x800,0,0,33]){_short(central,n);}for(final n in [crc,data.length,data.length]){_long(central,n);}for(final n in [name.length,0,0,0,0]){_short(central,n);}_long(central,0);_long(central,offset);central.add(name);
 }final start=out.length,len=central.length;out.add(central.takeBytes());_long(out,0x06054b50);for(final n in [0,0,files.length,files.length]){_short(out,n);}_long(out,len);_long(out,start);_short(out,0);return out.takeBytes();}
Uint8List examWord(Item e,{bool answers=false}){
 final files=<String,List<int>>{};void put(String name,String content)=>files[name]=utf8.encode(_decl+content);
 final size=(examFontSize(e)*2).round(),format=examFormat(e),margin=(examMargin(e)+4)*20;final width=(format.width*20).round(),height=(format.height*20).round(),inside=width-margin.round()*2;
 final ink=e['color']==true?'354C94':'000000';final mediaRels=<String>[];int imageId=0;
 String para(String text,{String align='right',bool bold=false,int? fontSize,bool line=false,int indent=0})=>'<w:p><w:pPr><w:bidi/><w:jc w:val="$align"/><w:spacing w:before="0" w:after="45" w:line="270" w:lineRule="auto"/>${indent>0?'<w:ind w:right="$indent"/>':''}${line?'<w:pBdr><w:bottom w:val="single" w:sz="4" w:space="2" w:color="$ink"/></w:pBdr>':''}</w:pPr><w:r><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/><w:rtl/><w:sz w:val="${fontSize??size}"/><w:szCs w:val="${fontSize??size}"/>${bold?'<w:b/><w:bCs/>':''}</w:rPr>${text.split('\n').map((s)=>'<w:t xml:space="preserve">${xml(s)}</w:t>').join('<w:br/>')}</w:r></w:p>';
 String table(List<List<String>> rows,List<int> widths,{bool border=false}) {
 final borderValue=border?'single':'nil';
 final borders=['top','left','bottom','right','insideH','insideV'].map((k)=>'<w:$k w:val="$borderValue" w:sz="4" w:color="000000"/>').join();
 final grid=widths.map((n)=>'<w:gridCol w:w="$n"/>').join();
 final body=StringBuffer();
 for(final row in rows){body.write('<w:tr>');for(int i=0;i<row.length;i++){body.write('<w:tc><w:tcPr><w:tcW w:w="${widths[i]}" w:type="dxa"/></w:tcPr>${row[i]}</w:tc>');}body.write('</w:tr>');}
 return '<w:tbl><w:tblPr><w:tblW w:w="$inside" w:type="dxa"/><w:tblBorders>$borders</w:tblBorders><w:tblLayout w:type="fixed"/></w:tblPr><w:tblGrid>$grid</w:tblGrid>$body</w:tbl>';
 }

 String image(Item b){try{final bytes=base64Decode(str(b,'image'));if(bytes.length<12)return para(str(b,'text'));final png=bytes[0]==137&&bytes[1]==80,jpg=bytes[0]==255&&bytes[1]==216;if(!png&&!jpg)return para(str(b,'text'));final id=++imageId,ext=png?'png':'jpeg',path='media/image$id.$ext';files['word/$path']=bytes;mediaRels.add('<Relationship Id="rIdImage$id" Type="$_r/image" Target="$path"/>');final cy=b['type']=='formula'?420000:1250000;double ratio=2;if(png&&bytes.length>=24){final d=ByteData.sublistView(bytes);final h=d.getUint32(20),w=d.getUint32(16);if(h>0)ratio=w/h;}final cx=(cy*ratio).clamp(100000,inside*635).round();return '<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="$cx" cy="$cy"/><wp:docPr id="$id" name="Image $id"/><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic><pic:nvPicPr><pic:cNvPr id="$id" name="Image $id"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="rIdImage$id"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="$cx" cy="$cy"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>';}catch(_){return para(str(b,'text'));}}
 String element(Item b){if(b['type']=='pageBreak')return '<w:p><w:r><w:br w:type="page"/></w:r></w:p>';if(b['type']=='table'){final rows=(b['rows'] as List).map((r)=>(r as List).map((v)=>para(v.toString(),align:'center')).toList().reversed.toList()).toList();if(rows.isEmpty||rows.first.isEmpty)return '';return table(rows,List.filled(rows.first.length,inside~/rows.first.length),border:true);}if(str(b,'image').isNotEmpty)return image(b);return para(str(b,'text'));}
 String nodes(List<Item> qs,int depth){final out=StringBuffer();for(int i=0;i<qs.length;i++){final q=qs[i],children=items(q['children']),mark=markLabel(e,q);final line=para('${questionLabel(q,i,depth,str(e,'numbering','س'))} ${str(q,'text')}',indent:depth*180);if(mark.isEmpty){out.write(line);}else{out.write(table([[para(mark,align:'left',fontSize:size-2),line]],[1200,inside-1200]));}for(final b in items(q['elements'])){out.write(element(b));}if(children.isNotEmpty)out.write(nodes(children,depth+1));if(answers&&str(q,'answer').isNotEmpty)out.write(para(str(q,'answer')));else if(!answers&&children.isEmpty)for(int n=0;n<(e['answerLines'] as int? ?? 0);n++){out.write(para(' ',line:true));}if(depth==0&&e['separator']!=false)out.write(para('',line:true,fontSize:6));}return out.toString();}
 final one=inside~/4;final header=table([[para(examDetails(e),align:'center',fontSize:22),para(examHeading(e,answers:answers),align:'center',fontSize:24,bold:true),para(schoolHeading(e),align:'center',fontSize:22)]],[one,inside-one*2,one]);
 final body=header+para('',line:true,fontSize:6)+(str(e,'notes').isNotEmpty?para(str(e,'notes'),bold:true):'')+nodes(items(e['questions']),0);
 final footer=(str(e,'footer').isNotEmpty?para(str(e,'footer'),align:'center'):'')+para(signature(e),align:'left',fontSize:22,bold:true)+(e['pageNumbers']==true?'<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:fldSimple w:instr="PAGE"/></w:p>':'');
 final border=e['frame']==true?'<w:pgBorders w:offsetFrom="page">${['top','left','bottom','right'].map((s)=>'<w:$s w:val="single" w:sz="10" w:space="18" w:color="$ink"/>').join()}</w:pgBorders>':'';
 put('word/document.xml','<w:document xmlns:w="$_w" xmlns:r="$_r" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><w:body>$body<w:sectPr><w:footerReference w:type="default" r:id="rIdFooter"/><w:pgSz w:w="$width" w:h="$height"${str(e,'orientation')=='أفقي'?' w:orient="landscape"':''}/><w:pgMar w:top="${margin.round()}" w:right="${margin.round()}" w:bottom="1000" w:left="${margin.round()}" w:header="360" w:footer="420" w:gutter="0"/>$border</w:sectPr></w:body></w:document>');
 put('word/footer1.xml','<w:ftr xmlns:w="$_w">$footer</w:ftr>');
 put('_rels/.rels','<Relationships xmlns="$_rels"><Relationship Id="rId1" Type="$_r/officeDocument" Target="word/document.xml"/></Relationships>');
 put('word/_rels/document.xml.rels','<Relationships xmlns="$_rels"><Relationship Id="rIdFooter" Type="$_r/footer" Target="footer1.xml"/>${mediaRels.join()}</Relationships>');
 put('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/><Default Extension="jpeg" ContentType="image/jpeg"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/></Types>');
 return zipPackage(files);
}
