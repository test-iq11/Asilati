import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/material.dart';
import 'package:muallim/data.dart';
import 'package:muallim/main.dart';
void main(){testWidgets('single home tool collection and four navigation destinations',(tester)async{final store=Store(File('/tmp/muallim-widget-test.json'));await tester.pumpWidget(Muallim(store));await tester.pumpAndSettle();expect(find.byType(NavigationDestination),findsNWidgets(4));expect(find.text('الأدوات'),findsNothing);expect(find.text('أدواتي التعليمية'),findsOneWidget);expect(tester.takeException(),isNull);});}
