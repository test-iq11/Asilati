import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/material.dart';
import 'package:muallim/data.dart';
import 'package:muallim/main.dart';
import 'package:muallim/ui.dart';

void main() {
  for (final size in [const Size(320, 640), const Size(360, 640), const Size(800, 600)]) {
    testWidgets('single home tool collection and four navigation destinations at $size', (tester) async {
      tester.view.devicePixelRatio = 1;
      tester.view.physicalSize = size;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final store = Store(File('${Directory.systemTemp.path}/muallim-widget-${size.width}.json'));
      await tester.pumpWidget(Muallim(store));
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull, reason: 'Initial home layout must not overflow');
      final nav = find.byType(NavigationBar);
      expect(nav, findsOneWidget);
      final bar = tester.widget<NavigationBar>(nav);
      expect(bar.destinations.whereType<NavigationDestination>().map((d) => d.label).toList(),
        ['الرئيسية', 'أوراقي', 'ملفاتي', 'الإعدادات']);
      expect(find.byType(NavigationDestination), findsNWidgets(4));
      expect(find.text('الأدوات'), findsNothing);
      final outer = find.descendant(of: find.byKey(const ValueKey('home-tab-0')), matching: find.byType(Scrollable)).first;
      await tester.scrollUntilVisible(find.text('مساحة العمل'), 120, scrollable: outer);
      await tester.pumpAndSettle();
      expect(find.text('مساحة العمل'), findsOneWidget);
      final gridFinder = find.byKey(const ValueKey('home-tools-grid'));
      await tester.scrollUntilVisible(gridFinder, 120, scrollable: outer);
      await tester.pumpAndSettle();
      expect(gridFinder, findsOneWidget);
      final cards = find.descendant(of: gridFinder, matching: find.byWidgetPredicate(
        (widget) => widget is Material && widget.key is ValueKey<String> &&
          (widget.key! as ValueKey<String>).value.startsWith('home-tool-'),
      ));
      final homeModules=[modules[0],modules[1],modules[8],modules[4],modules[5],modules[6],modules[7]];
      expect(cards, findsNWidgets(homeModules.length));
      expect(cards.evaluate().map((e) => e.widget.key).toSet(),
        homeModules.map((m) => ValueKey('home-tool-${m.key}')).toSet());
      final lastCard = find.byKey(ValueKey('home-tool-${homeModules.last.key}'));
      await tester.scrollUntilVisible(lastCard, 120, scrollable: outer);
      await tester.pumpAndSettle();
      expect(lastCard.hitTestable(), findsOneWidget);
      expect(tester.takeException(), isNull, reason: 'Tool grid must not overflow');
      for (final entry in [(1, 'أوراقي', 'ورقة امتحانية جديدة'), (2, 'ملفاتي', 'ملفاتك منظمة'), (3, 'الإعدادات', 'الوضع الليلي')]) {
        await tester.tap(find.descendant(of: nav, matching: find.text(entry.$2)));
        await tester.pumpAndSettle();
        expect(tester.widget<NavigationBar>(nav).selectedIndex, entry.$1);
        expect(find.text(entry.$3), findsOneWidget);
        expect(tester.takeException(), isNull, reason: 'Tab ${entry.$2} must not throw');
      }
      await tester.tap(find.descendant(of: nav, matching: find.text('الرئيسية')));
      await tester.pumpAndSettle();
      expect(tester.widget<NavigationBar>(nav).selectedIndex, 0);
      expect(tester.takeException(), isNull);
    });
  }
}
