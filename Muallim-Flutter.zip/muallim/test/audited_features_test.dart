import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:muallim/data.dart';
import 'package:muallim/audit_fields.dart';
import 'package:muallim/pdf_service.dart';
import 'package:muallim/word_service.dart';
import 'package:muallim/tools.dart' show chemistryTex, balancedFormula;
import 'export_test.dart' show storedZip;

void main(){
  TestWidgetsFlutterBinding.ensureInitialized();
  test('required alternatives expose a range, hidden nodes and section headings do not count',(){
    final e=exam()..['required']=2;
    final qs=[question()..['mark']=8,question()..['mark']=3,question()..['mark']=15,question()..addAll({'mark':100,'visible':false}),question()..addAll({'mark':0,'nodeKind':'section'})];
    expect(markRange(e,qs),(11,23));
    expect(markRangeText(e,qs),'11 – 23');
  });
  test('all 21 fields use a shared visibility model without deleting text',(){
    final e=exam()..addAll({'school':'SCHOOL_SECRET','teacherName':'TEACHER_SECRET','title':'TITLE_SECRET','notes':'NOTE_SECRET','footer':'FOOTER_SECRET'});
    expect(paperFields,hasLength(21));
    for(final f in paperFields){setPaperShown(e,f.$1,false);expect(paperShown(e,f.$1),isFalse);}
    expect(e['school'],'SCHOOL_SECRET');
    expect(schoolHeading(e),isEmpty);expect(examHeading(e),isEmpty);expect(examDetails(e),isEmpty);expect(signature(e),isEmpty);
    final parts=storedZip(examWord(e));
    final content=utf8.decode(parts['word/document.xml']!)+utf8.decode(parts['word/footer1.xml']!);
    for(final v in ['SCHOOL_SECRET','TEACHER_SECRET','TITLE_SECRET','NOTE_SECRET','FOOTER_SECRET']){expect(content,isNot(contains(v)));}
  });
  test('answer content cannot leak via a rich answer element into student Word',(){
    final q=question()..addAll({'text':'VISIBLE_QUESTION','answer':'ANSWER_ONLY'});
    q['elements']=[{'id':uid(),'type':'text','kind':'نموذج الإجابة','text':'RICH_SECRET','runs':[{'text':'RICH_SECRET'}]}];
    q['answerElements']=[{'id':uid(),'type':'text','kind':'نص منسق','text':'SCIENCE_SECRET'}];
    final e=exam()..['questions']=[q];
    String output(bool answers)=>utf8.decode(storedZip(examWord(e,answers:answers))['word/document.xml']!);
    expect(output(false),contains('VISIBLE_QUESTION'));
    for(final v in ['ANSWER_ONLY','RICH_SECRET','SCIENCE_SECRET']){expect(output(false),isNot(contains(v)));expect(output(true),contains(v));}
  });
  test('inline formatting survives Word output in document order',(){
    final q=question()..['inlineRuns']=[{'text':'LEFT_PART '},{'text':'BOLD_PART','bold':true},{'text':' RIGHT_PART','underline':true}];
    final e=exam()..['questions']=[q];
    final doc=utf8.decode(storedZip(examWord(e))['word/document.xml']!);
    expect(doc.indexOf('LEFT_PART'),lessThan(doc.indexOf('BOLD_PART')));expect(doc.indexOf('BOLD_PART'),lessThan(doc.indexOf('RIGHT_PART')));
    expect(doc,contains('<w:b/>'));expect(doc,contains('<w:u w:val="single"/>'));
  });
  test('basic chemistry conversion and brace checking',(){
    expect(chemistryTex('2H2O'),r'2H_{2}O');expect(chemistryTex('H2SO4'),r'H_{2}SO_{4}');
    expect(balancedFormula(r'\frac{1}{2}'),isTrue);expect(balancedFormula(r'\frac{1}{2'),isFalse);
  });
  testWidgets('visibility checkbox toggles value but preserves school name',(tester)async{
    final e=exam()..['school']='مدرسة اختبار';
    await tester.pumpWidget(MaterialApp(home:Scaffold(body:SingleChildScrollView(child:PaperVisibility(e)))));
    expect(find.byType(CheckboxListTile),findsNWidgets(21));
    final tile=find.widgetWithText(CheckboxListTile,'اسم المدرسة');await tester.ensureVisible(tile);await tester.tap(tile);await tester.pumpAndSettle();
    expect(paperShown(e,'school'),isFalse);expect(e['school'],'مدرسة اختبار');
  });
}
