import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:muallim/data.dart';
import 'package:muallim/exams.dart';
import 'package:muallim/pdf_service.dart';
import 'package:muallim/word_service.dart';

Map<String,Uint8List> storedZip(Uint8List bytes){final data=ByteData.sublistView(bytes);final result=<String,Uint8List>{};int pos=0;while(pos+30<=bytes.length&&data.getUint32(pos,Endian.little)==0x04034b50){final size=data.getUint32(pos+18,Endian.little),n=data.getUint16(pos+26,Endian.little),x=data.getUint16(pos+28,Endian.little);final name=utf8.decode(bytes.sublist(pos+30,pos+30+n));final start=pos+30+n+x;result[name]=bytes.sublist(start,start+size);pos=start+size;}return result;}
void main(){TestWidgetsFlutterBinding.ensureInitialized();
 test('all ten templates are exams and contain no school or teacher names',()async{final templates=await loadTemplates();expect(templates,hasLength(10));for(final original in templates){final e=cleanTemplate(original);expect(e['school'],'');expect(e['teacherName'],'');expect(items(e['questions']),isNotEmpty);final d=Store.empty()..['exams']=[e];expect(Store.validate(d)['exams'],hasLength(1));}});
 test('Word export includes editable questions, blank identity and correct package parts',()async{final template=(await loadTemplates()).first;final e=cleanTemplate(template);e['title']='اختبار & مراجعة';final files=storedZip(examWord(e));expect(files.keys,containsAll(['[Content_Types].xml','_rels/.rels','word/document.xml','word/footer1.xml','word/_rels/document.xml.rels']));final doc=utf8.decode(files['word/document.xml']!);expect(doc,contains('اختبار &amp; مراجعة'));expect(doc,contains('إدارة مدرسة'));expect(doc,contains('w:pgBorders'));expect(doc,contains('أجب عن الأسئلة'));expect(utf8.decode(files['word/footer1.xml']!),contains('معلم المادة'));});
 test('Arabic and mathematics samples produce valid PDF headers',()async{for(final t in (await loadTemplates()).take(2)){final bytes=await examPdf(cleanTemplate(t));expect(ascii.decode(bytes.take(5).toList()),'%PDF-');expect(bytes.length,greaterThan(1000));}});
 test('grade mean uses only entered scores',(){expect(studentMean({'first':80,'second':null,'mid':90}),85);expect(studentMean({}),isNull);});
 test('annual distribution spans months across new year and retains topics',(){final rows=distributeTopics('أ\nب\nج',11,2,2);expect(rows,hasLength(8));expect(rows.first['month'],11);expect(rows.last['month'],2);expect(rows.where((x)=>x['status']=='اعتيادي'),hasLength(3));});
 test('nested question marks are computed recursively',(){final q=question()..['children']=[question()..['mark']=6,question()..['mark']=4];expect(questionMark(q),10);});
}
