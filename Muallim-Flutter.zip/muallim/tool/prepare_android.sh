#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
# Generate the Android wrapper with the installed Flutter version; preserve authored source.
root="$PWD"
if [[ ! -f android/gradlew ]]; then
  tmp="$(mktemp -d)"
  trap 'rm -rf "$tmp"' EXIT
  flutter create --no-pub --platforms=android --org iq.teacher --project-name muallim "$tmp/muallim"
  cp -a "$tmp/muallim/android" "$root/"
  cp "$tmp/muallim/.metadata" "$root/"
fi
mkdir -p assets/fonts
if [[ ! -s assets/fonts/NotoNaskhArabic-Regular.ttf ]]; then
  curl --fail --location --retry 3 --output assets/fonts/NotoNaskhArabic-Regular.ttf 'https://raw.githubusercontent.com/notofonts/noto-fonts/main/hinted/ttf/NotoNaskhArabic/NotoNaskhArabic-Regular.ttf' || curl --fail --location --retry 3 --output assets/fonts/NotoNaskhArabic-Regular.ttf 'https://cdn.jsdelivr.net/gh/notofonts/notofonts.github.io/fonts/NotoNaskhArabic/hinted/ttf/NotoNaskhArabic-Regular.ttf'
  curl --fail --location --retry 3 --output assets/fonts/OFL.txt 'https://raw.githubusercontent.com/notofonts/noto-fonts/main/LICENSE' || true
fi
python3 - <<'PY'
from pathlib import Path
p=Path('android/app/src/main/AndroidManifest.xml');s=p.read_text();s=s.replace('android:label="muallim"','android:label="مساعد المعلم"')
permissions='''    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
'''
if 'android.permission.RECORD_AUDIO' not in s:s=s.replace('    <application',permissions+'    <application',1)
if 'android.speech.RecognitionService' not in s:s=s.replace('    <queries>', '    <queries>\n        <intent><action android:name="android.speech.RecognitionService" /></intent>',1)
s=s.replace('@mipmap/ic_launcher','@drawable/muallim_icon');p.write_text(s)
for p in [Path('android/app/build.gradle.kts'),Path('android/app/build.gradle')]:
 if p.exists():
  s=p.read_text().replace('minSdk = flutter.minSdkVersion','minSdk = 23').replace('minSdkVersion flutter.minSdkVersion','minSdkVersion 23')
  p.write_text(s)
# Original green vector icon, not an extracted icon from either app.
p=Path('android/app/src/main/res/drawable/muallim_icon.xml');p.parent.mkdir(parents=True,exist_ok=True);p.write_text('''<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">
<path android:fillColor="#126B55" android:pathData="M20,4 L88,4 Q104,4 104,20 L104,88 Q104,104 88,104 L20,104 Q4,104 4,88 L4,20 Q4,4 20,4Z"/>
<path android:fillColor="#E5F5EE" android:pathData="M27,22 L66,22 L81,37 L81,86 L27,86Z"/>
<path android:fillColor="#8ED3BA" android:pathData="M66,22 L81,37 L66,37Z"/>
<path android:strokeColor="#126B55" android:strokeWidth="4" android:strokeLineCap="round" android:pathData="M38,46 L67,46 M38,57 L58,57 M38,68 L52,68"/>
<path android:strokeColor="#126B55" android:strokeWidth="5" android:strokeLineCap="round" android:strokeLineJoin="round" android:pathData="M59,69 L65,75 L77,61"/>
</vector>''')
PY
