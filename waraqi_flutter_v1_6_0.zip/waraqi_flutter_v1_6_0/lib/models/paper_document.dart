import 'dart:convert';

/// Single source of truth for Arabic and Latin digits in editor, preview and print.
enum DigitStyle { arabic, english }

String formatDigits(Object? value, DigitStyle style) {
  final raw = '$value';
  const western = '0123456789';
  const eastern = '٠١٢٣٤٥٦٧٨٩';
  const persian = '۰۱۲۳۴۵۶۷۸۹';
  final target = style == DigitStyle.arabic ? eastern : western;
  return raw.split('').map((character) {
    var index = western.indexOf(character);
    if (index < 0) index = eastern.indexOf(character);
    if (index < 0) index = persian.indexOf(character);
    return index < 0 ? character : target[index];
  }).join();
}

/// Accept numeric input from both Arabic and English phone keyboards.
/// Discard non-finite numbers; they cannot be serialized safely as JSON.
double? parseLocalizedNumber(Object? value) {
  if(value==null) return null;
  final text = formatDigits(value, DigitStyle.english)
      .replaceAll('٫', '.')
      .replaceAll('٬', '')
      .trim();
  final result = double.tryParse(text);
  return result != null && result.isFinite ? result : null;
}

// Guard against collisions when many documents and image paths are generated
// within the same microsecond (e.g. importing a large question bank).
int _lastIdTimestamp = 0;
int _idSequence = 0;
String newId() {
  final now = DateTime.now().microsecondsSinceEpoch;
  if (now != _lastIdTimestamp) {
    _lastIdTimestamp = now;
    _idSequence = 0;
  }
  return '${now}_${_idSequence++}';
}

/// A printable, independently scored point inside a branch.
/// Old documents without this field retain their flat branches unchanged.
class PaperSubPoint {
  PaperSubPoint({required this.id, this.text = '', this.points = 0,
    this.answer = '', this.customNumber = '', this.visible = true});
  final String id;
  String text;
  double points;
  String answer;
  String customNumber;
  bool visible;
  Map<String, dynamic> toJson() => {
    'id': id, 'text': text, 'points': points, 'answer': answer,
    'customNumber': customNumber, 'visible': visible,
  };
  factory PaperSubPoint.fromJson(Map<String, dynamic> map) => PaperSubPoint(
    id: map['id']?.toString() ?? newId(),
    text: map['text']?.toString() ?? '',
    points: (parseLocalizedNumber(map['points']) ?? 0).clamp(0, 1000000).toDouble(),
    answer: map['answer']?.toString() ?? '',
    customNumber: map['customNumber']?.toString() ?? '',
    visible: map['visible'] != false,
  );
}

class PaperSignature {
  PaperSignature({required this.id, this.name = '', this.role = ''});
  final String id;
  String name;
  String role;
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'role': role};
  factory PaperSignature.fromJson(Map<String, dynamic> map) => PaperSignature(
    id: map['id']?.toString() ?? newId(),
    name: map['name']?.toString() ?? '',
    role: map['role']?.toString() ?? '',
  );
}

class PaperGridImage {
  PaperGridImage({required this.path, this.caption = ''});
  String path;
  String caption;
  Map<String, dynamic> toJson() => {'path': path, 'caption': caption};
  factory PaperGridImage.fromJson(Map<String, dynamic> map) => PaperGridImage(
    path: map['path']?.toString() ?? '', caption: map['caption']?.toString() ?? '',
  );
}

class PaperElement {
  PaperElement({required this.id, required this.kind, this.text = '', this.imagePath, this.caption = '', this.imageScale = 1, this.rotation = 0, List<PaperGridImage>? galleryImages}) : galleryImages = galleryImages ?? [];
  final String id;
  String kind;
  String text;
  String? imagePath;
  String caption;
  double imageScale;
  int rotation;
  final List<PaperGridImage> galleryImages;
  Map<String, dynamic> toJson() => {'id': id, 'kind': kind, 'text': text, 'imagePath': imagePath, 'caption': caption, 'imageScale': imageScale, 'rotation': rotation, 'galleryImages': galleryImages.map((e) => e.toJson()).toList()};
  factory PaperElement.fromJson(Map<String, dynamic> map) => PaperElement(
        id: map['id']?.toString() ?? newId(),
        kind: map['kind']?.toString() ?? 'text',
        text: map['text']?.toString() ?? '',
        imagePath: map['imagePath']?.toString(),
        caption: map['caption']?.toString() ?? '',
        imageScale: (parseLocalizedNumber(map['imageScale']) ?? 1).clamp(0.3, 1.0).toDouble(),
        rotation: ((parseLocalizedNumber(map['rotation']) ?? 0).round() % 4 + 4) % 4,
        galleryImages: (map['galleryImages'] as List<dynamic>? ?? [])
            .whereType<Map>().map((e) => PaperGridImage.fromJson(Map<String, dynamic>.from(e))).toList(),
      );
}

class PaperQuestion {
  PaperQuestion({required this.id, this.text = '', this.points = 5, this.answer = '', this.visible = true, this.type = 'essay', this.sectionTitle = '', this.pageBreakBefore = false, this.customNumber = '', this.requiredBranches = 0, this.useBranchPoints = false, this.tags = '', List<double>? branchPoints, List<List<PaperSubPoint>>? branchSubpoints, List<String>? branches, List<PaperElement>? elements})
      : branches = branches ?? [],
        elements = elements ?? [],
        branchPoints = branchPoints ?? [],
        branchSubpoints = branchSubpoints ?? [];
  final String id;
  String text;
  double points;
  String answer;
  bool visible;
  String type;
  String sectionTitle;
  bool pageBreakBefore;
  String customNumber;
  int requiredBranches;
  bool useBranchPoints;
  String tags;
  final List<double> branchPoints;
  final List<List<PaperSubPoint>> branchSubpoints;
  double effectiveBranchPoints(int index) {
    if (index < branchSubpoints.length && branchSubpoints[index].isNotEmpty) {
      return branchSubpoints[index].where((p) => p.visible)
          .fold<double>(0, (sum, p) => sum + p.points);
    }
    return index < branchPoints.length ? branchPoints[index] : 0;
  }
  double get effectivePoints => useBranchPoints && branches.isNotEmpty
      ? List.generate(branches.length, effectiveBranchPoints)
          .fold<double>(0, (sum, p) => sum + p) : points;
  final List<String> branches;
  final List<PaperElement> elements;

  /// A bank or duplicate operation must also assign new identities to nested
  /// points and elements, not just the parent question.
  PaperQuestion independentCopy() => PaperQuestion.fromJson({
    ...toJson(),
    'id': newId(),
    'elements': elements.map((e)=>{...e.toJson(),'id':newId()}).toList(),
    'branchSubpoints': branchSubpoints.map((items)=>
      items.map((point)=>{...point.toJson(),'id':newId()}).toList()).toList(),
  });

  /// OCR contributes editable text only; the photographed image is NOT added
  /// as an element. An empty recognition result never clears existing text.
  bool insertExtractedText(String recognized, {required bool append}) {
    final clean = recognized.replaceAll('\r\n', '\n').trim();
    if (clean.isEmpty) return false;
    text = append && text.trim().isNotEmpty ? '${text.trim()}\n$clean' : clean;
    return true;
  }

  Map<String, dynamic> toJson() => {
        'id': id, 'text': text, 'points': points, 'answer': answer, 'visible': visible,
        'type': type, 'sectionTitle': sectionTitle, 'pageBreakBefore': pageBreakBefore, 'customNumber': customNumber, 'requiredBranches': requiredBranches, 'useBranchPoints': useBranchPoints, 'tags': tags, 'branchPoints': branchPoints, 'branchSubpoints': branchSubpoints.map((items) => items.map((p) => p.toJson()).toList()).toList(), 'branches': branches, 'elements': elements.map((e) => e.toJson()).toList(),
      };
  factory PaperQuestion.fromJson(Map<String, dynamic> map) => PaperQuestion(
        id: map['id']?.toString() ?? newId(),
        text: map['text']?.toString() ?? '',
        points: (parseLocalizedNumber(map['points']) ?? 5).clamp(0,1000000).toDouble(),
        answer: map['answer']?.toString() ?? '',
        visible: map['visible'] != false,
        type: map['type']?.toString() ?? 'essay',
        sectionTitle: map['sectionTitle']?.toString() ?? '',
        pageBreakBefore: map['pageBreakBefore'] == true,
        customNumber: map['customNumber']?.toString() ?? '',
        requiredBranches: (parseLocalizedNumber(map['requiredBranches']) ?? 0).round().clamp(0, 50).toInt(),
        useBranchPoints: map['useBranchPoints'] == true,
        tags: map['tags']?.toString() ?? '',
        branchPoints: (map['branchPoints'] as List<dynamic>? ?? [])
            .map((e) => (parseLocalizedNumber(e) ?? 0).clamp(0, 1000000).toDouble()).toList(),
        branchSubpoints: (map['branchSubpoints'] as List<dynamic>? ?? []).whereType<List>()
            .map((items) => items.whereType<Map>().map((p) => PaperSubPoint.fromJson(Map<String, dynamic>.from(p))).toList()).toList(),
        branches: (map['branches'] as List<dynamic>? ?? []).map((e) => '$e').toList(),
        elements: (map['elements'] as List<dynamic>? ?? [])
            .whereType<Map>()
            .map((e) => PaperElement.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
      );
}

class PaperDocument {
  // Explicit unnamed constructor: the named fromJson factory suppresses Dart's
  // implicit default constructor. All new/load/decode paths rely on this.
  PaperDocument();

  String documentId = newId();
  String title = 'اختبار الرياضيات';
  String documentType = 'exam';
  String subject = 'الرياضيات';
  String grade = 'السادس الابتدائي';
  String country = 'جمهورية العراق';
  String ministry = 'وزارة التربية';
  String directorate = 'المديرية العامة للتربية';
  String school = 'مدرستي الابتدائية';
  String academicYear = '2026 - 2027';
  String date = '';
  String duration = '45 دقيقة';
  String term = 'الفصل الأول';
  String examLabel = 'امتحان يومي';
  String bismillah = 'بسم الله الرحمن الرحيم';
  String topNote = 'أجب عن جميع الأسئلة';
  String footerText = 'مع تمنياتنا لكم بالنجاح والتوفيق';
  String teacherName = '';
  String teacherRole = '';
  List<PaperSignature> signatures = [];
  String paperLanguage = 'ar';
  int coverDesign = 0;
  bool showQuestionWarnings = true;
  bool showSignatureLine = false;
  String signatureSide = 'left';
  bool includeCover = false;
  bool includeToc = false;
  String coverSubtitle = '';
  String bookletIntroduction = '';
  String questionNumbering = 'digits';
  String branchNumbering = 'digits';
  int questionSequenceStart = 1;
  int requiredQuestions = 0;
  String paperFontFamily = 'system';
  int headingColor = 0xFF17333D;
  int printAccentColor = 0xFF485F63;
  String questionSeparator = 'line';
  bool compactForOnePage = false;
  String? logoPath;
  DigitStyle digitStyle = DigitStyle.arabic;
  double total = 100;
  double topMarginMm = 8;
  double bottomMarginMm = 8;
  double sideMarginMm = 14;
  double headerGapMm = 6;
  double fontSize = 15;
  double lineSpacing = 1.45;
  double questionGap = 14;
  bool showRules = true;
  bool showGrades = true;
  bool showFooter = true;
  bool showPageNumbers = true;
  bool showHeaderLine = true;
  bool landscape = false;
  bool showLogo = true;
  bool showStudentNameField = true;
  bool showSectionField = true;
  String theme = 'teal';
  /// Printable final-result layout theme. `globalEmerald` matches the new premium default exam sheet.
  String paperLayout = 'globalEmerald';
  Set<String> headerFields = {'country','ministry','directorate','school','title','academicYear','subject','grade','total','date','duration'};
  List<PaperQuestion> questions = [PaperQuestion(id: 'sample-1', text: 'جد ناتج ما يأتي:', points: 10, branches: ['٤٥٫٦٧ × ١٠٠ =', '١٠٠ ÷ ٦٫٥ ='])];

  String digits(Object? value) => formatDigits(value, digitStyle);
  double get usedPoints => questions.where((q) => q.visible).fold(0, (sum, question) => sum + question.effectivePoints);

  Map<String, dynamic> toJson() => {
        'documentId':documentId,'title':title,'documentType':documentType,'subject':subject,'grade':grade,
        'country':country,'ministry':ministry,'directorate':directorate,'school':school,
        'academicYear':academicYear,'date':date,'duration':duration,'term':term,
        'examLabel':examLabel,'bismillah':bismillah,'topNote':topNote,
        'footerText':footerText,'teacherName':teacherName,'teacherRole':teacherRole,
        'signatures':signatures.map((e) => e.toJson()).toList(), 'paperLanguage':paperLanguage,
        'coverDesign':coverDesign,'showQuestionWarnings':showQuestionWarnings,
        'showSignatureLine':showSignatureLine,'signatureSide':signatureSide,
        'includeCover':includeCover,'includeToc':includeToc,'coverSubtitle':coverSubtitle,'bookletIntroduction':bookletIntroduction,
        'questionNumbering':questionNumbering,'branchNumbering':branchNumbering,
        'questionSequenceStart':questionSequenceStart,'requiredQuestions':requiredQuestions,'paperFontFamily':paperFontFamily,
        'headingColor':headingColor,'printAccentColor':printAccentColor,
        'questionSeparator':questionSeparator,'compactForOnePage':compactForOnePage,
        'logoPath':logoPath,'digitStyle':digitStyle.name,
        'total':total,'topMarginMm':topMarginMm,'bottomMarginMm':bottomMarginMm,
        'sideMarginMm':sideMarginMm,'headerGapMm':headerGapMm,'fontSize':fontSize,
        'lineSpacing':lineSpacing,'questionGap':questionGap,
        'showRules':showRules,'showGrades':showGrades,'showFooter':showFooter,
        'showPageNumbers':showPageNumbers,'showHeaderLine':showHeaderLine,
        'showLogo':showLogo,'showStudentNameField':showStudentNameField,'showSectionField':showSectionField,'landscape':landscape,'theme':theme,'paperLayout':paperLayout,
        'headerFields':headerFields.toList(), 'questions':questions.map((q)=>q.toJson()).toList(),
      };

  factory PaperDocument.fromJson(Map<String, dynamic> map) {
    final d = PaperDocument();
    final defaults = d.toJson();
    final merged = {...defaults, ...map};
    String s(String k) => merged[k]?.toString() ?? '';
    double n(String k) => parseLocalizedNumber(merged[k]) ?? 0;
    bool b(String k) => merged[k] == true;
    d.documentId=s('documentId').isEmpty ? newId() : s('documentId');
    d.title=s('title'); d.documentType=s('documentType'); d.subject=s('subject');
    d.grade=s('grade'); d.country=s('country'); d.ministry=s('ministry');
    d.directorate=s('directorate'); d.school=s('school'); d.academicYear=s('academicYear');
    d.date=s('date'); d.duration=s('duration'); d.term=s('term'); d.examLabel=s('examLabel');
    d.bismillah=s('bismillah'); d.topNote=s('topNote'); d.footerText=s('footerText');
    d.teacherName=s('teacherName'); d.teacherRole=s('teacherRole');
    d.signatures=(merged['signatures'] as List<dynamic>? ?? []).whereType<Map>()
        .map((e)=>PaperSignature.fromJson(Map<String,dynamic>.from(e))).toList();
    d.paperLanguage=s('paperLanguage')=='en'?'en':'ar';
    d.coverDesign=(parseLocalizedNumber(merged['coverDesign'])??0).round().clamp(0,19).toInt();
    d.showQuestionWarnings=merged['showQuestionWarnings']!=false;
    d.showSignatureLine=b('showSignatureLine'); d.signatureSide=s('signatureSide');
    d.includeCover=b('includeCover'); d.includeToc=b('includeToc');
    d.coverSubtitle=s('coverSubtitle'); d.bookletIntroduction=s('bookletIntroduction');
    d.questionNumbering=s('questionNumbering'); d.branchNumbering=s('branchNumbering');
    d.questionSequenceStart=n('questionSequenceStart').round().clamp(1, 9999).toInt();
    d.requiredQuestions=n('requiredQuestions').round().clamp(0, 1000).toInt();
    d.paperFontFamily=s('paperFontFamily');
    d.headingColor=(n('headingColor').toInt() == 0 ? 0xFF17333D : n('headingColor').toInt());
    d.printAccentColor=(n('printAccentColor').toInt() == 0 ? 0xFF485F63 : n('printAccentColor').toInt());
    d.questionSeparator=s('questionSeparator'); d.compactForOnePage=b('compactForOnePage');
    d.logoPath=merged['logoPath']?.toString(); d.theme=s('theme');
        const allowedLayouts = {
      'globalEmerald','royalBlue','sandGold','mintClassic','plumModern',
      'mathFrame','arabicLines'
    };
    final layout = s('paperLayout');
    d.paperLayout = allowedLayouts.contains(layout)
        ? layout
        : (layout == 'mathFrame' ? 'globalEmerald' : 'globalEmerald');
    d.digitStyle=s('digitStyle') == 'english' ? DigitStyle.english : DigitStyle.arabic;
    d.total=n('total'); d.topMarginMm=n('topMarginMm'); d.bottomMarginMm=n('bottomMarginMm');
    d.sideMarginMm=n('sideMarginMm'); d.headerGapMm=n('headerGapMm');
    d.fontSize=n('fontSize'); d.lineSpacing=n('lineSpacing'); d.questionGap=n('questionGap');
    d.showRules=b('showRules'); d.showGrades=b('showGrades'); d.showFooter=b('showFooter');
    d.showPageNumbers=b('showPageNumbers'); d.showHeaderLine=b('showHeaderLine');
    d.showLogo=b('showLogo'); d.showStudentNameField = merged.containsKey('showStudentNameField') ? b('showStudentNameField') : d.showStudentNameField; d.showSectionField = merged.containsKey('showSectionField') ? b('showSectionField') : d.showSectionField; d.landscape=b('landscape');
    d.headerFields=(merged['headerFields'] as List<dynamic>? ?? []).map((e)=>'$e').toSet();
    d.questions=(merged['questions'] as List<dynamic>? ?? []).whereType<Map>().map((q)=>PaperQuestion.fromJson(Map<String,dynamic>.from(q))).toList();
    return d;
  }
  String encode() => jsonEncode(toJson());
  static PaperDocument decode(String source) => PaperDocument.fromJson(Map<String,dynamic>.from(jsonDecode(source) as Map));
}
