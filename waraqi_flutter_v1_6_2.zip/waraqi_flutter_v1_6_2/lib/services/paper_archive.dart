import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/paper_document.dart';

/// A bank entry owns its own deep-copied question; modifying a copy inserted
/// into a paper never changes the original question in the bank.
class QuestionBankEntry {
  QuestionBankEntry({
    required this.id,
    required this.subject,
    required this.grade,
    required this.question,
    required this.savedAt,
  });

  final String id;
  final String subject;
  final String grade;
  final PaperQuestion question;
  final DateTime savedAt;

  Map<String, dynamic> toJson() => <String, dynamic>{
    'id': id,
    'subject': subject,
    'grade': grade,
    'savedAt': savedAt.toUtc().toIso8601String(),
    'question': question.toJson(),
  };

  factory QuestionBankEntry.fromJson(Map<String, dynamic> json) {
    final question = json['question'];
    if (question is! Map) {
      throw const FormatException('سؤال البنك غير صالح');
    }
    return QuestionBankEntry(
      id: json['id']?.toString() ?? newId(),
      subject: json['subject']?.toString() ?? '',
      grade: json['grade']?.toString() ?? '',
      question: PaperQuestion.fromJson(Map<String, dynamic>.from(question)),
      savedAt: DateTime.tryParse(json['savedAt']?.toString() ?? '') ?? DateTime.now(),
    );
  }
}

class PaperArchive {
  static const documentsKey = 'waraqi_saved_documents_v1';
  static const bankKey = 'waraqi_question_bank_v1';
  static const backupSchema = 'waraqi-backup-v1';

  Timer? _timer;

  static List<Map<String, dynamic>> _decodeList(String? source) {
    if (source == null) return [];
    final decoded = jsonDecode(source);
    if (decoded is! List) throw const FormatException('بيانات القائمة غير صالحة');
    return decoded
        .whereType<Map>()
        .map((value) => Map<String, dynamic>.from(value))
        .toList();
  }

  Future<List<PaperDocument>> documents() async {
    final prefs = await SharedPreferences.getInstance();
    return _decodeList(prefs.getString(documentsKey))
        .map(PaperDocument.fromJson)
        .toList();
  }

  Future<List<QuestionBankEntry>> bank() async {
    final prefs = await SharedPreferences.getInstance();
    return _decodeList(prefs.getString(bankKey))
        .map(QuestionBankEntry.fromJson)
        .toList();
  }

  Future<void> saveDocument(PaperDocument document) async {
    _timer?.cancel();
    final prefs = await SharedPreferences.getInstance();
    final docs = _decodeList(prefs.getString(documentsKey));
    final snapshot = document.toJson();
    final index = docs.indexWhere(
      (item) => item['documentId'] == document.documentId,
    );
    if (index == -1) {
      docs.insert(0, snapshot);
    } else {
      docs.removeAt(index);
      docs.insert(0, snapshot);
    }
    await prefs.setString(documentsKey, jsonEncode(docs));
  }

  void queueSave(PaperDocument document) {
    _timer?.cancel();
    // Snapshot immediately, so a later document switch cannot overwrite the
    // saved document by mutating the object referred to by the timer.
    final source = document.encode();
    _timer = Timer(const Duration(milliseconds: 650), () async {
      try {
        await saveDocument(PaperDocument.decode(source));
      } catch (_) {
        // The legacy auto-save remains independent. An explicit Save button
        // can be used if persistent storage is temporarily unavailable.
      }
    });
  }

  Future<void> removeDocument(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final docs = _decodeList(prefs.getString(documentsKey))
      ..removeWhere((item) => item['documentId'] == id);
    await prefs.setString(documentsKey, jsonEncode(docs));
  }

  Future<void> addToBank(
    PaperQuestion question, {
    required String subject,
    required String grade,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final entries = _decodeList(prefs.getString(bankKey));
    entries.insert(0, QuestionBankEntry(
      id: newId(),
      subject: subject,
      grade: grade,
      question: PaperQuestion.fromJson(question.toJson()),
      savedAt: DateTime.now(),
    ).toJson());
    await prefs.setString(bankKey, jsonEncode(entries));
  }

  Future<void> removeFromBank(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final entries = _decodeList(prefs.getString(bankKey))
      ..removeWhere((item) => item['id'] == id);
    await prefs.setString(bankKey, jsonEncode(entries));
  }

  /// A self-contained JSON backup: all local attachments are embedded as
  /// base64, and their paths are replaced with new local paths on import.
  Future<Uint8List> exportBackup() async {
    final docs = await documents();
    final entries = await bank();
    final imagePaths = <String>{};
    for (final document in docs) {
      if (document.logoPath != null) imagePaths.add(document.logoPath!);
      for (final question in document.questions) {
        for (final element in question.elements) {
          if (element.imagePath != null) imagePaths.add(element.imagePath!);
          for(final image in element.galleryImages){imagePaths.add(image.path);}
        }
      }
    }
    for (final entry in entries) {
      for (final element in entry.question.elements) {
        if (element.imagePath != null) imagePaths.add(element.imagePath!);
        for(final image in element.galleryImages){imagePaths.add(image.path);}
      }
    }
    final images = <String, String>{};
    for (final path in imagePaths) {
      final file = File(path);
      if (await file.exists()) {
        images[path] = base64Encode(await file.readAsBytes());
      }
    }
    return Uint8List.fromList(utf8.encode(jsonEncode(<String, dynamic>{
      'schema': backupSchema,
      'exportedAt': DateTime.now().toUtc().toIso8601String(),
      'documents': docs.map((doc) => doc.toJson()).toList(),
      'bank': entries.map((entry) => entry.toJson()).toList(),
      'images': images,
    })));
  }

  Future<int> importBackup(Uint8List bytes) async {
    if (bytes.length > 100 * 1024 * 1024) {
      throw const FormatException('النسخة الاحتياطية كبيرة جداً');
    }
    final root = jsonDecode(utf8.decode(bytes));
    if (root is! Map || root['schema'] != backupSchema ||
        root['documents'] is! List || root['bank'] is! List) {
      throw const FormatException('هذا الملف ليس نسخة احتياطية من ورقتي');
    }
    final importedDocs = (root['documents'] as List)
        .whereType<Map>()
        .map((item) => PaperDocument.fromJson(Map<String, dynamic>.from(item)))
        .toList();
    final importedEntries = (root['bank'] as List)
        .whereType<Map>()
        .map((item) => QuestionBankEntry.fromJson(Map<String, dynamic>.from(item)))
        .toList();
    // Validate before writing anything to storage. Existing documents are
    // never replaced; imported entries get independent identities.
    final oldImages = root['images'];
    if (oldImages != null && oldImages is! Map) {
      throw const FormatException('قسم الصور في النسخة الاحتياطية غير صالح');
    }
    final mapping = <String, String>{};
    if (oldImages is Map && oldImages.isNotEmpty) {
      final rootDir = await getApplicationDocumentsDirectory();
      final imageDir = Directory('${rootDir.path}/paper_images');
      if (!await imageDir.exists()) await imageDir.create(recursive: true);
      for (final entry in oldImages.entries) {
        final data = base64Decode(entry.value.toString());
        if (data.length > 20 * 1024 * 1024) {
          throw const FormatException('إحدى صور النسخة الاحتياطية كبيرة جداً');
        }
        final path = '${imageDir.path}/restored_${newId()}.${_imageExtension(data)}';
        await File(path).writeAsBytes(data, flush: true);
        mapping[entry.key.toString()] = path;
      }
    }
    for (final document in importedDocs) {
      document.documentId = newId();
      if (document.logoPath != null) {
        document.logoPath = mapping[document.logoPath];
      }
      for (final question in document.questions) {
        for (final element in question.elements) {
          if (element.imagePath != null) {
            element.imagePath = mapping[element.imagePath];
          }
          for(final image in element.galleryImages){
            image.path = mapping[image.path] ?? image.path;
          }
        }
      }
    }
    final prefs = await SharedPreferences.getInstance();
    final currentDocs = _decodeList(prefs.getString(documentsKey));
    final currentBank = _decodeList(prefs.getString(bankKey));
    for (final document in importedDocs) {
      currentDocs.insert(0, document.toJson());
    }
    for (final entry in importedEntries) {
      final question = PaperQuestion.fromJson(entry.question.toJson());
      for (final element in question.elements) {
        if (element.imagePath != null) {
          element.imagePath = mapping[element.imagePath];
        }
        for(final image in element.galleryImages){
          image.path = mapping[image.path] ?? image.path;
        }
      }
      currentBank.insert(0, QuestionBankEntry(
        id: newId(),
        subject: entry.subject,
        grade: entry.grade,
        question: question,
        savedAt: entry.savedAt,
      ).toJson());
    }
    await prefs.setString(documentsKey, jsonEncode(currentDocs));
    await prefs.setString(bankKey, jsonEncode(currentBank));
    return importedDocs.length;
  }

  // Backups may contain PNG/JPEG/WEBP images. Preserve their real type so
  // Word export does not label PNG bytes as JPEG and silently lose pictures.
  static String _imageExtension(Uint8List bytes) {
    if (bytes.length >= 8 && bytes[0] == 0x89 && bytes[1] == 0x50 &&
        bytes[2] == 0x4e && bytes[3] == 0x47) return 'png';
    if (bytes.length >= 3 && bytes[0] == 0xff && bytes[1] == 0xd8 &&
        bytes[2] == 0xff) return 'jpg';
    if (bytes.length >= 12 && bytes[0] == 0x52 && bytes[1] == 0x49 &&
        bytes[2] == 0x46 && bytes[3] == 0x46 && bytes[8] == 0x57 &&
        bytes[9] == 0x45 && bytes[10] == 0x42 && bytes[11] == 0x50) {
      return 'webp';
    }
    throw const FormatException('صيغة صورة غير مدعومة في النسخة الاحتياطية');
  }

  void dispose() => _timer?.cancel();
}
