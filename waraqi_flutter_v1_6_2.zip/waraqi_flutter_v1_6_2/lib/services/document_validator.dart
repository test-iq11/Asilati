import 'dart:io';

import '../models/paper_document.dart';
import '../widgets/paper_pages.dart';

class DocumentIssue {
  const DocumentIssue(this.message, {this.blocking = false});
  final String message;
  final bool blocking;
}

/// Pre-export diagnostics; never rewrites student scores or source questions.
/// PDF's estimated page limits remain conservative, pending device rendering.
class DocumentValidator {
  static List<DocumentIssue> inspect(PaperDocument doc, {required bool answers}) {
    final result = <DocumentIssue>[];
    final questions = doc.questions.where((q) => q.visible).toList();
    if (questions.length > 200) {
      result.add(const DocumentIssue('تجاوز عدد الأسئلة حد 200 سؤال.', blocking: true));
    }
    final actualTotal = doc.usedPoints;
    if ((actualTotal - doc.total).abs() > .001) {
      result.add(DocumentIssue('مجموع الدرجات $actualTotal يختلف عن الدرجة الكلية ${doc.total}.'));
    }
    final oversized = PaperPages.oversizedQuestions(doc, answers: answers);
    if (oversized.isNotEmpty) {
      result.add(DocumentIssue('الأسئلة ${oversized.map(doc.digits).join('، ')} أطول من المساحة الآمنة لصفحة A4.',blocking: true));
    }
    var imageCount = 0;
    for (var i = 0; i < questions.length; i++) {
      final q = questions[i];
      if (q.requiredBranches > q.branches.length) {
        result.add(DocumentIssue('السؤال ${doc.digits(i + 1)}: عدد الفروع المطلوبة أكبر من الفروع الموجودة.',blocking: true));
      }
      if (q.requiredBranches > 0 && q.requiredBranches < q.branches.length && q.useBranchPoints) {
        final grades = List.generate(q.branches.length, q.effectiveBranchPoints);
        if (grades.isNotEmpty && grades.any((value) => (value - grades.first).abs() > .001)) {
          result.add(DocumentIssue('السؤال ${doc.digits(i + 1)}: الفروع الاختيارية ليست متساوية الدرجات.'));
        }
      }
      for (final element in q.elements) {
        if (element.imagePath != null) {
          imageCount++;
          if (!File(element.imagePath!).existsSync()) {
            result.add(DocumentIssue('السؤال ${doc.digits(i + 1)}: صورة توضيحية مفقودة.',blocking: true));
          }
        }
        for (final image in element.galleryImages) {
          imageCount++;
          if (!File(image.path).existsSync()) {
            result.add(DocumentIssue('السؤال ${doc.digits(i + 1)}: صورة في الشبكة مفقودة.',blocking: true));
          }
        }
        if ((element.kind == 'math' || element.kind == 'chem') && element.text.trim().isEmpty) {
          result.add(DocumentIssue('السؤال ${doc.digits(i + 1)}: يوجد عنصر معادلة فارغ.'));
        }
        if (element.kind == 'math' && !_bracesBalanced(element.text)) {
          result.add(DocumentIssue('السؤال ${doc.digits(i + 1)}: الأقواس في المعادلة غير متوازنة.',blocking: true));
        }
      }
    }
    if (imageCount > 200) {
      result.add(const DocumentIssue('تجاوز عدد الصور حد 200 صورة.',blocking: true));
    }
    return doc.showQuestionWarnings ? result : result.where((issue)=>issue.blocking).toList();
  }

  static bool _bracesBalanced(String text) {
    var depth = 0;
    for (final code in text.runes) {
      if (code == 123) depth++;
      if (code == 125) depth--;
      if (depth < 0) return false;
    }
    return depth == 0;
  }
}
