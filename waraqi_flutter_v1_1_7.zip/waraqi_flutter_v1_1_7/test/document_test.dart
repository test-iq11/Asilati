import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;
import 'package:waraqi_studio/services/ocr_crop_service.dart';
import 'package:waraqi_studio/services/ocr_text_tools.dart';
import 'package:waraqi_studio/services/print_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:waraqi_studio/models/paper_document.dart';
import 'package:waraqi_studio/widgets/paper_pages.dart';

void main() {
  test('PaperDocument unnamed constructor is available across app entrypoints', () {
    final document = PaperDocument();
    expect(document.title, isNotEmpty);
    expect(document.questions, isNotEmpty);
    final fromEmptyJson = PaperDocument.fromJson(<String, dynamic>{});
    expect(fromEmptyJson.title, document.title);
    expect(fromEmptyJson.questions.length, document.questions.length);
    expect(PaperDocument.decode(document.encode()).title, document.title);
  });

  test('Arabic and English digits normalize across all source scripts', () {
    expect(formatDigits('س 1: 45.67 و ۱۲٣', DigitStyle.arabic), 'س ١: ٤٥.٦٧ و ١٢٣');
    expect(formatDigits('س ١: ٤٥.٦٧ و ۱۲٣', DigitStyle.english), 'س 1: 45.67 و 123');
    expect(formatDigits('رقم ١٢٣ 123 ۱۲۳', DigitStyle.english), 'رقم 123 123 123');
  });

  test('Arabic and English keyboard grades parse as finite numbers', () {
    expect(parseLocalizedNumber('١٢٫٥'), 12.5);
    expect(parseLocalizedNumber('12.5'), 12.5);
    expect(parseLocalizedNumber('۱۲٫۵'), 12.5);
    expect(parseLocalizedNumber('NaN'), isNull);
    expect(parseLocalizedNumber('Infinity'), isNull);
  });

  test('separate top and bottom A4 margins persist without clamping', () {
    final d = PaperDocument();
    d.topMarginMm = 0;
    d.bottomMarginMm = 27;
    d.digitStyle = DigitStyle.english;
    final copy = PaperDocument.decode(d.encode());
    expect(copy.topMarginMm, 0);
    expect(copy.bottomMarginMm, 27);
    expect(copy.digits('السؤال ٥: ٣+٢'), 'السؤال 5: 3+2');
    expect(PaperPages.mm(10), closeTo(28.346, .002));
  });

  test('full photo cropping happens after capture in photo coordinates', () {
    final full = img.Image(width: 1000, height: 800);
    final centered = OcrCropService.crop(full,
      centerX: .5, centerY: .5, widthFraction: .5, heightFraction: .25);
    expect(centered.width, 500);
    expect(centered.height, 200);
    final entire = OcrCropService.crop(full,
      centerX: .5, centerY: .5, widthFraction: 1, heightFraction: 1);
    expect(entire.width, full.width);
    expect(entire.height, full.height);
    final nearEdge = OcrCropService.crop(full,
      centerX: .95, centerY: .98, widthFraction: .6, heightFraction: .6);
    expect(nearEdge.width, 600);
    expect(nearEdge.height, 480);
  });

  test('optional student fields and footer teacher survive save/load', () {
    final d = PaperDocument()
      ..showStudentNameField = false
      ..showSectionField = false
      ..teacherName = 'سارة أحمد';
    final restored = PaperDocument.decode(d.encode());
    expect(restored.showStudentNameField, isFalse);
    expect(restored.showSectionField, isFalse);
    expect(restored.teacherName, 'سارة أحمد');
    // Old saved documents get the documented defaults for new fields.
    final oldData = d.toJson()
      ..remove('teacherName')
      ..remove('showStudentNameField')
      ..remove('showSectionField');
    final legacy = PaperDocument.fromJson(oldData);
    expect(legacy.showStudentNameField, isTrue);
    expect(legacy.showSectionField, isTrue);
    expect(legacy.teacherName, '');
  });

  testWidgets('optional student fields disappear and teacher appears in page footer', (tester) async {
    final d = PaperDocument()
      ..showStudentNameField = false
      ..showSectionField = false
      ..teacherName = 'سارة أحمد'
      ..questions = [PaperQuestion(id: 'q', text: 'سؤال تجريبي')];
    tester.view.physicalSize = const Size(1200, 1700);
    tester.view.devicePixelRatio = 1;
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: Center(
      child: ExamPage(document: d, questions: d.questions, pageIndex: 0,
        pageCount: 1, startingNumber: 1, answers: false),
    ))));
    expect(tester.takeException(), isNull);
    expect(find.text('اسم الطالب:'), findsNothing);
    expect(find.text('الصف/الشعبة:'), findsNothing);
    expect(find.text('معلم المادة: سارة أحمد'), findsOneWidget);
  });

  test('OCR inserts editable question text without embedding source photo', () {
    final d = PaperDocument();
    final q = d.questions.first;
    expect(q.insertExtractedText('أوجد ٣ × 4', append: false), isTrue);
    expect(q.insertExtractedText('ثم أجب عن ٥', append: true), isTrue);
    expect(q.insertExtractedText('   ', append: false), isFalse);
    expect(q.elements, isEmpty);
    final copy = PaperDocument.decode(d.encode());
    expect(copy.questions.first.text, 'أوجد ٣ × 4\nثم أجب عن ٥');
    expect(copy.questions.first.elements, isEmpty);
    expect(copy.digits(copy.questions.first.text), 'أوجد ٣ × ٤\nثم أجب عن ٥');
  });

  test('separately inserted illustrative images survive persistence', () {
    final d = PaperDocument();
    d.questions.first.elements.add(
      PaperElement(id: 'figure', kind: 'image', imagePath: '/test/figure.jpg'),
    );
    final copy = PaperDocument.decode(d.encode());
    expect(copy.questions.first.elements.first.imagePath, '/test/figure.jpg');
    expect(copy.questions.first.branches.length, 2);
  });

  test('pagination always includes a page, even with no questions', () {
    final d = PaperDocument()..questions = [];
    expect(PaperPages.paginate(d, answers: false).length, 1);
  });

  test('question headings and branches share one number style', () {
    final d = PaperDocument();
    for (final style in DigitStyle.values) {
      d.digitStyle = style;
      final heading = questionPrintLabel(d, 12, 'أوجد ٥ + 2');
      final branch = branchPrintLabel(d, 3, '٣ + 4');
      if (style == DigitStyle.english) {
        expect(heading, 'س 12: أوجد 5 + 2');
        expect(branch, '(3) 3 + 4');
      } else {
        expect(heading, 'س ١٢: أوجد ٥ + ٢');
        expect(branch, '(٣) ٣ + ٤');
      }
    }
  });

  test('digits stay consistent after saving and reloading', () {
    final d = PaperDocument()
      ..digitStyle = DigitStyle.english
      ..questions = [PaperQuestion(id: 'q01', text: 'أوجد ٥ + ٢',
        branches: ['٣ + 4', '۶ × 7'])];
    final restored = PaperDocument.decode(d.encode());
    final q = restored.questions.single;
    expect(questionPrintLabel(restored, 1, q.text), 'س 1: أوجد 5 + 2');
    expect(branchPrintLabel(restored, 1, q.branches.first), '(1) 3 + 4');
    expect(branchPrintLabel(restored, 2, q.branches.last), '(2) 6 × 7');
  });

  test('pagination keeps all visible questions and excludes hidden', () {
    final d = PaperDocument()
      ..questions = List.generate(16, (i) => PaperQuestion(
        id: 'q$i', text: 'سؤال رقم $i اختبار تنسيق الصفحات', points: 5));
    d.questions[8].visible = false;
    final pages = PaperPages.paginate(d, answers: false);
    expect(pages, isNotEmpty);
    final ids = pages.expand((page) => page).map((q) => q.id).toList();
    expect(ids.length, 15);
    expect(ids, d.questions.where((q) => q.visible).map((q) => q.id).toList());
  });

  test('oversized questions are detected before printing', () {
    final d = PaperDocument()
      ..questions = [PaperQuestion(id: 'too-long',
        text: List.filled(500, 'هذا النص طويل جداً').join(' '))];
    expect(PaperPages.oversizedQuestions(d, answers: false), [1]);
    d.questions.single.text = 'سؤال قصير';
    expect(PaperPages.oversizedQuestions(d, answers: false), isEmpty);
  });

  testWidgets('question numbering and body render with the same digit setting', (tester) async {
    final d = PaperDocument()
      ..digitStyle = DigitStyle.english
      ..showRules = false
      ..questions = [PaperQuestion(id: 'q1', text: 'أوجد ٥ + 2', branches: ['٣ + 4'])];
    tester.view.physicalSize = const Size(1200, 1700);
    tester.view.devicePixelRatio = 1;
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    Widget page() => MaterialApp(home: Scaffold(body: Center(
      child: ExamPage(document: d, questions: d.questions, pageIndex: 0,
        pageCount: 1, startingNumber: 1, answers: false),
    )));
    String printedText(String key) => tester.widget<Text>(
      find.byKey(ValueKey<String>(key)),
    ).data!;
    await tester.pumpWidget(page());
    expect(tester.takeException(), isNull,
      reason: 'A4 header and identity fields must not overflow horizontally');
    // Inspect the actual Text widgets that are printed, not an unrelated label.
    expect(printedText('exam-question-1'), 'س 1: أوجد 5 + 2');
    expect(printedText('exam-branch-1-1'), '(1) 3 + 4');
    d.digitStyle = DigitStyle.arabic;
    await tester.pumpWidget(page());
    expect(tester.takeException(), isNull);
    expect(printedText('exam-question-1'), 'س ١: أوجد ٥ + ٢');
    expect(printedText('exam-branch-1-1'), '(١) ٣ + ٤');
  });
  testWidgets('student identity lines fit A4 in both orientations and supported margins', (tester) async {
    final d = PaperDocument()
      ..showRules = false
      ..questions = [PaperQuestion(id: 'test', text: 'أوجد ٥ + ٢')];
    tester.view.physicalSize = const Size(1300, 1800);
    tester.view.devicePixelRatio = 1;
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    Widget page() => MaterialApp(home: Scaffold(body: Center(
      child: ExamPage(document: d, questions: d.questions, pageIndex: 0,
        pageCount: 1, startingNumber: 1, answers: false),
    )));
    for (final landscape in [false, true]) {
      for (final sideMargin in [5.0, 14.0, 30.0]) {
        for (final font in [11.0, 15.0, 23.0]) {
          d.landscape = landscape;
          d.sideMarginMm = sideMargin;
          d.fontSize = font;
          await tester.pumpWidget(page());
          expect(tester.takeException(), isNull,
            reason: 'Render overflow on A4: landscape=$landscape '
              'sideMargin=$sideMargin fontSize=$font');
          expect(find.byType(ExamPage), findsOneWidget);
        }
      }
    }
  });

  test('Arabic OCR cleanup drops suspect English words without losing any digits', () {
    const source = 'مساحة القارة ١٢٣٤ و 5678 و ۱۲۳ ET ey x\n'
        'قدر ناتج ٤٥ + ٣٢ = ٧٧';
    final cleaned = OcrTextTools.clean(source, arabicOnly: true);
    expect(cleaned, 'مساحة القارة ١٢٣٤ و 5678 و ۱۲۳ x\nقدر ناتج ٤٥ + ٣٢ = ٧٧');
    expect(cleaned, contains('١٢٣٤'));
    expect(cleaned, contains('5678'));
    expect(cleaned, contains('۱۲۳'));
    expect(OcrTextTools.hasLatinWords(source), isTrue);
    expect(OcrTextTools.hasDigits(source), isTrue);
    final bilingual = OcrTextTools.clean(source, arabicOnly: false);
    expect(bilingual, contains('ET ey'));
  });

  test('OCR image preparation preserves crop proportions and can be decoded', () {
    final sample = img.Image(width: 300, height: 120);
    final prepared = OcrTextTools.prepareForOcr(img.encodePng(sample));
    final decoded = img.decodeImage(prepared);
    expect(decoded, isNotNull);
    expect(decoded!.width, 1500);
    expect(decoded.height, 600);
  });

  test('section titles and exam templates survive serialization and cloning data', () {
    final d = PaperDocument()
      ..paperLayout = 'arabicLines'
      ..questions = [PaperQuestion(id: 'rules', text: 'استخرج المبتدأ والخبر',
        sectionTitle: 'القواعد', points: 10)];
    final saved = PaperDocument.decode(d.encode());
    expect(saved.paperLayout, 'arabicLines');
    expect(saved.questions.single.sectionTitle, 'القواعد');
    final oldDocument = d.toJson()..remove('paperLayout');
    expect(PaperDocument.fromJson(oldDocument).paperLayout, 'mathFrame');
  });

  test('editable Word format includes section headings and separated questions', () async {
    final d = PaperDocument()
      ..paperLayout = 'arabicLines'
      ..teacherName = 'علي'
      ..questions = [PaperQuestion(id: 'one', text: 'أعرب الآتي',
        sectionTitle: 'القواعد')];
    final html = await PrintService.generateWordHtml(d, answers: false);
    expect(html, contains('القواعد'));
    expect(html, contains('arabic-lines'));
    expect(html, contains('border-bottom:1px solid #444'));
    expect(html, contains('معلم المادة: علي'));
    expect(html, contains('أعرب الآتي'));
  });

}
