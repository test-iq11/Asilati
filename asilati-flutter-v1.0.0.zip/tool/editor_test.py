"""Check the packaged editor, OCR, native export bridge and student/teacher papers."""
import base64
import io
import json
import os
import shutil
import zipfile
from pathlib import Path
from xml.etree import ElementTree
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parents[1]
with sync_playwright() as playwright:
    executable = os.getenv('CHROME_BIN') or shutil.which('google-chrome') or shutil.which('chromium')
    browser = playwright.chromium.launch(executable_path=executable,args=['--no-sandbox','--disable-gpu','--no-zygote','--single-process'])
    tab = browser.new_page(viewport={'width':393,'height':851})
    tab.add_init_script("""window.messages=[];window.Asilati={postMessage:s=>messages.push(JSON.parse(s))};""")
    tab.goto((root/'assets/editor.html').as_uri())
    data=json.loads((root/'assets/seed.json').read_text())
    tab.evaluate("state=>nativeStart(state,1,'preview',state.exams[0].id,null)",data)
    assert 'تثبّت' not in tab.locator('#pages').inner_text()
    tab.get_by_role('button',name='الإجابة النموذجية',exact=True).click()
    assert 'تثبّت' in tab.locator('#pages').inner_text()
    tab.get_by_role('button',name='Word',exact=True).click()
    tab.wait_for_function("messages.some(m=>m.kind==='fileEnd')")
    chunks=tab.evaluate("messages.filter(m=>m.kind==='fileData').map(m=>m.data)")
    with zipfile.ZipFile(io.BytesIO(b''.join(base64.b64decode(chunk) for chunk in chunks))) as doc:
        xml=ElementTree.fromstring(doc.read('word/document.xml'))
        assert 'تثبّت' in ''.join(xml.itertext())
    tab.evaluate("go('edit');scan(E().qs[0].id)")
    encoded=base64.b64encode((root/'tool/printed-question.png').read_bytes()).decode()
    tab.evaluate("""s=>recognizeFile(new Blob([Uint8Array.from(atob(s),c=>c.charCodeAt(0))],{type:'image/png'}))""",encoded)
    assert 'الجذور' in tab.locator('#recognized').input_value()
    tab.get_by_role('button',name='إدراج النص في السؤال').click()
    assert tab.evaluate("messages.filter(m=>m.kind==='save').at(-1).state.exams[0].qs[0].text.endsWith('ما وظيفة الجذور في النبات؟')")
    browser.close()
print('Arabic OCR, editor autosave bridge, A4 preview, answer separation and DOCX export passed.')
