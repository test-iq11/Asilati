import 'dart:convert';

import 'package:asilati/main.dart';
import 'package:asilati/questions.dart';
import 'package:asilati/store.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('إنشاء ورقة ثم كتابة سؤال وحفظه', (tester) async {
    final state =
        jsonDecode(await rootBundle.loadString('assets/seed.json')) as Data;
    final store = ExamStore(state, (_, _) async {});
    await tester.pumpWidget(Asilati(store: store, locked: false));
    await tester.pumpAndSettle();
    await tester.tap(find.text('إنشاء ورقة'));
    await tester.pumpAndSettle();
    await tester.scrollUntilVisible(
      find.text('بدء كتابة الأسئلة'),
      350,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.tap(find.text('بدء كتابة الأسئلة'));
    await tester.pumpAndSettle();
    expect(find.byType(QuestionDesk), findsOneWidget);
    await tester.tap(find.text('سؤال'));
    await tester.pumpAndSettle();
    await tester.enterText(
      find.byType(TextFormField).first,
      'احسب مساحة المربع',
    );
    await tester.pump();
    expect(
      records(store.exams.first['qs']).first['text'],
      'احسب مساحة المربع',
    );
  });
}
