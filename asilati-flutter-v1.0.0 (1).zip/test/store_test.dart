import 'dart:convert';
import 'dart:io';

import 'package:asilati/store.dart';
import 'package:test/test.dart';

Data seed() => jsonDecode(File('assets/seed.json').readAsStringSync()) as Data;
void main() {
  test('تُجمع درجات الفروع دون احتساب الدرجة الرئيسية مرتين', () {
    final e = createExam({}, {});
    e['qs'] = [
      {
        'type': 'ذو فروع',
        'mark': 7,
        'parts': [
          {'mark': 2},
          {'mark': '2.5'},
        ],
      },
      {'type': 'مقالي', 'mark': 3},
    ];
    expect(total(e), 7.5);
  });
  test('يبقى مفتاح الإجابة صحيحاً بعد إعادة ترتيب النموذج B', () {
    final source = records(seed()['exams']).first;
    final q = records(source['qs']).last;
    final correct = q['opts'][q['correct']];
    final b = copyExam(source, formB: true);
    final other = records(b['qs']).first;
    expect(other['opts'][other['correct']], correct);
    expect(other['opts'], (q['opts'] as List).reversed.toList());
    expect(total(b), total(source));
    other['text'] = 'نص مختلف';
    expect(q['text'], isNot(other['text']));
  });
  test(
    'الحفظ السريع يكتب اللقطات بالترتيب ويتجاهل نسخة المحرر الأقدم',
    () async {
      final snapshots = <String>[];
      final s = ExamStore(seed(), (raw, rev) async {
        await Future<void>.delayed(const Duration(milliseconds: 1));
        snapshots.add(raw);
      });
      final e = s.exams.first;
      e['subject'] = 'العلوم';
      final first = s.save();
      e['subject'] = 'الرياضيات';
      final second = s.save();
      await Future.wait([first, second]);
      expect(
        records(jsonDecode(snapshots.first)['exams']).first['subject'],
        'العلوم',
      );
      expect(
        records(jsonDecode(snapshots.last)['exams']).first['subject'],
        'الرياضيات',
      );
      await s.importEditor(seed(), s.revision - 1);
      expect(s.exams.first['subject'], 'الرياضيات');
    },
  );
  test('إعادة حفظ نفس المراجعة بعد فشل كتابة عابر', () async {
    bool fail = true;
    final s = ExamStore(seed(), (_, _) async {
      if (fail) throw StateError('storage');
    });
    await expectLater(s.save(), throwsStateError);
    fail = false;
    await s.importEditor(s.data, s.revision);
    expect(s.active, isNotEmpty);
  });
}
