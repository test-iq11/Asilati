package iq.asilati.teacher

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterFragmentActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "iq.asilati/print")
            .setMethodCallHandler { call, result ->
                if (call.method != "print") {
                    result.notImplemented()
                    return@setMethodCallHandler
                }
                val webView = findEditor(window.decorView)
                if (webView == null) {
                    result.error("editor", "تعذّر العثور على معاينة الورقة", null)
                    return@setMethodCallHandler
                }
                val name = call.argument<String>("title") ?: "أسئلتي"
                val size = PrintAttributes.MediaSize.ISO_A4
                val page = if (call.argument<Boolean>("landscape") == true) size.asLandscape() else size.asPortrait()
                val printer = getSystemService(Context.PRINT_SERVICE) as PrintManager
                try {
                    printer.print(name, webView.createPrintDocumentAdapter(name),
                        PrintAttributes.Builder().setMediaSize(page).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build())
                    result.success(null)
                } catch (error: Exception) {
                    result.error("print", error.localizedMessage, null)
                }
            }
    }
    private fun findEditor(view: View): WebView? {
        if (view is WebView) return view
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) findEditor(view.getChildAt(i))?.let { return it }
        }
        return null
    }
}
