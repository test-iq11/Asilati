import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';

import 'security.dart';
import 'store.dart';

Future<void> configureAi(BuildContext context) async {
  final old = await secrets.read(key: 'model') ?? 'gpt-4o-mini';
  if (!context.mounted) return;
  final key = await askText(
    context,
    'مفتاح OpenAI الشخصي (فارغ لإزالته)',
    secret: true,
  );
  if (key == null) return;
  if (key.isEmpty) {
    await secrets.delete(key: 'api');
    return;
  }
  if (!context.mounted) return;
  final model = await askText(context, 'اسم النموذج', value: old);
  if (model == null || model.isEmpty) return;
  await secrets.write(key: 'api', value: key);
  await secrets.write(key: 'model', value: model);
}

class ExamEditor extends StatefulWidget {
  const ExamEditor({
    super.key,
    required this.store,
    required this.route,
    this.id,
    this.tool,
  });
  final ExamStore store;
  final String route;
  final String? id, tool;
  @override
  State<ExamEditor> createState() => _ExamEditorState();
}

class _ExamEditorState extends State<ExamEditor> {
  late final WebViewController web;
  bool ready = false, leaving = false, allowPop = false, asking = false;
  String? failure;
  final pendingFiles = <String, (String, BytesBuilder)>{};
  static const printChannel = MethodChannel('iq.asilati/print');
  @override
  void initState() {
    super.initState();
    web = WebViewController();
    unawaited(start());
  }

  void notice(String v) {
    if (mounted)
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(v)));
  }

  Future<void> start() async {
    try {
      await web.setJavaScriptMode(JavaScriptMode.unrestricted);
      final platform = web.platform as AndroidWebViewController;
      await platform.setOnShowFileSelector(pickFile);
      await web.addJavaScriptChannel(
        'Asilati',
        onMessageReceived: (m) => unawaited(message(m.message)),
      );
      await web.setNavigationDelegate(
        NavigationDelegate(
          onNavigationRequest: (request) {
            return request.url.startsWith(
                  'file:///android_asset/flutter_assets/assets/editor.html',
                )
                ? NavigationDecision.navigate
                : NavigationDecision.prevent;
          },
          onPageFinished: (url) async {
            if (!mounted || ready) return;
            try {
              final s = widget.store;
              await web.runJavaScript(
                'nativeStart(${jsonEncode(s.data)},${s.revision},${jsonEncode(widget.route)},${jsonEncode(widget.id)},${jsonEncode(widget.tool)});',
              );
              if (mounted) setState(() => ready = true);
            } catch (_) {
              if (mounted)
                setState(() => failure = 'تعذّر تحميل بيانات المحرر');
            }
          },
          onWebResourceError: (e) {
            if (e.isForMainFrame == true && mounted)
              setState(() => failure = 'تعذّر فتح محرر الأسئلة');
          },
        ),
      );
      await web.loadFlutterAsset('assets/editor.html');
    } catch (_) {
      if (mounted)
        setState(() => failure = 'تعذّر تشغيل المحرر على هذا الجهاز');
    }
  }

  Future<List<String>> pickFile(FileSelectorParams params) async {
    try {
      if (params.isCaptureEnabled) {
        final photo = await ImagePicker().pickImage(
          source: ImageSource.camera,
          maxWidth: 2600,
          imageQuality: 91,
        );
        return photo == null ? [] : [Uri.file(photo.path).toString()];
      }
      final accepts = params.acceptTypes.join(',').toLowerCase();
      final images = accepts.contains('image');
      final docs = accepts.contains('pdf') || accepts.contains('docx');
      final json = accepts.contains('json');
      final r = await FilePicker.platform.pickFiles(
        type: images
            ? FileType.image
            : docs || json
            ? FileType.custom
            : FileType.any,
        allowedExtensions: docs
            ? ['pdf', 'docx']
            : json
            ? ['json']
            : null,
      );
      final path = r?.files.single.path;
      return path == null ? [] : [Uri.file(path).toString()];
    } catch (_) {
      notice('تعذّر فتح الملف أو الكاميرا');
      return [];
    }
  }

  Future<void> close() async {
    if (leaving) return;
    leaving = true;
    try {
      if (ready) {
        final handled = await web.runJavaScriptReturningResult('nativeBack()');
        if (handled == true || handled == 'true') return;
        final raw = await web.runJavaScriptReturningResult(
          'JSON.stringify({state:db,revision:deviceRevision})',
        );
        Object? decoded = raw;
        if (decoded is String) decoded = jsonDecode(decoded);
        if (decoded is String) decoded = jsonDecode(decoded);
        final m = decoded as Map;
        await widget.store.importEditor(
          m['state'] as Data,
          m['revision'] as int,
        );
      }
      if (!mounted) return;
      setState(() => allowPop = true);
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) Navigator.pop(context);
      });
    } catch (_) {
      notice('تعذّر تأكيد الحفظ. حاول العودة مرة أخرى.');
    } finally {
      leaving = false;
    }
  }

  Future<void> message(String raw) async {
    try {
      final m = jsonDecode(raw) as Data;
      final id = m['id'];
      switch (m['kind']) {
        case 'save':
          await widget.store.importEditor(
            m['state'] as Data,
            m['revision'] as int,
          );
        case 'exit':
          await close();
        case 'print':
          await printChannel.invokeMethod<void>('print', {
            'title': m['title'],
            'landscape': m['landscape'],
          });
        case 'fileStart':
          pendingFiles[id as String] = (
            m['name'].toString().replaceAll(RegExp(r'[/\\\x00-\x1f]'), '_'),
            BytesBuilder(copy: false),
          );
        case 'fileData':
          pendingFiles[id]?.$2.add(base64Decode(m['data']));
        case 'fileEnd':
          final f = pendingFiles.remove(id);
          if (f != null) await exportFile(f.$1, f.$2.takeBytes());
        case 'ai':
          await propose(m);
      }
    } catch (_) {
      notice('تعذّر إتمام العملية. تحقق من مساحة الجهاز أو أعد المحاولة.');
    }
  }

  Future<void> exportFile(String name, Uint8List bytes) async {
    if (!mounted) return;
    final mode = await showDialog<String>(
      context: context,
      builder: (c) => SimpleDialog(
        title: Text(name),
        children: [
          SimpleDialogOption(
            onPressed: () => Navigator.pop(c, 'save'),
            child: const Text('حفظ في الجهاز'),
          ),
          SimpleDialogOption(
            onPressed: () => Navigator.pop(c, 'share'),
            child: const Text('مشاركة الملف'),
          ),
        ],
      ),
    );
    if (mode == 'save') {
      final path = await FilePicker.platform.saveFile(
        fileName: name,
        bytes: bytes,
        dialogTitle: 'حفظ الملف',
      );
      if (path != null) notice('حُفظ الملف');
    }
    if (mode == 'share') {
      final root = await getTemporaryDirectory();
      final dir = await root.createTemp('export-');
      final file = File('${dir.path}/$name');
      await file.writeAsBytes(bytes, flush: true);
      await SharePlus.instance.share(
        ShareParams(files: [XFile(file.path)], title: name),
      );
    }
  }

  Future<void> propose(Data m) async {
    if (asking || !mounted) return;
    asking = true;
    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 20);
    try {
      var key = await secrets.read(key: 'api');
      if (!mounted) return;
      if (key == null) {
        await configureAi(context);
        key = await secrets.read(key: 'api');
      }
      if (key == null || !mounted) return;
      final input = {
        'المادة': m['subject'],
        'الصف': m['grade'],
        'المستوى': m['difficulty'],
        'النص': m['text'],
      };
      final ok = await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('إرسال إلى OpenAI؟'),
          content: SingleChildScrollView(
            child: Text(
              'سيُرسَل النص التالي مع المادة والصف والصعوبة لتوليد مسودة. قد تُحتسب تكلفة على حساب الخدمة.\n\n${input['النص']}',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(c, false),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(c, true),
              child: const Text('إرسال'),
            ),
          ],
        ),
      );
      if (ok != true) return;
      final model = await secrets.read(key: 'model') ?? 'gpt-4o-mini';
      notice('جارٍ إعداد المسودة…');
      final req = await client.postUrl(
        Uri.https('api.openai.com', '/v1/chat/completions'),
      );
      req.headers
        ..set('Authorization', 'Bearer $key')
        ..contentType = ContentType.json;
      req.write(
        jsonEncode({
          'model': model,
          'messages': [
            {
              'role': 'system',
              'content': 'أنت مساعد معلم عراقي. اكتب سؤالاً وإجابة وفق النص أو الموضوع. أعد JSON يحتوي على question وanswer فقط.',
            },
            {'role': 'user', 'content': jsonEncode(input)},
          ],
        }),
      );
      final res = await req.close().timeout(const Duration(seconds: 75));
      final text = await utf8.decoder
          .bind(res)
          .join()
          .timeout(const Duration(seconds: 45));
      if (res.statusCode != 200) {
        notice(
          'تعذّر الاتصال بالخدمة (رمز ${res.statusCode}). راجع المفتاح واسم النموذج.',
        );
        return;
      }
      final content =
          jsonDecode(text)['choices'][0]['message']['content'] as String;
      final draft = jsonDecode(
        content
            .trim()
            .replaceFirst(RegExp(r'^```(?:json)?\s*'), '')
            .replaceFirst(RegExp(r'\s*```$'), ''),
      ) as Data;
      if (draft['question'] is! String || draft['answer'] is! String)
        throw const FormatException();
      if (mounted)
        await web.runJavaScript(
          'nativeProposal(${jsonEncode(draft['question'])},${jsonEncode(draft['answer'])});',
        );
    } catch (_) {
      notice('تعذّر تجهيز المسودة. أدوات التحرير المحلية متاحة.');
    } finally {
      client.close(force: true);
      asking = false;
    }
  }

  @override
  Widget build(BuildContext context) => PopScope(
    canPop: allowPop,
    onPopInvokedWithResult: (didPop, _) async {
      if (!didPop) await close();
    },
    child: Scaffold(
      appBar: AppBar(
        title: const Text('أسئلتي'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: close,
        ),
      ),
      body: SafeArea(
        child: Stack(
          children: [
            WebViewWidget.fromPlatformCreationParams(
              params: AndroidWebViewWidgetCreationParams(
                controller: web.platform,
                displayWithHybridComposition: true,
                layoutDirection: TextDirection.rtl,
              ),
            ),
            if (!ready || failure != null)
              Positioned.fill(
                child: ColoredBox(
                  color: Theme.of(context).scaffoldBackgroundColor,
                  child: Center(
                    child: failure == null
                        ? const CircularProgressIndicator()
                        : Text(failure!),
                  ),
                ),
              ),
          ],
        ),
      ),
    ),
  );
}
