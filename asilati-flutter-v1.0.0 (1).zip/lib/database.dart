import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:sqflite/sqflite.dart';

import 'store.dart';

Future<ExamStore> openStore() async {
  final db = await openDatabase(
    '${await getDatabasesPath()}/asilati.db',
    version: 1,
    onCreate: (db, _) => db.execute(
      'CREATE TABLE workspace (id INTEGER PRIMARY KEY, revision INTEGER, content TEXT NOT NULL)',
    ),
  );
  final rows = await db.query('workspace', where: 'id=1');
  final raw = rows.isEmpty
      ? await rootBundle.loadString('assets/seed.json')
      : rows.first['content'] as String;
  final store = ExamStore(jsonDecode(raw) as Data, (s, r) async {
    await db.insert('workspace', {
      'id': 1,
      'revision': r,
      'content': s,
    }, conflictAlgorithm: ConflictAlgorithm.replace);
  });
  store.revision = rows.isEmpty ? 0 : (rows.first['revision'] as int);
  if (rows.isEmpty) {
    await store.save();
  }
  return store;
}
