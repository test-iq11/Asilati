import 'dart:convert';

typedef Data = Map<String, dynamic>;
List<Data> records(Object? value) => (value as List).cast<Data>();
Data clone(Data value) => jsonDecode(jsonEncode(value)) as Data;
String newId() => DateTime.now().microsecondsSinceEpoch.toRadixString(36);
String titleOf(Data e) => e['title']?.toString().trim().isNotEmpty == true
    ? e['title'] as String
    : "${e['subject'].toString().isEmpty ? 'ورقة جديدة' : e['subject']} • ${e['kind']}";
num asNumber(Object? v) => num.tryParse(v.toString()) ?? 0;
num marks(Data q) => q['type'] == 'ذو فروع'
    ? records(q['parts']).fold<num>(0, (s, x) => s + asNumber(x['mark']))
    : asNumber(q['mark']);
num total(Data e) => records(e['qs']).fold<num>(0, (s, x) => s + marks(x));
const profileLabels = {
  'school': 'اسم المدرسة',
  'district': 'المديرية',
  'teacher': 'اسم المعلم',
  'stage': 'المرحلة',
  'grade': 'الصف',
  'section': 'الشعبة',
  'subject': 'المادة',
  'kind': 'نوع الامتحان',
  'year': 'العام الدراسي',
  'duration': 'المدة بالدقائق',
  'target': 'الدرجة الكلية',
  'count': 'عدد الأسئلة المخطط',
};
const defaults = <String, dynamic>{
  'school': '',
  'district': '',
  'teacher': '',
  'stage': 'الابتدائية',
  'grade': '',
  'section': '',
  'subject': '',
  'kind': 'شهري',
  'year': '',
  'duration': 45,
  'target': 20,
  'count': 4,
};
Data createExam(Data profile, Data settings) => {
  ...defaults,
  ...profile,
  'id': newId(),
  'date': DateTime.now().toIso8601String().substring(0, 10),
  'qs': <Data>[],
  'version': 'A',
  'orientation': settings['orientation'] ?? 'عمودي',
  'margin': settings['margin'] ?? 15,
  'gap': 14,
  'template': 'رسمي',
  'folder': '',
  'deleted': false,
  'modified': DateTime.now().millisecondsSinceEpoch,
};
Data copyExam(Data exam, {bool formB = false}) {
  final e = clone(exam);
  e['id'] = newId();
  e['title'] = "${titleOf(exam)} • ${formB ? 'نموذج B' : 'نسخة'}";
  e['modified'] = DateTime.now().millisecondsSinceEpoch;
  if (formB) {
    e['version'] = 'B';
    e['qs'] = records(e['qs']).reversed.toList();
    for (final q in records(e['qs'])) {
      if (q['type'] == 'اختيار من متعدد') {
        final a = (q['opts'] as List).reversed.toList();
        q['opts'] = a;
        q['correct'] = a.length - 1 - (q['correct'] as int);
      }
    }
  }
  return e;
}

class ExamStore {
  ExamStore(this.data, this.write);
  Data data;
  final Future<void> Function(String, int) write;
  Future<void> _pending = Future.value();
  int revision = 0;
  int _durable = -1;
  Data get settings => data['settings'] as Data;
  List<Data> get exams => records(data['exams']);
  List<Data> get bank => records(data['bank']);
  List<Data> get active => exams.where((e) => e['deleted'] != true).toList()
    ..sort(
      (a, b) => asNumber(b['modified']).compareTo(asNumber(a['modified'])),
    );
  Future<void> save({int? fromEditor}) {
    final now = DateTime.now().microsecondsSinceEpoch;
    revision = fromEditor ?? (now > revision ? now : revision + 1);
    final raw = jsonEncode(data), rev = revision;
    final next = _pending.then((_) async {
      await write(raw, rev);
      _durable = rev;
    });
    _pending = next.catchError((Object _) {});
    return next;
  }

  Future<void> importEditor(Data next, int rev) async {
    if (rev < revision) return;
    if (rev == revision) {
      await _pending;
      if (_durable >= rev) return;
    }
    data = next;
    await save(fromEditor: rev);
  }
}
