import 'package:flutter/material.dart';

import 'editor.dart';
import 'store.dart';

const questionTypes = [
  'مقالي',
  'اختيار من متعدد',
  'صح أو خطأ',
  'ملء الفراغات',
  'مطابقة',
  'تعاريف وتعاليل',
  'مسألة حسابية',
  'ترتيب كلمات',
  'سؤال مصوّر',
  'ذو فروع',
];
Data blankQuestion() => {
  'id': newId(),
  'type': questionTypes.first,
  'text': '',
  'mark': 5,
  'answer': '',
  'opts': ['', ''],
  'correct': 0,
  'parts': <Data>[],
  'lines': 2,
  'size': 16,
  'color': '#162b38',
  'font': 'V',
  'term': '',
  'unit': '',
  'lesson': '',
  'difficulty': 'متوسط',
  'image': '',
  'table': '',
  'shape': '',
  'area': 'خطوط',
};

class QuestionDesk extends StatefulWidget {
  const QuestionDesk({super.key, required this.store, required this.id});
  final ExamStore store;
  final String id;
  @override
  State<QuestionDesk> createState() => _QuestionDeskState();
}

class _QuestionDeskState extends State<QuestionDesk> {
  Data get e => widget.store.exams.firstWhere((x) => x['id'] == widget.id);
  String? active;
  int generation = 0;
  final past = <Data>[], future = <Data>[];
  void snapshot() {
    past.add(clone(e));
    if (past.length > 35) past.removeAt(0);
    future.clear();
  }

  Future<void> changed() async {
    e['modified'] = DateTime.now().millisecondsSinceEpoch;
    try {
      await widget.store.save();
    } catch (_) {
      if (mounted)
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('تعذّر حفظ التغييرات')));
    }
  }

  void revert(bool redo) {
    final a = redo ? future : past, b = redo ? past : future;
    if (a.isEmpty) return;
    b.add(clone(e));
    final n = a.removeLast();
    e
      ..clear()
      ..addAll(n);
    generation++;
    setState(() {});
    changed();
  }

  Future<void> advanced(String route, {String? tool}) async {
    await Navigator.push(
      context,
      MaterialPageRoute<void>(
        builder: (_) => ExamEditor(
          store: widget.store,
          route: route,
          id: widget.id,
          tool: tool,
        ),
      ),
    );
    if (mounted) {
      if (!widget.store.exams.any(
        (v) => v['id'] == widget.id && v['deleted'] != true,
      )) {
        Navigator.pop(context);
        return;
      }
      setState(() {
        generation++;
        past.clear();
        future.clear();
      });
    }
  }

  Widget input(
    String label,
    dynamic value,
    ValueChanged<String> onChange, {
    bool number = false,
    int rows = 1,
  }) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: TextFormField(
      initialValue: value.toString(),
      keyboardType: number
          ? const TextInputType.numberWithOptions(decimal: true)
          : TextInputType.multiline,
      minLines: rows,
      maxLines: number ? 1 : null,
      decoration: InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
      ),
      onTap: snapshot,
      onChanged: (v) {
        onChange(v);
        changed();
        setState(() {});
      },
    ),
  );
  void add() {
    snapshot();
    final q = blankQuestion();
    (e['qs'] as List).add(q);
    setState(() => active = q['id']);
    changed();
  }

  Widget content(Data q) {
    final type = q['type'],
        opts = (q['opts'] as List),
        parts = records(q['parts']);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        DropdownButtonFormField<String>(
          initialValue: type,
          items: questionTypes
              .map((v) => DropdownMenuItem(value: v, child: Text(v)))
              .toList(),
          decoration: const InputDecoration(labelText: 'نوع السؤال'),
          onChanged: (v) {
            if (v == null) return;
            snapshot();
            setState(() => q['type'] = v);
            changed();
          },
        ),
        input('نص السؤال', q['text'], (v) => q['text'] = v, rows: 2),
        if (type != 'ذو فروع')
          input(
            'الدرجة',
            q['mark'],
            (v) => q['mark'] = asNumber(v).clamp(0, 10000),
            number: true,
          ),
        if (type == 'اختيار من متعدد') ...[
          for (var i = 0; i < opts.length; i++)
            Row(
              children: [
                IconButton(
                  tooltip: 'تحديد الخيار الصحيح',
                  onPressed: () {
                    snapshot();
                    setState(() => q['correct'] = i);
                    changed();
                  },
                  icon: Icon(
                    q['correct'] == i
                        ? Icons.radio_button_checked
                        : Icons.radio_button_off,
                  ),
                ),
                Expanded(
                  child: input('الخيار ${i + 1}', opts[i], (v) => opts[i] = v),
                ),
              ],
            ),
          Wrap(
            children: [
              TextButton(
                onPressed: opts.length >= 6
                    ? null
                    : () {
                        snapshot();
                        setState(() => opts.add(''));
                        changed();
                      },
                child: const Text('إضافة خيار'),
              ),
              TextButton(
                onPressed: opts.length <= 2
                    ? null
                    : () {
                        snapshot();
                        opts.removeLast();
                        setState(
                          () => q['correct'] = (q['correct'] as int).clamp(
                            0,
                            opts.length - 1,
                          ),
                        );
                        changed();
                      },
                child: const Text('حذف آخر خيار'),
              ),
            ],
          ),
        ] else if (type == 'ذو فروع') ...[
          for (var i = 0; i < parts.length; i++)
            Column(
              children: [
                input(
                  'نص الفرع ${i + 1}',
                  parts[i]['text'],
                  (v) => parts[i]['text'] = v,
                ),
                input(
                  'درجة الفرع',
                  parts[i]['mark'],
                  (v) => parts[i]['mark'] = asNumber(v).clamp(0, 10000),
                  number: true,
                ),
                input(
                  'إجابة الفرع',
                  parts[i]['answer'],
                  (v) => parts[i]['answer'] = v,
                ),
              ],
            ),
          OutlinedButton(
            onPressed: () {
              snapshot();
              (q['parts'] as List).add({'text': '', 'mark': 1, 'answer': ''});
              setState(() {});
              changed();
            },
            child: const Text('إضافة فرع'),
          ),
        ] else if (type == 'صح أو خطأ')
          DropdownButtonFormField<String>(
            initialValue: ['صح', 'خطأ'].contains(q['answer'])
                ? q['answer']
                : null,
            decoration: const InputDecoration(labelText: 'الإجابة الصحيحة'),
            items: [
              'صح',
              'خطأ',
            ].map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(),
            onChanged: (v) {
              snapshot();
              setState(() => q['answer'] = v);
              changed();
            },
          )
        else
          input('الإجابة النموذجية', q['answer'], (v) => q['answer'] = v),
        if (type == 'مطابقة')
          input(
            'صفوف المطابقة (أ | ب)',
            q['table'],
            (v) => q['table'] = v,
            rows: 2,
          ),
        Wrap(
          spacing: 5,
          children: [
            TextButton.icon(
              onPressed: () =>
                  advanced('edit', tool: 'scanExisting:${q['id']}'),
              icon: const Icon(Icons.document_scanner_outlined),
              label: const Text('صورة إلى نص'),
            ),
            TextButton.icon(
              onPressed: () => advanced('edit', tool: 'expand:${q['id']}'),
              icon: const Icon(Icons.tune),
              label: const Text('تنسيق وإدراج'),
            ),
            TextButton(
              onPressed: () {
                snapshot();
                (e['qs'] as List).remove(q);
                setState(() => active = null);
                changed();
              },
              child: const Text('حذف السؤال'),
            ),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final qs = records(e['qs']);
    return Scaffold(
      appBar: AppBar(
        title: Text(titleOf(e)),
        actions: [
          IconButton(
            tooltip: 'تراجع',
            onPressed: past.isEmpty ? null : () => revert(false),
            icon: const Icon(Icons.undo),
          ),
          IconButton(
            tooltip: 'إعادة',
            onPressed: future.isEmpty ? null : () => revert(true),
            icon: const Icon(Icons.redo),
          ),
        ],
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 940),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(10),
                  child: Wrap(
                    spacing: 8,
                    runSpacing: 4,
                    children: [
                      FilledButton.icon(
                        onPressed: add,
                        icon: const Icon(Icons.add),
                        label: const Text('سؤال'),
                      ),
                      OutlinedButton(
                        onPressed: () => advanced('edit'),
                        child: const Text('المحرر المتقدم'),
                      ),
                      OutlinedButton(
                        onPressed: () => advanced('preview'),
                        child: const Text('معاينة الورقة'),
                      ),
                    ],
                  ),
                ),
                Text(
                  'الدرجات ${total(e)} / ${e['target']}  ${total(e) == asNumber(e['target']) ? '✓' : '• راجع المجموع'}',
                ),
                Expanded(
                  child: qs.isEmpty
                      ? const Center(
                          child: Text('أضف السؤال الأول لبدء كتابة الاختبار.'),
                        )
                      : ReorderableListView.builder(
                          padding: const EdgeInsets.all(12),
                          itemCount: qs.length,
                          onReorderItem: (old, dest) {
                            snapshot();
                            final list = e['qs'] as List;
                            list.insert(dest, list.removeAt(old));
                            setState(() {});
                            changed();
                          },
                          itemBuilder: (context, i) {
                            final q = qs[i];
                            return Card(
                              key: ValueKey('${q['id']}-$generation'),
                              child: Padding(
                                padding: const EdgeInsets.all(12),
                                child: Column(
                                  children: [
                                    ListTile(
                                      title: Text(
                                        'س${i + 1} ـ ${q['text'].toString().isEmpty ? q['type'] : q['text']}',
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      subtitle: Text(
                                        "${q['type']} · ${marks(q)} درجات",
                                      ),
                                      onTap: () => setState(
                                        () => active = active == q['id']
                                            ? null
                                            : q['id'],
                                      ),
                                    ),
                                    if (active == q['id']) content(q),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
