import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'store.dart';
import 'database.dart';
import 'editor.dart';
import 'questions.dart';
import 'security.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    final store = await openStore();
    final locked = await secrets.read(key: 'pin') != null;
    runApp(Asilati(store: store, locked: locked));
  } catch (_) {
    runApp(
      const MaterialApp(
        home: Scaffold(
          body: Center(
            child: Text('تعذّر فتح البيانات المحلية. أعد تشغيل التطبيق.'),
          ),
        ),
      ),
    );
  }
}

class Asilati extends StatefulWidget {
  const Asilati({super.key, required this.store, required this.locked});
  final ExamStore store;
  final bool locked;
  @override
  State<Asilati> createState() => _AsilatiState();
}

class _AsilatiState extends State<Asilati> {
  late bool locked = widget.locked;
  @override
  Widget build(BuildContext context) {
    final s = widget.store.settings;
    final hex =
        int.tryParse(
          (s['color'] ?? '#096c62').toString().replaceFirst('#', 'ff'),
          radix: 16,
        ) ??
        0xff096c62;
    final dark = s['night'] == true;
    return MaterialApp(
      title: 'أسئلتي',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      theme: ThemeData(
        useMaterial3: true,
        brightness: dark ? Brightness.dark : Brightness.light,
        colorSchemeSeed: Color(hex),
        scaffoldBackgroundColor: dark
            ? const Color(0xff080b0e)
            : const Color(0xfff3f6f8),
        fontFamily: s['font'] == 'serif' ? 'serif' : null,
      ),
      home: locked
          ? LockView(unlock: () => setState(() => locked = false))
          : Workspace(
              store: widget.store,
              refresh: () => setState(() {}),
              lock: () => setState(() => locked = true),
            ),
    );
  }
}

class Workspace extends StatefulWidget {
  const Workspace({
    super.key,
    required this.store,
    required this.refresh,
    required this.lock,
  });
  final ExamStore store;
  final VoidCallback refresh, lock;
  @override
  State<Workspace> createState() => _WorkspaceState();
}

class _WorkspaceState extends State<Workspace> {
  int tab = 0;
  String search = '', folder = 'الكل';
  ExamStore get s => widget.store;
  void note(String t) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));
  Future<void> save() async {
    try {
      await s.save();
      if (mounted) setState(() {});
    } catch (_) {
      if (mounted) note('تعذّر حفظ التغييرات على الجهاز');
    }
  }

  Future<void> openEditor(String route, {String? id, String? tool}) async {
    await Navigator.push(
      context,
      MaterialPageRoute<void>(
        builder: (_) => route == 'edit' && id != null && tool == null
            ? QuestionDesk(store: s, id: id)
            : ExamEditor(store: s, route: route, id: id, tool: tool),
      ),
    );
    if (mounted) {
      setState(() {});
      widget.refresh();
    }
  }

  Future<void> create({String? tool}) async {
    final m = await Navigator.push<Data>(
      context,
      MaterialPageRoute(
        builder: (_) =>
            MetadataForm(initial: {...defaults, ...s.data['profile'] as Data}),
      ),
    );
    if (m == null || !mounted) return;
    final exam = createExam(m, s.settings);
    exam['date'] = m['date'];
    s.data['profile'] = {...m}..remove('date');
    (s.data['exams'] as List).insert(0, exam);
    await save();
    if (mounted) await openEditor('edit', id: exam['id'], tool: tool);
  }

  Future<void> chooseTool(String tool) async {
    if (s.active.isEmpty) {
      await create(tool: tool);
      return;
    }
    final id = await showDialog<String>(
      context: context,
      builder: (c) => SimpleDialog(
        title: const Text('اختر ورقة الأسئلة'),
        children: [
          SimpleDialogOption(
            onPressed: () => Navigator.pop(c, '+'),
            child: const Text('＋ إنشاء ورقة جديدة'),
          ),
          ...s.active.map(
            (e) => SimpleDialogOption(
              onPressed: () => Navigator.pop(c, e['id']),
              child: Text(titleOf(e)),
            ),
          ),
        ],
      ),
    );
    if (!mounted || id == null) return;
    if (id == '+') {
      await create(tool: tool);
    } else {
      await openEditor('edit', id: id, tool: tool);
    }
  }

  Widget tile(
    String text,
    String sub,
    IconData icon,
    VoidCallback tap, {
    Color tone = const Color(0xff176f67),
    Widget? trailing,
  }) => Card(
    elevation: 0,
    child: ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      leading: CircleAvatar(
        backgroundColor: tone.withValues(alpha: .13),
        child: Icon(icon, color: tone),
      ),
      title: Text(text, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: sub.isEmpty ? null : Text(sub),
      trailing: trailing ?? const Icon(Icons.chevron_left),
      onTap: tap,
    ),
  );
  Widget heading(String t) => Padding(
    padding: const EdgeInsets.fromLTRB(4, 19, 4, 6),
    child: Text(t, style: Theme.of(context).textTheme.titleLarge),
  );
  Widget examTile(Data e, {bool actions = false}) => tile(
    titleOf(e),
    "${e['grade']} · ${records(e['qs']).length} أسئلة · نموذج ${e['version']}",
    Icons.description_outlined,
    () => openEditor('edit', id: e['id']),
    tone: const Color(0xffa07737),
    trailing: actions
        ? PopupMenuButton<String>(
            onSelected: (v) async {
              if (v == 'open') {
                await openEditor('edit', id: e['id']);
                return;
              }
              if (v == 'preview') {
                await openEditor('preview', id: e['id']);
                return;
              }
              if (v == 'folder') {
                final name = await askText(
                  context,
                  'اسم مجلد المادة أو الصف',
                  value: e['folder'] ?? '',
                );
                if (name == null) return;
                e['folder'] = name;
              } else if (v == 'trash') {
                e['deleted'] = true;
              } else {
                (s.data['exams'] as List).insert(
                  0,
                  copyExam(e, formB: v == 'B'),
                );
              }
              await save();
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'open', child: Text('فتح المحرر')),
              PopupMenuItem(value: 'preview', child: Text('معاينة الورقة')),
              PopupMenuItem(value: 'copy', child: Text('حفظ نسخة')),
              PopupMenuItem(value: 'B', child: Text('إنشاء نموذج B')),
              PopupMenuItem(value: 'folder', child: Text('تحديد المجلد')),
              PopupMenuItem(
                value: 'trash',
                child: Text('نقل إلى سلة المحذوفات'),
              ),
            ],
          )
        : null,
  );
  List<Widget> home() => [
    DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          colors: [Color(0xff12394c), Color(0xff265968)],
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'إنشاء أسئلة جديدة',
                    style: TextStyle(
                      fontSize: 26,
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const Text(
                    'أعدّ ورقة امتحانك ووزّع درجاتها.',
                    style: TextStyle(color: Color(0xffd0e3e8)),
                  ),
                  const SizedBox(height: 14),
                  FilledButton.icon(
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xffbcead5),
                      foregroundColor: const Color(0xff103b39),
                    ),
                    onPressed: create,
                    icon: const Icon(Icons.add),
                    label: const Text('إنشاء ورقة'),
                  ),
                ],
              ),
            ),
            const Icon(
              Icons.post_add_rounded,
              color: Color(0xffbcead5),
              size: 54,
            ),
          ],
        ),
      ),
    ),
    heading('أدوات المعلم'),
    LayoutBuilder(
      builder: (c, b) {
        final tools = [
          tile(
            'من صورة إلى سؤال',
            'التقاط أو اختيار صورة',
            Icons.document_scanner_outlined,
            () => chooseTool('scan'),
            tone: const Color(0xff346caa),
          ),
          tile(
            'مساعد الأسئلة',
            'اقتراح مسودة ومراجعتها',
            Icons.auto_awesome_outlined,
            () => chooseTool('assist'),
            tone: const Color(0xff7963a5),
          ),
        ];
        return b.maxWidth > 640
            ? Row(children: tools.map((t) => Expanded(child: t)).toList())
            : Column(children: tools);
      },
    ),
    heading('آخر الاختبارات'),
    ...s.active.take(3).map((e) => examTile(e)),
    if (s.active.isEmpty) const Text('ابدأ بإنشاء ورقتك الأولى.'),
  ];
  List<Widget> exams() {
    final folders = s.active
        .map((e) => (e['folder'] ?? '').toString())
        .where((f) => f.isNotEmpty)
        .toSet();
    return [
      heading('اختباراتي'),
      FilledButton.icon(
        onPressed: create,
        icon: const Icon(Icons.add),
        label: const Text('إنشاء ورقة'),
      ),
      TextField(
        decoration: const InputDecoration(
          labelText: 'بحث بالعنوان أو الصف',
          prefixIcon: Icon(Icons.search),
        ),
        onChanged: (v) => setState(() => search = v),
      ),
      Wrap(
        spacing: 6,
        children: ['الكل', ...folders]
            .map(
              (f) => ChoiceChip(
                label: Text(f),
                selected: f == folder,
                onSelected: (_) => setState(() => folder = f),
              ),
            )
            .toList(),
      ),
      ...s.active
          .where(
            (e) =>
                (folder == 'الكل' ||
                    !folders.contains(folder) ||
                    folder == e['folder']) &&
                '${titleOf(e)} ${e['grade']}'.contains(search),
          )
          .map((e) => examTile(e, actions: true)),
    ];
  }

  Future<void> protect() async {
    final existing = await secrets.read(key: 'pin');
    if (!mounted) return;
    if (existing != null) {
      final value = await askText(
        context,
        'رمز الدخول الحالي',
        secret: true,
        numeric: true,
      );
      if (value == null || !await verifyPin(value)) {
        if (mounted) note('رمز غير صحيح');
        return;
      }
      if (!mounted) return;
    }
    final v = await askText(
      context,
      existing == null
          ? 'تعيين رمز من ٦ أرقام'
          : 'رمز جديد (اتركه فارغاً لإلغاء القفل)',
      secret: true,
      numeric: true,
    );
    if (v == null) return;
    if (v.isEmpty && existing != null) {
      await secrets.delete(key: 'pin');
      await secrets.delete(key: 'bio');
    } else if (RegExp(r'^[0-9]{6}$').hasMatch(v)) {
      await setPin(v);
    } else {
      if (mounted) note('أدخل ستة أرقام من 0 إلى 9');
      return;
    }
    if (mounted) note('تم تحديث قفل التطبيق');
  }

  List<Widget> settings() => [
    heading('الإعدادات'),
    SwitchListTile(
      title: const Text('الوضع الليلي'),
      value: s.settings['night'] == true,
      onChanged: (v) async {
        s.settings['night'] = v;
        await save();
        widget.refresh();
      },
    ),
    tile(
      'المظهر والبيانات والنسخ الاحتياطي',
      'الألوان والخط وإعداد الورقة الافتراضي',
      Icons.palette_outlined,
      () => openEditor('settings'),
    ),
    tile('رمز الدخول', 'حماية التطبيق عند فتحه', Icons.lock_outline, protect),
    tile(
      'تفعيل أو إيقاف البصمة',
      'يتطلب تعيين رمز دخول أولاً',
      Icons.fingerprint,
      () async {
        if (await secrets.read(key: 'pin') == null) {
          if (mounted) note('عيّن رمز الدخول أولاً');
          return;
        }
        final on = await secrets.read(key: 'bio') == 'yes';
        await secrets.write(key: 'bio', value: on ? 'no' : 'yes');
        if (mounted) note(on ? 'تم إيقاف البصمة' : 'تم تفعيل خيار البصمة');
      },
    ),
    tile('قفل الآن', '', Icons.lock, () async {
      if (await secrets.read(key: 'pin') != null) {
        if (mounted) widget.lock();
      } else if (mounted) {
        note('عيّن رمز الدخول أولاً');
      }
    }),
    tile(
      'إعدادات المساعد المتصل',
      'مفتاح الخدمة واسم النموذج',
      Icons.auto_awesome,
      () => configureAi(context),
    ),
    tile(
      'سلة المحذوفات',
      'استعادة الاختبارات',
      Icons.restore_from_trash_outlined,
      () => openEditor('trash'),
    ),
  ];
  @override
  Widget build(BuildContext context) {
    final labels = ['الرئيسية', 'اختباراتي', 'بنك الأسئلة', 'الإعدادات'];
    return Scaffold(
      appBar: AppBar(title: const Text('أسئلتي')),
      drawer: Drawer(
        child: SafeArea(
          child: ListView(
            children: [
              heading('أسئلتي'),
              for (var i = 0; i < labels.length; i++)
                ListTile(
                  title: Text(labels[i]),
                  onTap: () {
                    Navigator.pop(context);
                    setState(() {
                      tab = i;
                      search = '';
                    });
                  },
                ),
              ListTile(
                title: const Text('سلة المحذوفات'),
                onTap: () {
                  Navigator.pop(context);
                  openEditor('trash');
                },
              ),
            ],
          ),
        ),
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 940),
          child: ListView(
            key: ValueKey(tab),
            padding: const EdgeInsets.all(16),
            children: tab == 0
                ? home()
                : tab == 1
                ? exams()
                : tab == 3
                ? settings()
                : [
                    heading('بنك الأسئلة'),
                    tile(
                      'فتح بنك الأسئلة',
                      'بحث وتصنيف وتعديل وإضافة للاختبار',
                      Icons.collections_bookmark_outlined,
                      () => openEditor('bank'),
                    ),
                    for (final q in s.bank.take(8))
                      tile(
                        q['text'],
                        [
                          q['type'],
                          q['subject'],
                          q['grade'],
                        ].whereType<String>().join(' · '),
                        Icons.bookmark_border,
                        () => openEditor('bank'),
                      ),
                  ],
          ),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() {
          tab = v;
          search = '';
        }),
        destinations: [
          for (var i = 0; i < labels.length; i++)
            NavigationDestination(
              icon: Icon(
                [
                  Icons.home_outlined,
                  Icons.description_outlined,
                  Icons.layers_outlined,
                  Icons.tune,
                ][i],
              ),
              label: labels[i],
            ),
        ],
      ),
    );
  }
}

class MetadataForm extends StatefulWidget {
  const MetadataForm({super.key, required this.initial});
  final Data initial;
  @override
  State<MetadataForm> createState() => _MetadataFormState();
}

class _MetadataFormState extends State<MetadataForm> {
  late final Data m = {
    ...widget.initial,
    'date': DateTime.now().toIso8601String().substring(0, 10),
  };
  final key = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('إنشاء ورقة أسئلة')),
    body: Form(
      key: key,
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          for (final entry in {...profileLabels, 'date': 'التاريخ'}.entries)
            Padding(
              padding: const EdgeInsets.only(bottom: 11),
              child: entry.key == 'kind' || entry.key == 'stage'
                  ? DropdownButtonFormField<String>(
                      initialValue: m[entry.key],
                      decoration: InputDecoration(
                        labelText: entry.value,
                        border: const OutlineInputBorder(),
                      ),
                      items:
                          (entry.key == 'kind'
                                  ? [
                                      'يومي',
                                      'شهري',
                                      'فصلي',
                                      'نصف السنة',
                                      'نهاية السنة',
                                    ]
                                  : ['الابتدائية', 'المتوسطة', 'الإعدادية'])
                              .map(
                                (x) =>
                                    DropdownMenuItem(value: x, child: Text(x)),
                              )
                              .toList(),
                      onChanged: (v) => m[entry.key] = v,
                    )
                  : TextFormField(
                      initialValue: m[entry.key].toString(),
                      decoration: InputDecoration(
                        labelText: entry.value,
                        border: const OutlineInputBorder(),
                      ),
                      keyboardType:
                          ['count', 'duration', 'target'].contains(entry.key)
                          ? TextInputType.number
                          : TextInputType.text,
                      onChanged: (v) => m[entry.key] = v,
                      validator: (v) =>
                          ['count', 'duration', 'target'].contains(entry.key) &&
                              asNumber(v) <= 0
                          ? 'أدخل قيمة أكبر من صفر'
                          : null,
                    ),
            ),
          FilledButton(
            onPressed: () {
              if (key.currentState!.validate()) Navigator.pop(context, m);
            },
            child: const Text('بدء كتابة الأسئلة'),
          ),
        ],
      ),
    ),
  );
}
