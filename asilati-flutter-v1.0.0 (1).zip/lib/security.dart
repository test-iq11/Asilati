import 'dart:convert';
import 'dart:math';

import 'package:cryptography/cryptography.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:local_auth/local_auth.dart';

const secrets = FlutterSecureStorage(
  aOptions: AndroidOptions(encryptedSharedPreferences: true),
);
Future<String> pinHash(String pin, List<int> salt) async {
  final k = await Pbkdf2(
    macAlgorithm: Hmac.sha256(),
    iterations: 120000,
    bits: 256,
  ).deriveKey(secretKey: SecretKey(utf8.encode(pin)), nonce: salt);
  return base64Encode(await k.extractBytes());
}

Future<void> setPin(String pin) async {
  final r = Random.secure(), salt = List.generate(16, (_) => r.nextInt(256));
  await secrets.write(
    key: 'pin',
    value: '${base64Encode(salt)}.${await pinHash(pin, salt)}',
  );
}

Future<bool> verifyPin(String pin) async {
  final s = await secrets.read(key: 'pin');
  if (s == null) return true;
  final pair = s.split('.');
  return await pinHash(pin, base64Decode(pair.first)) == pair.last;
}

Future<String?> askText(
  BuildContext context,
  String title, {
  String value = '',
  bool secret = false,
  bool numeric = false,
}) async {
  var entry = value;
  return showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: TextFormField(
        initialValue: value,
        autofocus: true,
        obscureText: secret,
        keyboardType: numeric ? TextInputType.number : TextInputType.text,
        onChanged: (v) => entry = v,
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: const Text('إلغاء'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(ctx, entry.trim()),
          child: const Text('تأكيد'),
        ),
      ],
    ),
  );
}

class LockView extends StatefulWidget {
  const LockView({super.key, required this.unlock});
  final VoidCallback unlock;
  @override
  State<LockView> createState() => _LockViewState();
}

class _LockViewState extends State<LockView> {
  String message = '';
  bool busy = false;
  Future<void> enter(bool biometric) async {
    if (busy) return;
    setState(() => busy = true);
    try {
      bool ok = false;
      if (biometric) {
        if (await secrets.read(key: 'bio') == 'yes') {
          ok = await LocalAuthentication().authenticate(
            localizedReason: 'فتح اختبارات المعلم',
            options: const AuthenticationOptions(biometricOnly: true),
          );
        } else {
          if (mounted) setState(() => message = 'البصمة غير مفعّلة');
          return;
        }
      } else {
        final v = await askText(
          context,
          'أدخل رمز الدخول',
          secret: true,
          numeric: true,
        );
        if (v == null) return;
        ok = await verifyPin(v);
      }
      if (!mounted) return;
      if (ok) {
        widget.unlock();
      } else {
        setState(() => message = 'تعذّر التحقق من الهوية');
      }
    } catch (_) {
      if (mounted)
        setState(() => message = 'تعذّر استخدام البصمة. استخدم رمز الدخول.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.lock_outline, size: 54),
          const Text('اختبارات المعلم'),
          FilledButton(
            onPressed: busy ? null : () => enter(false),
            child: const Text('إدخال الرمز'),
          ),
          TextButton(
            onPressed: busy ? null : () => enter(true),
            child: const Text('البصمة'),
          ),
          Text(message),
        ],
      ),
    ),
  );
}
