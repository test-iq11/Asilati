import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../models/paper_document.dart';

/// Print image snapshots of Flutter-rendered A4 pages. This preserves Arabic
/// shaping and digit selection offline, without depending on remote PDF fonts.
class PrintService {
  static Future<Uint8List> generatePdf(PaperDocument document,List<GlobalKey> pageKeys) async {
    final pdf=pw.Document(compress:true);
    final format=document.landscape?PdfPageFormat.a4.landscape:PdfPageFormat.a4;
    for(final key in pageKeys){
      final boundary=key.currentContext?.findRenderObject() as RenderRepaintBoundary?;
      if(boundary==null) throw StateError('صفحة غير جاهزة للتصدير');
      await WidgetsBinding.instance.endOfFrame;
      final ui.Image image=await boundary.toImage(pixelRatio:3);
      final data=await image.toByteData(format:ui.ImageByteFormat.png);
      image.dispose();
      if(data==null) throw StateError('تعذّر قراءة صورة الصفحة');
      final source=pw.MemoryImage(data.buffer.asUint8List());
      pdf.addPage(pw.Page(pageFormat:format,margin:pw.EdgeInsets.zero,build:(_)=>pw.Image(source,width:format.width,height:format.height,fit:pw.BoxFit.fill)));
    }
    return pdf.save();
  }
  static Future<void> printPages(PaperDocument doc,List<GlobalKey> keys) async {
    final bytes=await generatePdf(doc,keys);
    await Printing.layoutPdf(onLayout:(_)=>bytes,name:doc.title);
  }
  static Future<void> sharePdf(PaperDocument doc,List<GlobalKey> keys) async {
    final bytes=await generatePdf(doc,keys);
    await Printing.sharePdf(bytes:bytes,filename:'waraqi_exam.pdf');
  }
}
