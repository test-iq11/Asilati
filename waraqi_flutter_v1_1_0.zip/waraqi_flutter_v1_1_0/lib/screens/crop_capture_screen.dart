import 'dart:io';
import 'dart:math' as math;
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';
import '../theme.dart';

/// Frame is deliberately adjustable in the LIVE preview BEFORE shutter.
/// Imported images use the same adjustable frame before the crop is confirmed.
class CropCaptureScreen extends StatefulWidget {
  const CropCaptureScreen({super.key, required this.fromCamera});
  final bool fromCamera;
  @override State<CropCaptureScreen> createState() => _CropCaptureScreenState();
}

class _CropCaptureScreenState extends State<CropCaptureScreen> {
  CameraController? _controller;
  File? _picked;
  bool _working = true;
  String? _error;
  double _frameW = .80;
  double _frameH = .40;
  double _centerX = .5;
  double _centerY = .5;
  bool _saving = false;

  @override void initState() { super.initState(); _initialize(); }
  Future<void> _initialize() async {
    try {
      if (widget.fromCamera) {
        final devices = await availableCameras();
        if (devices.isEmpty) throw Exception('لا توجد كاميرا متاحة');
        final back = devices.where((d)=>d.lensDirection == CameraLensDirection.back);
        final device = back.isNotEmpty ? back.first : devices.first;
        final controller = CameraController(device, ResolutionPreset.high, enableAudio:false, imageFormatGroup:ImageFormatGroup.jpeg);
        await controller.initialize();
        if (!mounted) { await controller.dispose(); return; }
        _controller=controller;
      } else {
        final photo = await ImagePicker().pickImage(source:ImageSource.gallery, imageQuality:100);
        if (photo == null) { if(mounted) Navigator.of(context).pop(); return; }
        _picked=File(photo.path);
      }
    } catch (e) { _error='تعذّر فتح ${widget.fromCamera ? 'الكاميرا' : 'الصورة'}: $e'; }
    if(mounted) setState(()=>_working=false);
  }
  @override void dispose() { _controller?.dispose(); super.dispose(); }

  /// The frame is normalized to viewport; exported crop compensates for BoxFit.cover.
  Future<void> _capture(Size viewport) async {
    if (_saving) return;
    setState(()=>_saving=true);
    try {
      final original = widget.fromCamera
          ? await (await _controller!.takePicture()).readAsBytes()
          : await _picked!.readAsBytes();
      final decoded = img.decodeImage(original);
      if(decoded == null) throw Exception('صيغة الصورة غير مدعومة');
      final oriented = img.bakeOrientation(decoded);
      final iw=oriented.width.toDouble(), ih=oriented.height.toDouble();
      final scale=math.max(viewport.width/iw, viewport.height/ih);
      final displayedWidth=iw*scale, displayedHeight=ih*scale;
      final offsetX=(viewport.width-displayedWidth)/2;
      final offsetY=(viewport.height-displayedHeight)/2;
      final fx=(_centerX-_frameW/2)*viewport.width;
      final fy=(_centerY-_frameH/2)*viewport.height;
      final x=((fx-offsetX)/scale).round().clamp(0,oriented.width-1).toInt();
      final y=((fy-offsetY)/scale).round().clamp(0,oriented.height-1).toInt();
      final w=((_frameW*viewport.width)/scale).round().clamp(1,oriented.width-x).toInt();
      final h=((_frameH*viewport.height)/scale).round().clamp(1,oriented.height-y).toInt();
      final cropped=img.copyCrop(oriented,x:x,y:y,width:w,height:h);
      final resized=cropped.width>1900 ? img.copyResize(cropped,width:1900) : cropped;
      final result=img.encodeJpg(resized,quality:88);
      if(mounted) Navigator.of(context).pop(result);
    } catch(e) {
      if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذّر قص الصورة: $e')));
    } finally { if(mounted) setState(()=>_saving=false); }
  }

  @override Widget build(BuildContext context) {
    return Scaffold(backgroundColor:const Color(0xFF101C24), appBar:AppBar(backgroundColor:const Color(0xFF101C24),foregroundColor:Colors.white,title:Text(widget.fromCamera?'تصوير النص المراد استخراجه':'تحديد النص المراد استخراجه'),actions:[IconButton(onPressed:()=>Navigator.of(context).pop(),icon:const Icon(Icons.close))]), body:SafeArea(child:Column(children:[
      Padding(padding:const EdgeInsets.fromLTRB(18,8,18,10),child:Text(widget.fromCamera?'غيّر حجم إطار الالتقاط واسحبه إلى الجزء المطلوب قبل التصوير':'حدد الجزء المطلوب من الصورة بسحب الإطار وتغيير أبعاده',style:const TextStyle(color:Colors.white70,fontSize:13),textAlign:TextAlign.center)),
      Expanded(child:LayoutBuilder(builder:(context,constraints){
        final viewport=Size(constraints.maxWidth,constraints.maxHeight);
        if(_working) return const Center(child:CircularProgressIndicator());
        if(_error!=null) return Center(child:Padding(padding:const EdgeInsets.all(22),child:Text(_error!,style:const TextStyle(color:Colors.white),textAlign:TextAlign.center)));
        return Stack(fit:StackFit.expand,children:[
          if(widget.fromCamera && _controller!=null) ClipRect(child:LayoutBuilder(builder:(context,box){
            final size=_controller!.value.previewSize!;
            final portrait=Size(size.height,size.width);
            return FittedBox(fit:BoxFit.cover,child:SizedBox(width:portrait.width,height:portrait.height,child:CameraPreview(_controller!)));
          }))
          else if(_picked!=null) Image.file(_picked!,fit:BoxFit.cover),
          CustomPaint(painter:_CropShade(frame:Rect.fromCenter(center:Offset(_centerX*viewport.width,_centerY*viewport.height),width:_frameW*viewport.width,height:_frameH*viewport.height))),
          Positioned(left:(_centerX-_frameW/2)*viewport.width,top:(_centerY-_frameH/2)*viewport.height,width:_frameW*viewport.width,height:_frameH*viewport.height,child:GestureDetector(
            behavior:HitTestBehavior.translucent,
            onPanUpdate:(details)=>setState((){
              _centerX=(_centerX+details.delta.dx/viewport.width).clamp(_frameW/2,1-_frameW/2).toDouble();
              _centerY=(_centerY+details.delta.dy/viewport.height).clamp(_frameH/2,1-_frameH/2).toDouble();
            }),
            child:Container(decoration:BoxDecoration(border:Border.all(color:const Color(0xFFBBF0C6),width:2),borderRadius:BorderRadius.circular(10)),child:Stack(children:[
              const Positioned(right:4,top:4,child:Icon(Icons.open_with,color:Colors.white,size:20)),
              Positioned(bottom:4,left:4,child:Container(padding:const EdgeInsets.symmetric(horizontal:7,vertical:3),decoration:BoxDecoration(color:Colors.black54,borderRadius:BorderRadius.circular(8)),child:const Text('اسحب لتحريك الإطار',style:TextStyle(color:Colors.white,fontSize:10))))
            ])),
          )),
          Positioned(bottom:14,right:0,left:0,child:Center(child:FilledButton.icon(onPressed:_saving?null:()=>_capture(viewport),icon:Icon(widget.fromCamera?Icons.camera_alt_rounded:Icons.check_circle_outline),label:Text(_saving?'جارٍ المعالجة...':widget.fromCamera?'التقاط واستخراج النص':'قص واستخراج النص'),style:FilledButton.styleFrom(backgroundColor:const Color(0xFFB9EBD0),foregroundColor:Palette.ink,padding:const EdgeInsets.symmetric(horizontal:23,vertical:14))))),
        ]);
      })),
      Container(color:const Color(0xFF182832),padding:const EdgeInsets.fromLTRB(20,12,20,18),child:Column(children:[
        Row(children:[const Icon(Icons.width_normal,color:Colors.white70),const SizedBox(width:8),const Text('عرض اللقطة',style:TextStyle(color:Colors.white)),Expanded(child:Slider(value:_frameW,min:.25,max:.98,onChanged:(v)=>setState((){_frameW=v;_centerX=_centerX.clamp(v/2,1-v/2).toDouble();})))]),
        Row(children:[const Icon(Icons.height,color:Colors.white70),const SizedBox(width:8),const Text('ارتفاع اللقطة',style:TextStyle(color:Colors.white)),Expanded(child:Slider(value:_frameH,min:.18,max:.90,onChanged:(v)=>setState((){_frameH=v;_centerY=_centerY.clamp(v/2,1-v/2).toDouble();})))]),
      ])),
    ])));
  }
}

class _CropShade extends CustomPainter {
  const _CropShade({required this.frame});
  final Rect frame;
  @override void paint(Canvas canvas, Size size) {
    final path=Path()..addRect(Offset.zero&size)..addRRect(RRect.fromRectAndRadius(frame,const Radius.circular(10)));
    path.fillType=PathFillType.evenOdd;
    canvas.drawPath(path,Paint()..color=Colors.black.withValues(alpha:.56));
    final pen=Paint()..color=Colors.white.withValues(alpha:.5)..strokeWidth=1;
    for(var i=1;i<3;i++){
      canvas.drawLine(Offset(frame.left+frame.width*i/3,frame.top),Offset(frame.left+frame.width*i/3,frame.bottom),pen);
      canvas.drawLine(Offset(frame.left,frame.top+frame.height*i/3),Offset(frame.right,frame.top+frame.height*i/3),pen);
    }
  }
  @override bool shouldRepaint(covariant _CropShade oldDelegate)=>oldDelegate.frame!=frame;
}
