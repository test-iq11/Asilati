import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../models/paper_document.dart';

/// A4 in PDF points (72 dpi). The exact same widgets are captured for printing.
class PaperPages {
  static const a4Width = 595.28;
  static const a4Height = 841.89;
  static double mm(double value) => value*72/25.4;

  static List<List<PaperQuestion>> paginate(PaperDocument doc, {required bool answers}) {
    final pageHeight=doc.landscape?a4Width:a4Height;
    final overhead=mm(doc.topMarginMm+doc.bottomMarginMm)+175+mm(doc.headerGapMm);
    final available=math.max(160.0,pageHeight-overhead);
    final pages=<List<PaperQuestion>>[[]];
    var used=0.0;
    for(final q in doc.questions.where((q)=>q.visible)) {
      final score=estimateHeight(q,doc,answers:answers);
      if(pages.last.isNotEmpty && used+score>available){pages.add([]);used=0;}
      pages.last.add(q);used+=score;
    }
    return pages;
  }

  static double estimateHeight(PaperQuestion q,PaperDocument doc,{required bool answers}) {
    final fs=doc.fontSize;
    final lineWidth=math.max(23,(doc.landscape?100:55) * (15/fs)).round();
    double measure(String s)=>math.max(1,(s.length/lineWidth).ceil())*fs*doc.lineSpacing;
    var height=34+measure(q.text)+doc.questionGap;
    for(final b in q.branches){height+=measure(b)+4;}
    for(final e in q.elements){height+=e.imagePath!=null?170:math.max(35,measure(e.text)+12);}
    if(doc.showRules && q.branches.isEmpty && q.elements.isEmpty)height+=44;
    if(answers && q.answer.isNotEmpty)height+=measure(q.answer)+22;
    return height;
  }
}

class ExamPage extends StatelessWidget {
  const ExamPage({super.key,required this.document,required this.questions,required this.pageIndex,required this.pageCount,required this.startingNumber,required this.answers});
  final PaperDocument document;
  final List<PaperQuestion> questions;
  final int pageIndex,pageCount,startingNumber;
  final bool answers;

  @override Widget build(BuildContext context) {
    final d=document;
    final isFirst=pageIndex==0;
    final w=d.landscape?PaperPages.a4Height:PaperPages.a4Width;
    final h=d.landscape?PaperPages.a4Width:PaperPages.a4Height;
    final ink=const Color(0xFF171B1D);
    final textStyle=TextStyle(color:ink,fontSize:d.fontSize,height:d.lineSpacing,fontWeight:FontWeight.w400);
    return Directionality(textDirection:TextDirection.rtl,child:Container(
      width:w,height:h,color:Colors.white,
      padding:EdgeInsets.only(left:PaperPages.mm(d.sideMarginMm),right:PaperPages.mm(d.sideMarginMm),top:PaperPages.mm(d.topMarginMm),bottom:PaperPages.mm(d.bottomMarginMm)),
      child:DefaultTextStyle(style:textStyle,child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        if(isFirst) ...[
          _header(),SizedBox(height:PaperPages.mm(d.headerGapMm)),
          if(d.showHeaderLine) const Divider(color:Colors.black54,height:1,thickness:.65),
          const SizedBox(height:9),
          Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text('اسم الطالب: ..........................................',style:TextStyle(fontSize:d.fontSize*.68)),Text('الصف/الشعبة: ...................',style:TextStyle(fontSize:d.fontSize*.68))]),
          if(d.topNote.isNotEmpty) Padding(padding:const EdgeInsets.symmetric(vertical:7),child:Text(d.digits(d.topNote),textAlign:TextAlign.center,style:TextStyle(fontSize:d.fontSize*.85,fontWeight:FontWeight.bold))),
        ] else Padding(padding:const EdgeInsets.only(bottom:10),child:Text(d.digits(d.title),textAlign:TextAlign.center,style:TextStyle(fontSize:d.fontSize*.9,fontWeight:FontWeight.bold))),
        Expanded(child:ClipRect(child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
          for(var i=0;i<questions.length;i++) _question(questions[i],startingNumber+i,textStyle),
        ]))),
        if(d.showFooter) Padding(padding:const EdgeInsets.only(top:4),child:Text(d.digits(d.footerText),textAlign:TextAlign.center,style:TextStyle(fontSize:d.fontSize*.75))),
        if(d.showPageNumbers) Padding(padding:const EdgeInsets.only(top:5),child:Text('صفحة ${d.digits(pageIndex+1)} من ${d.digits(pageCount)}',textAlign:TextAlign.center,style:TextStyle(fontSize:d.fontSize*.65,color:Colors.black54))),
      ])),
    ));
  }

  Widget _header(){
    final d=document;
    bool visible(String name)=>d.headerFields.contains(name);
    Widget line(String key,String text)=>visible(key) ? Text(d.digits(text),style:TextStyle(fontSize:d.fontSize*.68,fontWeight:FontWeight.w600),textAlign:TextAlign.right) : const SizedBox.shrink();
    return Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        line('country',d.country),line('ministry',d.ministry),line('directorate',d.directorate),line('school',d.school),
      ])),
      Expanded(child:Column(children:[
        if(d.showLogo && d.logoPath!=null && File(d.logoPath!).existsSync()) Image.file(File(d.logoPath!),height:38,fit:BoxFit.contain),
        Text(d.digits(d.bismillah),style:TextStyle(fontSize:d.fontSize*.70),textAlign:TextAlign.center),
        if(visible('title')) Text(d.digits(d.title),style:TextStyle(fontSize:d.fontSize*.9,fontWeight:FontWeight.w800),textAlign:TextAlign.center),
        if(visible('academicYear')) Text('للعام الدراسي ${d.digits(d.academicYear)}',style:TextStyle(fontSize:d.fontSize*.65),textAlign:TextAlign.center),
      ])),
      Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.end,children:[
        line('subject','المادة: ${d.subject}'),line('grade','الصف: ${d.grade}'),
        line('total','الدرجة الكلية: ${d.total.toStringAsFixed(d.total==d.total.roundToDouble()?0:1)}'),
        line('duration','الوقت: ${d.duration}'),line('date','التاريخ: ${d.date}'),
      ])),
    ]);
  }

  Widget _question(PaperQuestion q,int index,TextStyle textStyle){
    final d=document;
    return Padding(padding:EdgeInsets.only(bottom:d.questionGap),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Expanded(child:Text('س ${d.digits(index)}: ${d.digits(q.text)}',style:textStyle.copyWith(fontWeight:FontWeight.w700))),
        if(d.showGrades) Container(margin:const EdgeInsets.only(right:10),padding:const EdgeInsets.symmetric(horizontal:6,vertical:3),decoration:BoxDecoration(border:Border.all(color:Colors.black54),borderRadius:BorderRadius.circular(4)),child:Text('${d.digits(q.points.toStringAsFixed(q.points==q.points.roundToDouble()?0:1))} درجات',style:TextStyle(fontSize:d.fontSize*.61))),
      ]),
      for(var i=0;i<q.branches.length;i++) Padding(padding:const EdgeInsets.only(top:4,right:12),child:Text('(${d.digits(i+1)}) ${d.digits(q.branches[i])}',style:textStyle)),
      for(final e in q.elements) _element(e,textStyle),
      if(d.showRules && q.type=='essay' && q.branches.isEmpty && q.elements.isEmpty) ...List.generate(2,(_)=>Container(margin:const EdgeInsets.only(top:20),decoration:const BoxDecoration(border:Border(bottom:BorderSide(color:Color(0xFFB9BEC1),width:.5))))),
      if(answers && q.answer.trim().isNotEmpty) Container(margin:const EdgeInsets.only(top:9),padding:const EdgeInsets.all(8),color:const Color(0xFFF1F7F4),child:Text('الإجابة: ${d.digits(q.answer)}',style:textStyle.copyWith(fontSize:d.fontSize*.84))),
    ]));
  }

  Widget _element(PaperElement e,TextStyle style){
    final d=document;
    if(e.imagePath!=null && File(e.imagePath!).existsSync()){
      return Padding(padding:const EdgeInsets.symmetric(vertical:7),child:Image.file(File(e.imagePath!),height:140,fit:BoxFit.contain,alignment:Alignment.centerRight));
    }
    switch(e.kind){
      case 'space':
        final count=int.tryParse(e.text)??3;
        return Column(children:List.generate(count.clamp(1,9).toInt(),(_)=>Container(height:25,decoration:const BoxDecoration(border:Border(bottom:BorderSide(color:Colors.black26))))));
      case 'options':
        return Column(crossAxisAlignment:CrossAxisAlignment.start,children:e.text.split('\n').where((x)=>x.isNotEmpty).map((t)=>Text('□ ${d.digits(t)}',style:style)).toList());
      case 'tf':
        return Text('□ صح    □ خطأ     ${d.digits(e.text)}',style:style);
      case 'table':
        final rows=e.text.split('\n').where((x)=>x.isNotEmpty).map((line)=>line.split('|')).toList();
        if(rows.isEmpty)return const SizedBox.shrink();
        return Table(border:TableBorder.all(color:Colors.black54,width:.5),children:rows.map((row)=>TableRow(children:row.map((cell)=>Padding(padding:const EdgeInsets.all(5),child:Text(d.digits(cell),style:style.copyWith(fontSize:d.fontSize*.8)))).toList())).toList());
      case 'math':case 'chem':
        return Padding(padding:const EdgeInsets.symmetric(vertical:5),child:Directionality(textDirection:TextDirection.ltr,child:Text(d.digits(e.text),textAlign:TextAlign.center,style:style.copyWith(fontWeight:FontWeight.w700))));
      default:return Padding(padding:const EdgeInsets.symmetric(vertical:5),child:Text(d.digits(e.text),style:style));
    }
  }
}
